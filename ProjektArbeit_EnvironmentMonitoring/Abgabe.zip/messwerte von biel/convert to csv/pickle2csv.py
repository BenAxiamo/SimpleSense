import pickle
import csv
a = pickle.load( open( "messages.pickle", "rb" ) )

with open('eggs.csv', 'w', newline='') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=' ',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
    for m in a:
        spamwriter.writerow(str(m["date"]), m["content"].hex())

