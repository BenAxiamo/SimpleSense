
figure 
[hAx,hLine1,hLine2] = plotyy([battery.timestamp],[battery.value],[counter.timestamp],[counter.value]);
title('Batterylevel vs Sendcounter')
datetick('x', 'HH')
xlabel('Time [Hour]')
ylabel(hAx(1),'Batterylevel [%]')   % left y-axis 
ylabel(hAx(2),'Sendcounter')        % right y-axis
legend('Batterylevel','Sendcounter')
grid on

figure 
[hAx,hLine1,hLine2] = plotyy([no2.timestamp],[no2.value],[o3.timestamp],[o3.value]);
title('O3 vs NO2')
datetick('x', 'HH')
xlabel('Time [Hour]')
ylabel(hAx(1),'NO2 [ppm]')   % left y-axis 
ylabel(hAx(2),'O3 [ppm]')        % right y-axis
legend('NO2 Concentration', 'O3 Concentration')
grid on

figure
plot([pm10.timestamp],[pm10.value])
hold
plot([pm2_5.timestamp],[pm2_5.value])
plot([pm1.timestamp],[pm1.value])
datetick('x', 'HH')
title('Pollution')
xlabel('Time [Hour]')
legend('PM10','PM2.5', 'PM1')
ylabel('PMxx [ug/m^3]')   % left y-axis 
grid on


figure
plot([temperature.timestamp],[temperature.value],'Marker', '.');
hold
plot([humidity.timestamp],[humidity.value],'Marker', '.');
datetick('x', 'HH')
title('Temperature vs Humidity')
xlabel('Time [Hour]')
ylabel('value')  
legend('Temperature [�C]', 'Humidity [%]')
ylim([0 100])

grid on

figure
p = plot([pressure.timestamp],[pressure.value]/100, 'Marker', '.');

datetick('x', 'HH')
xlabel('Time [Hour]')
title('Pressure')
ylabel('Pressure [hPa]') 
legend('Pressure')
ylim([900 1000])
grid on

figure
semilogy([lux.timestamp],[lux.value], 'Marker', '.');
datetick('x', 'HH')
legend('Illuminance')
title('Illuminance')
xlabel('Time [Hour]')
ylabel('Illuminance [Lux]')
grid on

figure
title('All Sensors')
plot([temperature.timestamp],[temperature.value])
hold
plot([humidity.timestamp],[humidity.value])
plot([lux.timestamp],[lux.value]/200)
plot([battery.timestamp],[battery.value])
plot([counter.timestamp],[counter.value]/2.6)
plot([pm1.timestamp],[pm1.value])
datetick('x', 'HH')
legend('temperature','humidity', 'lux', 'battery', 'sendcounter', 'pm1')
ylim([0 100])
grid on

