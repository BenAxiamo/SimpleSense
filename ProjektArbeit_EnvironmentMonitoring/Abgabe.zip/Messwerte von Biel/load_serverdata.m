[text, alldata] = xlsread('serverdata.csv'); %Funktioniert teilweise

counter = struct('timestamp',[],'timestamp_str',[],'value',[]);
counter_count = 1;
battery = struct('timestamp',[],'timestamp_str',[],'value',[]);
battery_count = 1;
noise = struct('timestamp',[],'timestamp_str',[],'value',[]);
noise_count = 1;
pm1 = struct('timestamp',[],'timestamp_str',[],'value',[]);
pm1_count = 1;
pm2_5 = struct('timestamp',[],'timestamp_str',[],'value',[]);
pm2_5_count = 1;
pm10 = struct('timestamp',[],'timestamp_str',[],'value',[]);
pm10_count = 1;
pressure = struct('timestamp',[],'timestamp_str',[],'value',[]);
pressure_count = 1;
no2 = struct('timestamp',[],'timestamp_str',[],'value',[]);
no2_count = 1;
o3 = struct('timestamp',[],'timestamp_str',[],'value',[]);
o3_count = 1;
lux = struct('timestamp',[],'timestamp_str',[],'value',[]);
lux_count = 1;
temperature = struct('timestamp',[],'timestamp_str',[],'value',[]);
temperature_count = 1;
humidity = struct('timestamp',[],'timestamp_str',[],'value',[]);
humidity_count = 1;

 
%{12922 '|2017-05-23 13:51:58.881727+00:00| 386531613032303030666562'} %Start senden
for index=12922:length(alldata)
    
    data = strsplit(char(alldata(index)),'|') ;         %Zeile splitten in Timestamp und Hexdata
    
    data_hex = char(sscanf(char(data(3)), '%2x'))';     %Hexdaten in Text umwndeln
    data_ascii = char(sscanf(data_hex, '%2x'))';        %Hexdaten in Text umwndeln

    values = strsplit(data_ascii,'#');                  %Textdaten Aufsplitten in einzelne Werte und dessen Tag
    values = values(4:end) ;                            %Overhead entfernen
   
    %datum konvertieren
    date_str = strsplit(char(data(2)), '.');
    date_str = date_str(1);
    date_int = datenum(date_str(1),'yyyy-mm-dd HH:MM:SS');
    
    %Wenn messwerte vorhanden sind, alles abspeichern im struct
    if(length(values)>0) 
       
        counter(counter_count).value = str2double(char(values(1)));
        counter(counter_count).timestamp_str = char(date_str);
        counter(counter_count).timestamp = date_int;
        counter_count = counter_count+1;
        
        for j=2:length(values)

            value = strsplit(char(values(j)),':');

            switch char(value(1))
                case 'BAT'
                    battery(battery_count).value = str2double(char(value(2)));
                    battery(battery_count).timestamp_str = char(date_str);
                    battery(battery_count).timestamp = date_int;
                    battery_count = battery_count +1;
                case 'NOISE'
                    noise(noise_count).value = str2double(char(value(2)));
                    noise(noise_count).timestamp_str = char(date_str);
                    noise(noise_count).timestamp = date_int;
                    noise_count = noise_count +1;
                case 'PM1'
                    pm1(pm1_count).value = str2double(char(value(2)));
                    pm1(pm1_count).timestamp_str = char(date_str);
                    pm1(pm1_count).timestamp = date_int;
                    pm1_count = pm1_count +1;
                case 'PM2_5'
                    pm2_5(pm2_5_count).value = str2double(char(value(2)));
                    pm2_5(pm2_5_count).timestamp_str = char(date_str);
                    pm2_5(pm2_5_count).timestamp = date_int;
                    pm2_5_count = pm2_5_count +1;
                case 'PM10'
                    pm10(pm10_count).value = str2double(char(value(2)));
                    pm10(pm10_count).timestamp_str = char(date_str);
                    pm10(pm10_count).timestamp = date_int;
                    pm10_count = pm10_count +1;
                case 'PRES'
                    pressure(pressure_count).value = str2double(char(value(2)));
                    pressure(pressure_count).timestamp_str = char(date_str);
                    pressure(pressure_count).timestamp = date_int;
                    pressure_count = pressure_count +1;
                case 'NO2'
                     no2(no2_count).value = str2double(char(value(2)));
                    no2(no2_count).timestamp_str = char(date_str);
                    no2(no2_count).timestamp = date_int;
                    no2_count = no2_count +1;
                case 'O3'
                    o3(o3_count).value = str2double(char(value(2)));
                    o3(o3_count).timestamp_str = char(date_str);
                    o3(o3_count).timestamp = date_int;
                    o3_count = o3_count +1;
                case 'LUX'
                    lux(lux_count).value = str2double(char(value(2)));
                    lux(lux_count).timestamp_str = char(date_str);
                    lux(lux_count).timestamp = date_int;
                    lux_count = lux_count +1;
                case 'TC'
                    temperature(temperature_count).value = str2double(char(value(2)));
                    temperature(temperature_count).timestamp_str = char(date_str);
                    temperature(temperature_count).timestamp = date_int;
                    temperature_count = temperature_count +1;
                case 'HUM'
                    humidity(humidity_count).value = str2double(char(value(2)));
                    humidity(humidity_count).timestamp_str = char(date_str);
                    humidity(humidity_count).timestamp = date_int;
                    humidity_count = humidity_count +1;
            end 
        end
    end
end
 
ende = 1
 

