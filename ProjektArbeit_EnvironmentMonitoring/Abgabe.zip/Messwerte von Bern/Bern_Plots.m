csv_hour = importdata('data_hour.csv');
csv_day = importdata('data_tag.csv');

o3_hour = csv_hour.data(:,1);
no2_hour = csv_hour.data(:,2);
pm10_hour= csv_hour.data(:,3);
temp_hour = csv_hour.data(:,4);
regen_hour = csv_hour.data(:,5);
rad_hour = csv_hour.data(:,6);

o3_day = csv_day.data(:,1);
no2_day = csv_day.data(:,2);
pm10_day= csv_day.data(:,3);
temp_day = csv_day.data(:,4);
regen_day = csv_day.data(:,5);
rad_day = csv_day.data(:,6);

%%%%%%%%%%%%%%% Durchschnittliche Ozon No2 und Pm10 werte Pro stunde
if 1
pm10_timeAvg = zeros(3,24)
o3_timeAvg = zeros(3,24)
no2_timeAvg = zeros(3,24)

for i=1:24
    pm10_timeAvg(1,i) = nanmean (pm10_hour(i:24:end));
    no2_timeAvg(1,i) = nanmean (no2_hour(i:24:end));
    o3_timeAvg(1,i) = nanmean (o3_hour(i:24:end));
end
figure 
plot(o3_timeAvg(1,:))
hold
plot(no2_timeAvg(1,:))
legend('Ozon [ppm]', 'NO2 [ppm]');
title('Durchschnittliche 03/N02 Belastung')

figure
plot(pm10_timeAvg(1,:))
legend('PM10 [ug/m^3]');
title('Durchschnittliche PM10 Belastung')

end

%%%%%%%%%%%%%%% 
if 0
pm10_hour = pm10_hour(~isnan(pm10_hour)); %Entferne Nan

figure
plot(pm10_hour(((0*24)+1):24+(0*24)))
hold
plot(pm10_hour(((1*24)+1):24+(1*24)))
plot(pm10_hour(((2*24)+1):24+(2*24)))
plot(pm10_hour(((3*24)+1):24+(3*24)))
plot(pm10_hour(((4*24)+1):24+(4*24)))

pm10_norm = pm10_hour - mean(pm10_hour);% Nan Werte ignorieren
pm10_norm(isnan(pm10_norm)) =0;
fs = 1; %Jede Stunde einen Wert
t = (0:length(pm10_norm)-1)/fs;
[autocor, lags] = xcorr(pm10_norm, length(pm10_norm)*fs, 'unbiased');

figure 
plot(t, pm10_norm)
plot(lags/fs, autocor);

figure
plot(abs(fft(autocor)))
end
%%%%%%%%%%%%%%% Berechne Pm10 Zu Niederschlag 
if 1
pm10_ohneRegen = [];
pm10_mitRegen = [];
for i= 1:length(pm10_day)
    if regen_day(i) == 0
        pm10_ohneRegen = [pm10_ohneRegen pm10_day(i)]
    else
        pm10_mitRegen = [pm10_mitRegen pm10_day(i)]
    end
end

figure
histogram(pm10_ohneRegen, [1:10:150],'faceColor', 'r')
hold on
histogram(pm10_mitRegen,[1:10:150],'facecolor','b')
legend('ohne NS','mit NS')
xlabel('PM10 Konzentration [ug/m^3]');
ylabel('Anzahl Messwerte');
end