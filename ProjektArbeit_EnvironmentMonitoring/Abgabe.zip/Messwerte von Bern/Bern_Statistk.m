csv = importdata('data_hour.csv');
csv_tag = importdata('data_tag.csv');

csv.textdata; %timestamp
csv.data; %Datenwerte

%Korrekte Excelspalte w�hlen f�r Daten
O3      = csv_tag.data(:,1); %Werte in [�g/m�]
NO2     = csv_tag.data(:,2); %Werte in [�g/m�]
pm10    = csv_tag.data(:,3); %Werte in [�g/m�]
temp    = csv_tag.data(:,4); %Werte in [�C]
regen   = csv_tag.data(:,5); %Werte in [�C]
rad     = csv_tag.data(:,6);%Werte in [W/m�]

%Daten der Gr�sse nach sortieren
sort_O3     = sort(O3);
sort_NO2    = sort(NO2);
sort_pm10   = sort(pm10);
sort_regen  = sort(regen);
sort_temp   = sort(temp);
sort_rad    = sort(rad);

%Alle Mittelwerte berechnen
mittelwert_O3       = mean(sort_O3);
mittelwert_NO2      = mean(sort_NO2);
mittelwert_pm10     = nanmean(sort_pm10);
mittelwert_regen    = nanmean(sort_regen);
mittelwert_temp     = nanmean(sort_temp);
mittelwert_rad      = nanmean(sort_rad);

%Alle Varianzen berechnen
var_O3       = var(sort_O3);
var_NO2      = var(sort_NO2);
var_pm10     = nanvar(sort_pm10);
var_regen    = nanvar(sort_regen);
var_temp     = nanvar(sort_temp);
var_rad      = nanvar(sort_rad);

stdabw_O3       = sqrt(var_O3)
stdabw_NO2      = sqrt(var_NO2)
stdabw_pm10     = sqrt(var_pm10)
stdabw_regen    = sqrt(var_regen)
stdabw_temp     = sqrt(var_temp)
stdabw_rad      = sqrt(var_rad);

%Min & Max Werte bestimmen
max_O3      = max(O3);
min_O3      = min(O3);
max_NO2     = max(NO2);
min_NO2     = min(NO2);
max_pm10    = max(pm10);
min_pm10    = min(pm10);
max_regen   = max(regen);
min_regen   = min(regen);
max_temp    = max(temp);
min_temp    = min(temp);
max_rad     = max(rad);
min_rad     = min(rad);

%Messwerte in Monat aufteilen
Jun16      = csv_tag.data(3:32,1:6);    %Zeile,Spalte
Jul16      = csv_tag.data(33:63,1:6);   %Zeile,Spalte
Aug16      = csv_tag.data(64:94,1:6);   %Zeile,Spalte
Sept16     = csv_tag.data(95:124,1:6);  %Zeile,Spalte
Okt16      = csv_tag.data(125:155,1:6); %Zeile,Spalte
Nov16      = csv_tag.data(156:185,1:6); %Zeile,Spalte
Dez16      = csv_tag.data(186:216,1:6); %Zeile,Spalte
Jan17      = csv_tag.data(217:247,1:6); %Zeile,Spalte
Feb17      = csv_tag.data(248:275,1:6); %Zeile,Spalte
Maer17     = csv_tag.data(276:306,1:6); %Zeile,Spalte
Apr17      = csv_tag.data(307:336,1:6); %Zeile,Spalte
Mai17      = csv_tag.data(337:366,1:6); %Zeile,Spalte