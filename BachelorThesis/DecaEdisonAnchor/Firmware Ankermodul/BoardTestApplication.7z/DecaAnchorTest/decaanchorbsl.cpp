#include "decaanchorbsl.h"

DecaAnchorBSL::DecaAnchorBSL(QObject *parent)
{
	/* setup power converters / on-board voltages */
	initPowerConverters();

	/* setup level shifters */
	initLevelShifters();

	/* setup power management monitoring */
	initPowerManagement();

	/* setup decawave module */
	initDecaWave();

	/* setup further communication interfaces */


	/* setup on-board peripherals */
	initPWM();
	initLeds();
	initButtons();
	initGPIO();
}

DecaAnchorBSL::~DecaAnchorBSL()
{
	/* disabling interrupts */
	decaIRQ->isr(mraa::EDGE_NONE, &isrDecaExton, this);
	decaEXT->isr(mraa::EDGE_NONE, &isrDecaExton, this);
	chgDone->isr(mraa::EDGE_NONE, &isrChargeDone, this);
	gaugeAlcc->isr(mraa::EDGE_NONE, &isrGaugeAlert, this);
	gpioPB3->isr(mraa::EDGE_NONE, &isrPB3, this);
	gpioPB2->isr(mraa::EDGE_NONE, &isrPB2, this);
	gpioPB1->isr(mraa::EDGE_NONE, &isrPB1, this);

	/* clearing outputs */
	gpioL3->write(LED_OFF);
	gpioL2->write(LED_OFF);
	gpioL1->write(LED_OFF);

	qDebug() << "Destructor BSL Start";

	/* free used ressources */
	delete gpio1;
	delete gpio0;

	delete gpioPB3;
	delete gpioPB2;
	delete gpioPB1;

	delete gpioL3;
	delete gpioL2;
	delete gpioL1;

	delete gpioBluePWM;
	delete gpioGreenPWM;
	delete gpioRedPWM;

	delete spiMaster_;
	delete decaRST;
	delete decaEXT;
	delete decaWKU;
	delete decaIRQ;
	delete decaCS;
	delete spi;

	delete chgDone;
	delete gaugeAlcc;

	delete enaLS2;
	delete enaLS1;
	delete ena5V0;
	delete ena3V3;

	qDebug() << "Destructor BSL Stop";
}


void DecaAnchorBSL::initPowerConverters()
{
	ena3V3 = new mraa::Gpio(PIN_ENA3V3);
	ena5V0 = new mraa::Gpio(PIN_ENA5V0);

	ena3V3->mode(mraa::MODE_STRONG);
	ena3V3->dir(mraa::DIR_OUT_HIGH);

	ena5V0->mode(mraa::MODE_STRONG);
	ena5V0->dir(mraa::DIR_OUT_HIGH);
}

void DecaAnchorBSL::enablePC5V0(bool enable)
{
	if (enable) {
		ena5V0->write(ENABLE);
	} else {
		ena5V0->write(DISABLE);
	}
}

void DecaAnchorBSL::enablePC3V3(bool enable)
{
	if (enable) {
		ena3V3->write(ENABLE);
	} else {
		ena3V3->write(DISABLE);
	}
}


void DecaAnchorBSL::initLevelShifters()
{
	enaLS1 = new mraa::Gpio(PIN_ENALS1);
	enaLS2 = new mraa::Gpio(PIN_ENALS2);

	enaLS1->mode(mraa::MODE_STRONG);
	enaLS1->dir(mraa::DIR_OUT_HIGH);

	enaLS2->mode(mraa::MODE_STRONG);
	enaLS2->dir(mraa::DIR_OUT_HIGH);
}

void DecaAnchorBSL::enableLS1(bool enable)
{
	if (enable) {
		enaLS1->write(ENABLE);
	} else {
		enaLS1->write(DISABLE);
	}
}

void DecaAnchorBSL::enableLS2(bool enable)
{
	if (enable) {
		enaLS2->write(ENABLE);
	} else {
		enaLS2->write(DISABLE);
	}
}


void DecaAnchorBSL::initPowerManagement()
{
	gaugeAlcc = new mraa::Gpio(PIN_ALCC);
	chgDone = new mraa::Gpio(PIN_CHG_DO);

	gaugeAlcc->mode(mraa::MODE_HIZ);
	gaugeAlcc->dir(mraa::DIR_IN);
	gaugeAlcc->isr(mraa::EDGE_FALLING, &isrGaugeAlert, this);

	chgDone->mode(mraa::MODE_HIZ);
	chgDone->dir(mraa::DIR_IN);
	chgDone->isr(mraa::EDGE_FALLING, &isrChargeDone, this);

	/* TODO: initialize powergauge/i2c, provide gauge api */
}

void DecaAnchorBSL::isrGaugeAlert(void *args)
{
	qDebug() << "Gauge Alert";

	DecaAnchorBSL *bsl = static_cast<DecaAnchorBSL *>(args);

	/* handle gauge alert */

	emit bsl->gaugeAlert();
}

void DecaAnchorBSL::isrChargeDone(void *args)
{
	qDebug() << "Charge Done";

	DecaAnchorBSL *bsl = static_cast<DecaAnchorBSL *>(args);

	/* handle chargeDone */

	emit bsl->chargeDone();
}


void DecaAnchorBSL::initDecaWave()
{
	spi = new mraa::Spi(2);

	decaCS = new mraa::Gpio(PIN_DECA_CS);
	decaCS->mode(mraa::MODE_STRONG);
	decaCS->dir(mraa::DIR_OUT_HIGH);

	decaIRQ = new mraa::Gpio(PIN_DECA_IRQ);
	decaIRQ->mode(mraa::MODE_HIZ);
	decaIRQ->dir(mraa::DIR_IN);

	decaEXT = new mraa::Gpio(PIN_DECA_EXT);
	decaEXT->mode(mraa::MODE_HIZ);
	decaEXT->dir(mraa::DIR_IN);
	decaEXT->isr(mraa::EDGE_RISING, &isrDecaExton, this);

	decaWKU = new mraa::Gpio(PIN_DECA_WKU);
	decaWKU->mode(mraa::MODE_STRONG);
	decaWKU->dir(mraa::DIR_OUT_LOW);

	decaRST = new mraa::Gpio(PIN_DECA_RST);
	decaRST->mode(mraa::MODE_STRONG);
	decaRST->dir(mraa::DIR_OUT_LOW);

	spiMaster_ = new SPI_Master(spi, decaCS);
}

void DecaAnchorBSL::initDecaIRQ(void (*fptr)(void*), QObject *par)
{
	decaIRQ->isr(mraa::EDGE_RISING, fptr, par);
}

void DecaAnchorBSL::isrDecaExton(void *args)
{
	qDebug() << "DecaExton";

	DecaAnchorBSL *bsl = static_cast<DecaAnchorBSL *>(args);

	/* handle deca exton */

	emit bsl->decaExton();
}

SPI_Master *DecaAnchorBSL::getSPIMaster()
{
	return spiMaster_;
}


void DecaAnchorBSL::initPWM()
{
	gpioRedPWM = new mraa::Pwm(PIN_RPWM);
	gpioGreenPWM = new mraa::Pwm(PIN_GPWM);
	gpioBluePWM = new mraa::Pwm(PIN_BPWM);

	int result =-1;
	result = gpioRedPWM->enable(true);
	result = gpioRedPWM->write(0);

	result = gpioGreenPWM->enable(true);
	result = gpioGreenPWM->write(0);

	result = gpioBluePWM->enable(true);
	result = gpioBluePWM->write(0);
}

void DecaAnchorBSL::rgbEnable(bool r, bool g, bool b)
{
	gpioRedPWM->enable(r);
	gpioGreenPWM->enable(g);
	gpioBluePWM->enable(b);
}

void DecaAnchorBSL::rgbPeriod(int r, int g, int b)
{
	gpioRedPWM->period_ms(r);
	gpioGreenPWM->period_ms(g);
	gpioBluePWM->period_ms(b);
}

void DecaAnchorBSL::rgbPulseWidth(int r, int g, int b)
{
	gpioRedPWM->pulsewidth_ms(r);
	gpioGreenPWM->pulsewidth_ms(g);
	gpioBluePWM->pulsewidth_ms(b);
}

void DecaAnchorBSL::rgbDutyCycle(float r, float g, float b)
{
	gpioRedPWM->write(r);
	gpioGreenPWM->write(g);
	gpioBluePWM->write(b);
}


void DecaAnchorBSL::initLeds()
{
	gpioL1 = new mraa::Gpio(PIN_L1);
	gpioL2 = new mraa::Gpio(PIN_L2);
	gpioL3 = new mraa::Gpio(PIN_L3);

	gpioL1->mode(mraa::MODE_STRONG);
	gpioL1->dir(mraa::DIR_OUT_LOW);

	gpioL2->mode(mraa::MODE_STRONG);
	gpioL2->dir(mraa::DIR_OUT_LOW);

	gpioL3->mode(mraa::MODE_STRONG);
	gpioL3->dir(mraa::DIR_OUT_LOW);
}

int DecaAnchorBSL::getLED(LedControls ledMask)
{
	switch (ledMask) {

	case L1:
		return gpioL1->read();
	case L2:
		return gpioL2->read();
	case L3:
		return gpioL3->read();
	default:
		return bslParamError;
	}
}

void DecaAnchorBSL::setLED(LedControls ledMask)
{
	if ((ledMask & L1) != LED_OFF) {
		gpioL1->write(LED_ON);
	} else {
		gpioL1->write(LED_OFF);
	}

	if ((ledMask & L2) != LED_OFF) {
		gpioL2->write(LED_ON);
	} else {
		gpioL2->write(LED_OFF);
	}

	if ((ledMask & L3) != LED_OFF) {
		gpioL3->write(LED_ON);
	} else {
		gpioL3->write(LED_OFF);
	}

}


void DecaAnchorBSL::initButtons()
{
	gpioPB1 = new mraa::Gpio(PIN_PB1);
	gpioPB2 = new mraa::Gpio(PIN_PB2);
	gpioPB3 = new mraa::Gpio(PIN_PB3);

	gpioPB1->mode(mraa::MODE_HIZ);
	gpioPB1->dir(mraa::DIR_IN);
	gpioPB1->isr(mraa::EDGE_BOTH, &isrPB1, this);

	gpioPB2->mode(mraa::MODE_HIZ);
	gpioPB2->dir(mraa::DIR_IN);
	gpioPB2->isr(mraa::EDGE_BOTH, &isrPB2, this);

	gpioPB3->mode(mraa::MODE_HIZ);
	gpioPB3->dir(mraa::DIR_IN);
	gpioPB3->isr(mraa::EDGE_BOTH, &isrPB3, this);
}

int DecaAnchorBSL::getBTN(BtnControls btnMask)
{
	switch (btnMask) {

	case PB1:
		return gpioPB1->read();
	case PB2:
		return gpioPB2->read();
	case PB3:
		return gpioPB3->read();
	default:
		return bslParamError;
	}
}

void DecaAnchorBSL::isrPB1(void *args)
{
	// Entprellung

	DecaAnchorBSL *bsl = static_cast<DecaAnchorBSL *>(args);

	/* TODO: remove, out = in */
	if (bsl->getBTN(PB1) == BTN_PRESS)
		bsl->setLED(L1);
	else
		bsl->setLED(LED_OFF);

	emit bsl->pb1Pressed();
}

void DecaAnchorBSL::isrPB2(void *args)
{
	// Entprellung

	DecaAnchorBSL *bsl = static_cast<DecaAnchorBSL *>(args);

	/* TODO: remove, out = in */
	if (bsl->getBTN(PB2) == BTN_PRESS)
		bsl->setLED(L2);
	else
		bsl->setLED(LED_OFF);

	emit bsl->pb2Pressed();
}

void DecaAnchorBSL::isrPB3(void *args)
{
	// Entprellung

	DecaAnchorBSL *bsl = static_cast<DecaAnchorBSL *>(args);

	/* TODO: remove, out = in */
	if (bsl->getBTN(PB3) == BTN_PRESS)
		bsl->setLED(L3);
	else
		bsl->setLED(LED_OFF);

	emit bsl->pb3Pressed();
}


void DecaAnchorBSL::initGPIO()
{
	//gpio0 = new mraa::Gpio(PIN_GP0);
	gpio1 = new mraa::Gpio(PIN_GP1);
}

int DecaAnchorBSL::getGPIO(GpioControls gpNbr, mraa::Gpio *gpPtr)
{
	switch (gpNbr) {
	case GP0:
		gpPtr = gpio0;
	case GP1:
		gpPtr = gpio1;
	default:
		return bslParamError;
	}

	return bslSuccess;
}


/**/


void DecaAnchorBSL::initUART()
{

}


void DecaAnchorBSL::initI2C()
{
	i2c = new mraa::I2c(1);
	if (i2c->address(I2C_GAUGE_ADDR) != 0)
		return;
	i2c->frequency((mraa_i2c_mode_t)0);

	qDebug() << "---------- I2C INIT ------------\n";

//    quint8 len = 2;
//    quint8 rxBuf[2] = {0xFF, 0xFF};

//    qDebug() << "Result  : " << i2c->readBytesReg(I2C_GAUGE_STAT, &rxBuf[0], len);
//    qDebug() << "STATUS  : " << rxBuf[0]; //<< i2c->readReg(I2C_GAUGE_STAT);
//    qDebug() << "CONTROL : " << rxBuf[1]; //<< i2c->readReg(I2C_GAUGE_CTRL);

	timer = new QTimer(this);
	QObject::connect(timer, &QTimer::timeout, this, &DecaAnchorBSL::readI2C);
	timer->setSingleShot(false);

	timer->start(2000);
}

void DecaAnchorBSL::readI2C()
{
	toggleLed();

	quint8 stat = 0x55;
	i2c->address(I2C_GAUGE_ADDR);
	i2c->writeByte(0x00);
	i2c->address(I2C_GAUGE_ADDR);
	stat = i2c->readByte();

	qDebug() << "Status: " << stat;
}


void DecaAnchorBSL::cleanSpiBuffers(){
	cleanSpiRxBuffer();
	cleanSpiTxBuffer();
}

void DecaAnchorBSL::cleanSpiTxBuffer(){
	for(quint8 i = 0; i < SPI_BUFFER_SIZE; i++){
		txBuf[i] = 0;
	}
}

void DecaAnchorBSL::cleanSpiRxBuffer(){
	for(quint8 i = 0; i < SPI_BUFFER_SIZE; i++){
		rxBuf[i] = 0;
	}
}

void DecaAnchorBSL::outputSpiRxBuffer(int byteCount){
	int end;
	if (byteCount >= 0) {
		end = byteCount;
	} else {
		end = SPI_BUFFER_SIZE;
	}

	qDebug () << "=======SPI Rx buf:=============";
	for (quint8 index = 0; index < end; index++){
		qDebug () << rxBuf[index];
	}
}


void DecaAnchorBSL::toggleLed()
{
	if (gpioL2->read() == LED_OFF)
		gpioL2->write(LED_ON);
	else
		gpioL2->write(LED_OFF);
}
