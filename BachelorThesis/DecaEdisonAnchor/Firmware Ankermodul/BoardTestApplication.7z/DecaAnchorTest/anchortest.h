#ifndef ANCHORTEST_H
#define ANCHORTEST_H

#include <QDebug>
#include <QTimer>
#include "decaanchorbsl.h"

class AnchorTest : public QObject
{
	Q_OBJECT

public:
	AnchorTest(QObject *parent);
	~AnchorTest();

private slots:
	void slPb1();
	void slPb2();
	void slPb3();
	void slGaAl();
	void slChDo();
	void slDeEx();
	void rgbTimer();

private:
	void testDecawave();
	void testSPIperformance();

	DecaAnchorBSL *bsl;
	SPI_Master *spimaster;
	QTimer *timer;

	float r, g, b, sr, sg, sb;
	int rgb;
};

#endif // ANCHORTEST_H
