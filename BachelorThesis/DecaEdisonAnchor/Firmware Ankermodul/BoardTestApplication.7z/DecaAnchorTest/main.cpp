#include <QCoreApplication>
#include "anchortest.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

	AnchorTest test(qApp);

    return a.exec();
}
