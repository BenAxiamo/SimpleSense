#include "anchortest.h"

#define SPI_PERF_CYCLES 1000
#define SPI_PERF_BYTES 127

AnchorTest::AnchorTest(QObject *parent)
{
	qDebug() << "<<< Welcome to the EdisonDecaAnchor board test! >>>";

	bsl = new DecaAnchorBSL(parent);

	QObject::connect(bsl, SIGNAL(pb1Pressed()), this, SLOT(slPb1()));
	QObject::connect(bsl, SIGNAL(pb2Pressed()), this, SLOT(slPb2()));
	QObject::connect(bsl, SIGNAL(pb3Pressed()), this, SLOT(slPb3()));

	QObject::connect(bsl, SIGNAL(gaugeAlert()), this, SLOT(slGaAl()));
	QObject::connect(bsl, SIGNAL(chargeDone()), this, SLOT(slChDo()));
	QObject::connect(bsl, SIGNAL(decaExton()), this, SLOT(slDeEx()));

	/* read deca device id */
	spimaster = bsl->getSPIMaster();
	testDecawave();

	/* communicate with power gauge */

	/* mess around with voltages and levelshifters */
//	bsl->enablePC3V3(false);
//	bsl->enablePC5V0(false);
//	bsl->enableLS1(false);
//	bsl->enableLS2(false);
//	testDecawave();

	/* initiate some pwm magic */
	bsl->rgbPeriod(10,10,10);
	rgb = 0;
	sr = sg = sb = r = g = b = 0.005;
	timer = new QTimer();
	QObject::connect(timer, SIGNAL(timeout()), this, SLOT(rgbTimer()));
	timer->setInterval(50);
	timer->setSingleShot(false);
	timer->start();
}

AnchorTest::~AnchorTest()
{
	timer->stop();
	delete timer;
	delete bsl;
}

void AnchorTest::testDecawave()
{
	unsigned char txBuf = DEV_ID_ID;
	unsigned char rxBuf[DEV_ID_LEN];
	if (spimaster->transfer(&txBuf, 1, &rxBuf[0], DEV_ID_LEN) == -1) {
		qDebug() << "problem with spi/decawave";
	}
	else {
		if ((rxBuf[3] == 222) && (rxBuf[2] == 202) &&
			(rxBuf[1] == 1) && (rxBuf[0] == 48)) {
			qDebug() << "0xDECA0130";
		}

		for (int i = DEV_ID_LEN; i > 0; i--) {
			qDebug() << rxBuf[i-1];
		}
	}
}

void AnchorTest::testSPIperformance()
{
	int i, j;
	uint8_t tx[SPI_PERF_BYTES];

	qDebug() << ">>> SPI Performance Test";

	for (i = 0; i < SPI_PERF_BYTES; i++) {
		tx[i] = 0x89;
	}

	for (j = 32; j <= SPI_PERF_BYTES; j++) {
		for (i = 0; i < SPI_PERF_CYCLES; i++) {
			if (spimaster->transfer(&tx[0], j, NULL, 0) == -1) {
				qDebug() << " spi transfer error";
			}
		}
		qDebug() << "spi transfer complete (bytes/cyles) : " << j << " / " << i;
	}
}

void AnchorTest::slPb1()
{
	qDebug() << " received signal: pb1";

//	bsl->enableLS2(true);
//	bsl->enableLS1(true);
//	bsl->enablePC5V0(true);
//	bsl->enablePC3V3(true);

	//testSPIperformance();
}

void AnchorTest::slPb2()
{
	qDebug() << " received signal: pb2";
}

void AnchorTest::slPb3()
{
	qDebug() << " received signal: pb3";
}

void AnchorTest::slGaAl()
{
	qDebug() << " received signal: gauge alert";
}

void AnchorTest::slChDo()
{
	qDebug() << " received signal: charge done";
}

void AnchorTest::slDeEx()
{
	qDebug() << " received signal: deca exton";
	//testDecawave();
	//testSPIperformance();
}

void AnchorTest::rgbTimer()
{
	//qDebug() << "timer here, r = " << r;

	if(r > 0.1 ){
		sr = -0.005;
	}
	if(r < 0 ){
		sr = 0.005;
	}
	r += sr;

	if ((rgb % 3) == 0) {
		if(g > 0.1 ){
			sg = -0.005;
		}
		if(g < 0 ){
			sg = 0.005;
		}
		g += sg;
	}

	if ((rgb % 9) == 0) {
		if(b > 0.1 ){
			sb = -0.005;
		}
		if(b < 0 ){
			sb = 0.005;
		}
		b += sb;
	}

	rgb++;

//	qDebug() << "r: " << r;
//	qDebug() << "g: " << g;
//	qDebug() << "b: " << b;

	bsl->rgbDutyCycle(r,g,b);
}
