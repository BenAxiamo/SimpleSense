#ifndef CUSTOMINCREMENTTIMER_H
#define CUSTOMINCREMENTTIMER_H

#include <QThread>

enum Increments {
	FAST_INCREMENT = 1000,
	TIMEOUT_INCREMENT = 4000,
	ERROR_INCREMENT = 20000
};

class CustomIncrementTimer : public QThread
{
	Q_OBJECT

public:
	CustomIncrementTimer();
	void setIncrement(uint16_t msInc);

signals:
	void timeout();

private:
	void run();

	uint16_t increment;
	uint32_t i;
};

#endif // CUSTOMINCREMENTTIMER_H
