#include "edisondecaanchor.h"

EdisonDecaAnchor* anchor_;

EdisonDecaAnchor::EdisonDecaAnchor()
{

}

EdisonDecaAnchor::~EdisonDecaAnchor()
{
	qDebug() << "Destructor EdisonDecaAnchor Start";

//	timer_->deleteLater();
//	client_->deleteLater();
//	bsl_->deleteLater();
	delete timer_;
	delete uwb_;
	delete bsl_;
	delete client_;

	qDebug() << "Destructor EdisonDecaAnchor Stop";
}

void EdisonDecaAnchor::initEdisonDecaAnchor()
{
	qDebug() << QObject::tr("Axiamo Positioning Network Client Application") << "\n";

	timerCount = 0;

	/* Anchor */
//	decaNID = 0x00000303ACED0404;
//	decaEUI = 0x7D0022EA82603B9E;
//	DecaRole role = ROLE_ANCHOR;
	/* Tag */
//	decaNID = 0x00000404ACED0303;
//	decaEUI = 0x7D0022EA82603B9F;
//	DecaRole role = ROLE_TAG;

//	QSettings settings(QSettings::UserScope, "Axiamo", "DecaClient");
//	settings.setValue("uwbdw1000/nid", decaNID);
//	settings.setValue("uwbdw1000/eui", decaEUI);
//	settings.setValue("uwbdw1000/role", role);

	QSettings settings(QSettings::UserScope, "Axiamo", "DecaClient");
	qDebug() << settings.fileName();

	if (settings.contains("uwbdw1000/nid"))
		qDebug() << "NID Settings exist";

	if (settings.contains("uwbdw1000/eui"))
		qDebug() << "EUI Settings exist";

	if (settings.contains("uwbdw1000/role"))
		qDebug() << "ROLE Settings exist";

	anchorName = settings.value("eddie/name", "eddie6").value<QString>();
	decaNID = settings.value("uwbdw1000/nid", 0x00000303ACED0404).value<uint64_t>();
	decaEUI = settings.value("uwbdw1000/eui", 0x7D0022EA82603B9E).value<uint64_t>();
	DecaRole role = (DecaRole) settings.value("uwbdw1000/role", ROLE_ANCHOR).value<int>();
	qDebug() << "Role: " << role;


	client_ = new Client();
	bsl_ = new DecaAnchorBSL(qApp);
	spiMaster_ = bsl_->getSPIMaster();
	uwb_ = new UWBDW1000(spiMaster_);
	timer_ = new QTimer();
	thrTimer = new CustomIncrementTimer();

	bsl_->initDecaIRQ(&decaInterrupt, this);

	uwb_->Initialize(role);

	connect(thrTimer, SIGNAL(timeout()), this, SLOT(decaTimer()));
	thrTimer->setIncrement(FAST_INCREMENT);
	thrTimer->start();

	bsl_->setLED(L1);

//	client_->setupServerConnection();

//	if (client_->sendDistanceMessage("AX", 55, "0080") != cSuccess) {
//		qDebug() << QObject::tr("Error in sending");
//	}
}

void EdisonDecaAnchor::calculatedDistance(float distance)
{
	QString strTimestamp = QString::number(QDateTime::currentMSecsSinceEpoch());
	client_->sendDistanceMessage("EddieDecaAnchor", distance, strTimestamp);
}

uint8_t EdisonDecaAnchor::setNextTimerTime(uint16_t msec)
{
	qDebug() << QObject::tr("decaTimer start") << msec;

	thrTimer->setIncrement(msec);

	//qDebug() << QObject::tr("decaTimer started");

	return 0;
}


uint8_t EdisonDecaAnchor::RGBColorSet(uint8_t color)
{
	//TODO

	//qDebug() << "LED COLOR";

	return 0;
}


uint8_t* EdisonDecaAnchor::getSettingsDecaEUI()
{
	return (uint8_t*) &decaEUI;
}


uint64_t EdisonDecaAnchor::getSettingsDecaNID()
{
	return decaNID;
}


void EdisonDecaAnchor::decaTimer()
{
	//qDebug() << QObject::tr("decaTimer here: ") << ++timerCount;

	switch (uwb_->_role) {
	case ROLE_ANCHOR:
		uwb_->stepAnchorStateMachine(EVENT_TYPE_TIMER, MSG_TYPE_NONE);
		break;
	case ROLE_TAG:
		uwb_->stepTagStateMachine(EVENT_TYPE_TIMER, MSG_TYPE_NONE);
		break;
	default:
		//TODO proper error handling
		break;
	}

	//qDebug() << QObject::tr("decaTimer left");
}

void EdisonDecaAnchor::decaInterrupt(void *args)
{
	/* TODO: parameter check */

	EdisonDecaAnchor *eda = static_cast<EdisonDecaAnchor *>(args);
	//qDebug() << QObject::tr("decaISR here") << " eda: " << eda;

	// possibly also call with : anchor_

	EventType eventType = eda->uwb_->getIRQEvent();
	MsgType msgType = eda->uwb_->getMessageType();
	qDebug() << "EVT: " << eventType << ", MSG: " << msgType;

	switch (eda->uwb_->_role) {
	case ROLE_ANCHOR:
		eda->uwb_->stepAnchorStateMachine(eventType, msgType);
		break;
	case ROLE_TAG:
		eda->uwb_->stepTagStateMachine(eventType, msgType);
		break;
	default:
		//TODO proper error handling
		break;
	}

	//qDebug() << QObject::tr("decaISR left");
}
