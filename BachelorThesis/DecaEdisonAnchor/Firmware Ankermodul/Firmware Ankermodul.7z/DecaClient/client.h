#ifndef CLIENT_H
#define CLIENT_H
/****************************************************************************
*  Header     : Client                  Version 1.0   *
*****************************************************************************
*                                                                           *
*  Function   :                  *
*                                                                           *
*                                                                           *
*  Methodes   :                           *
*                                                                           *
*  Author     : bunto1                                                      *
*                                                                           *
*  History    : 26.05.2016  bo Created                                      *
*                                                                           *
*  File       : main.cpp                                                    *
*                                                                           *
*****************************************************************************
* BFH TI Biel / Axiamo                                                      *
****************************************************************************/

/* imports */
#include <QtNetwork>
#include <QTcpSocket>
#include <QTimer>

#include "../lib/tcpipprotocol.h"

/* Class constant declaration  */

/* Class Type declaration      */
enum TcpConnectionState {
    TcpUnconnected,
    TcpConnecting,
    TcpConnected,
    TcpClosing,
    TcpError
};

enum TcpClient{
    cSuccess,
    cPending,
    cErrAlreadyInUse,
    cErrNoConnection,
    cErrUndefined
};

/* Class data declaration      */

/* Class definition            */

QT_BEGIN_NAMESPACE
class QTcpSocket;
class QNetworkSession;
QT_END_NAMESPACE

class Client : public QObject
{
    Q_OBJECT

public:
    Client();
    ~Client();
    void setAnchorName(QString name);
    TcpConnectionState getConnectionState();
    void closeServerConnection();
    TcpClient sendDistanceMessage(QString nameTag, double valueDistance, QString strTimestamp);
    TcpClient sendSensorDataMessage(QString nameTag, quint16 *sensorDataBuffer, quint16 dataBytes, QString strTimestamp);
    TcpClient sendControlMessage(quint16 ctrl, QString strTimestamp);

public slots:
    TcpClient setupServerConnection();

private slots:
    void sendKeepaliveMessage();
    void sendTimedDummyDistanceMessage();
    void connectedToServer();
    void readServerMessage();
    void displayServerError(QAbstractSocket::SocketError socketError);
    void networkSessionOpened();

private:
    TcpClient sendTcpMessage(QString msg, quint16 *data, quint16 bytes);
    void writeSettings();
    void readSettings();
    void promptNewServerSettings();
    void testDataRate(quint16 messageCount, quint16 msInterval);

    QTcpSocket *tcpSocket;
    QTimer *timer;
    QNetworkSession *networkSession;
    QTextStream cout;
    QTextStream cin;

    QString nameAnchor;

    QString tcpServerMessage;
    QString tcpAddress;
    quint16 tcpPort;
    quint16 tcpInBlockSize;

    quint16 tcpInMsgCount;
    quint16 tcpOutMsgCount;

};

#endif // CLIENT_H
