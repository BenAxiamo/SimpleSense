#include "customincrementtimer.h"

CustomIncrementTimer::CustomIncrementTimer()
{
	increment = TIMEOUT_INCREMENT;
	i = 0;
}

void CustomIncrementTimer::setIncrement(uint16_t msInc)
{
	increment = msInc;
	i = 0;
}

void CustomIncrementTimer::run()
{
	while (1) {
		for (i = 0; i < increment; i++) {
			usleep(1000);
		}
		emit this->timeout();
		increment = TIMEOUT_INCREMENT;
	}
}
