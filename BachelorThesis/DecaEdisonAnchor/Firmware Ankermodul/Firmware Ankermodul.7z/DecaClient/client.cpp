/***************************************************************************/
/*! \file       client.cpp                                                  *
*****************************************************************************
*
* \brief        This file contains the implemention of the Class Client.
*               This class handles a tcp/ip client connection to a Server
*               which is run by the ServerApplication_SNS.
*               <br>
*               Once the client is connected to the server, the client
*               should transmit positioning data to the server.
*
* Methodes:
* <br>          Client()
* <br>          void writeSettings()
* <br>          void readSettings()
* <br>          void setupServerConnection()
* <br>          void readServerMessage()
* <br>          void connectedToServer()
* <br>          void sendDummyPositionMessage()
* <br>          void sendPositionMessage(QString nameAnchor,
*                       QString nameTag, quint16 valueDistance,
*                       QString strTimestamp)
* <br>          void displayError(QAbstractSocket::SocketError socketError)
* <br>          void sessionOpened()
*
* \author       bunto1
*
* \version      0.0.1
*
* \history      26.05.2016 - bunto1 - Created
*
* \ingroup      tcpip
*
* \todo         Choice of tcp/ip-address (Settings/Available/whatever)
* <br>          Error visualization
* <br>          Handle closing connection
*
* \bug
*/
/****************************************************************************
* BFH TI Biel / Axiamo                                                      *
****************************************************************************/

/* imports */
#include <QDebug>
#include "client.h"

/* Class constant declaration  */
#define TMR_TCP_SETUP   2000
#define TMR_KEEPALIVE   5000          // To test rate&range, later ~5000?

    /*!< Registers, whatever */

/* Class Type declaration      */

/* Class data declaration      */

/* Class definition            */

/****************************************************************************
* Constructor:  Client                                                      *
****************************************************************************/
Client::Client()
    : tcpSocket(new QTcpSocket(qApp))
    , timer(new QTimer(qApp))
    , networkSession(Q_NULLPTR)
    , cout(stdout)
    , cin(stdin)
    , nameAnchor("eddie")
    , tcpInBlockSize(0)
    , tcpInMsgCount(0)
    , tcpOutMsgCount(0)
{

    // set up the settings
    readSettings();

    // find out name of this machine
    QString name = QHostInfo::localHostName();
    if (!name.isEmpty()) {
        QString domain = QHostInfo::localDomainName();
        if (!domain.isEmpty())
            qDebug() << "Host: " << name << "@" << domain;
        else
            qDebug() << "Host: " << name;
    }
    if (name != QLatin1String("localhost"))
       qDebug() << "localhost";

    // find out IP addresses of this machine
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();

    // add non-localhost addresses
    qDebug() << "\nnon-localhost addresses: ";
    for (int i = 0; i < ipAddressesList.size(); ++i) {
        if (!ipAddressesList.at(i).isLoopback())
            qDebug() << ipAddressesList.at(i).toString();
    }

    // add localhost addresses
    qDebug() << "\nlocalhost addresses: ";
    for (int i = 0; i < ipAddressesList.size(); ++i) {
        if (ipAddressesList.at(i).isLoopback())
            qDebug() << ipAddressesList.at(i).toString();
    }

    typedef void (QAbstractSocket::*QAbstractSocketErrorSignal)(QAbstractSocket::SocketError);
    QObject::connect(tcpSocket, static_cast<QAbstractSocketErrorSignal>(&QAbstractSocket::error), this, &Client::displayServerError);

    QObject::connect(tcpSocket, &QTcpSocket::connected, this, &Client::connectedToServer);
    QObject::connect(tcpSocket, &QIODevice::readyRead, this, &Client::readServerMessage);

    // Check if target device requires a networkSession
    QNetworkConfigurationManager manager;
    if (manager.capabilities() & QNetworkConfigurationManager::NetworkSessionRequired) {

        // Get saved network configuration
        QSettings settings(QSettings::UserScope, QLatin1String("Axiamo"));
        settings.beginGroup(QLatin1String("QtNetwork"));
        const QString id = settings.value(QLatin1String("DefaultNetworkConfiguration")).toString();
        settings.endGroup();

        // If the saved network configuration is not currently discovered use the system default
        QNetworkConfiguration config = manager.configurationFromIdentifier(id);
        if ((config.state() & QNetworkConfiguration::Discovered) !=
            QNetworkConfiguration::Discovered) {
            config = manager.defaultConfiguration();
        }

        networkSession = new QNetworkSession(config);
        QObject::connect(networkSession, &QNetworkSession::opened, this, &Client::networkSessionOpened);

        qDebug() << tr("Opening network session.");
        networkSession->open();
    }
}

/****************************************************************************
* Destructor:  ~Client                                                      *
****************************************************************************/
Client::~Client()
{
	qDebug() << "Destructor Client Start";

	tcpSocket->deleteLater();
	networkSession->deleteLater();
	timer->deleteLater();

	qDebug() << "Destructor Client Stop";
}

/****************************************************************************
* Function:  setAnchorName                                                  *
****************************************************************************/
/*! \brief Sets the internal name of the Anchor
*
* Function : This function overwrites the internal saved name of the Client
*               (Anchor) with the specified String name
*
* \param[in] QString name - newly saved name
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
****************************************************************************/
void Client::setAnchorName(QString name)
{
    nameAnchor = name;
}

/****************************************************************************
* Function:  getConnectionState                                             *
****************************************************************************/
/*! \brief Returns the state of the tcp connection
*
* Function : This function returns the state of the tcp connection depending
*               on the tcpSockets state.
*
* \return TcpConnectionState - state of the connection (enum)
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
****************************************************************************/
TcpConnectionState Client::getConnectionState()
{
    switch (tcpSocket->state()) {

    case QAbstractSocket::UnconnectedState:
        return TcpUnconnected;

    case QAbstractSocket::HostLookupState:
    case QAbstractSocket::ConnectingState:
        return TcpConnecting;

    case QAbstractSocket::ConnectedState:
        return TcpConnected;

    case QAbstractSocket::ClosingState:
        return TcpClosing;

    default:
        return TcpError;
    }

    return TcpError;
}

/****************************************************************************
* Function:  closeServerConnection                                          *
****************************************************************************/
/*! \brief Closes open tcp connection
*
* Function : This function closes the tcp connection if it isn't
*               unconnected already
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
****************************************************************************/
void Client::closeServerConnection()
{
    if (getConnectionState() != TcpUnconnected)
        tcpSocket->abort();
}

/****************************************************************************
* Public SLOT:  setupServerConnection                                       *
****************************************************************************/
/*! \brief Public Slot, either called manually or by timer
*
* Function : This function tries to setup a tcp connection to the saved
*               combination of address and port. At first, the socket state
*               gets checked to prevent multiple connection attempts.
*
* \return TcpClient - feedback on the connection setup
* <br>                  cErrAlreadyInUse: the socket is already in use
* <br>                  cPending: the setup was successful so far,
*                                   connection is pending
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
*
* \todo move writeSettings() call out of this function
*
****************************************************************************/
TcpClient Client::setupServerConnection()
{
    if (getConnectionState() != TcpUnconnected) {
        qDebug() << tr("Socket already in use, quit new setup");
        return cErrAlreadyInUse;
    }

    if (timer->isActive()) {
        timer->stop();
        qDebug() << tr("Stopping timer");
    }

    qDebug() << "\nAddress: "<< tcpAddress;
    qDebug() << "Port: " << tcpPort;

    qDebug() << tr("->> request server connection:");

    tcpInBlockSize = 0;
    tcpSocket->abort();

	//tcpSocket->connectToHost("147.87.129.13", tcpPort);
	tcpSocket->connectToHost(tcpAddress, tcpPort);

    /* vilech de eher im close oder connected server teil */
    writeSettings();

    return cPending;
}

/****************************************************************************
* Function:  sendTcpMessage                                                 *
****************************************************************************/
/*! \brief Sending a distance message to the tcp server
*
* Function : This function sends a specified message to a tcp server.
*               Before sending, connectionState is tested.
*               in addition to the msg, the message length gets sent before
*
* \param[in] QString msg - Message to send
*
* \return TcpClient - feedback from the TcpSocket about operation success
*                       cErrNoConnection: No Connection to the server
*                       cSuccess: Operation successful
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
*
* \todo maybe implement sending of timestamp here
* <br> remove msgCount limit
*
****************************************************************************/
TcpClient Client::sendTcpMessage(QString msg, quint16 *data = 0, quint16 bytes = 0)
{
    if (getConnectionState() != TcpConnected)
        return cErrNoConnection;

//    /* To test connection, remove later */
//    if (tcpOutMsgCount > 1000)
//        return cErrUndefined;

    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_0);

    out << (quint16)0;
    out << (QString)msg;

    if (bytes != 0) {
        out << bytes;

        for (; bytes > 0; bytes--) {
            out << *data;
            data++;
        }
    }

    out.device()->seek(0);
    out << (quint16)(block.size() - sizeof(quint16));

    tcpSocket->write(block);

    tcpOutMsgCount++;

    return cSuccess;
}

/****************************************************************************
* Function:  sendDistanceMessage                                            *
****************************************************************************/
/*! \brief Sending a distance message to the tcp server
*
* Function : This function sends a message with a distance value to the
*               tcp server. This message contains a Prefix, the name of the
*               anchor, the name of the tag the distance was measured to,
*               the distance value and a timestamp.
*
* \param[in] QString nameTag - name of the tag
* \param[in] double valueDistance - measured distance
* \param[in] QString strTimestamp - timestamp to append to the message
*
* \return TcpClient - feedback from the TcpSocket about operation success
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
*
* \todo maybe implement timestamp in the sendTcpMessage() function
*
****************************************************************************/
TcpClient Client::sendDistanceMessage(QString nameTag, double valueDistance, QString strTimestamp)
{
    if (getConnectionState() != TcpConnected)
        return cErrNoConnection;

    QStringList stList;
    stList << QString::number(PREF_DISTANCE) << nameAnchor
           << nameTag << QString::number(valueDistance) << strTimestamp;

    return sendTcpMessage(stList.join(TCP_SEPARATOR));
}

/****************************************************************************
* Function:  sendSensorDataMessage                                          *
****************************************************************************/
/*! \brief Sending a sensor-data message to the tcp server
*
* Function : This function sends a message with a sensor data values to the
*               tcp server. This message contains a Prefix, the name of the
*               anchor, the name / id of the sensor, max. 16x16bits data of
*               the sensor, the number of data bytes and a timestamp.
*
* \param[in] QString nameTag - name of the tag
* \param[in] quint16 *sensorDataBuffer - pointer to data buffer
* \param[in] quint16 dataBytes - number of data bytes in buffer (max. 16)
* \param[in] QString strTimestamp - timestamp to append to the message
*
* \return TcpClient - feedback from the TcpSocket about operation success
*
* \author bunto1
*
* \version 0.0.1
*
* \date 07.06.16 - bunto1 - Created
*
*
* \todo maybe implement timestamp in the sendTcpMessage() function
*
****************************************************************************/
TcpClient Client::sendSensorDataMessage(QString nameTag, quint16 *sensorDataBuffer,
                                        quint16 dataBytes, QString strTimestamp)
{
    if (getConnectionState() != TcpConnected)
        return cErrNoConnection;

    QStringList stList;
    stList << QString::number(PREF_SENSORDATA)
           << nameAnchor
           << nameTag
           << strTimestamp;

    return sendTcpMessage(stList.join(TCP_SEPARATOR), sensorDataBuffer, dataBytes);
}

/****************************************************************************
* Function:  sendControlMessage                                             *
****************************************************************************/
/*! \brief Sending a control message to the tcp server
*
* Function : This function sends a defined control message to the tcp server.
*               This message contains a Prefix, the name of the anchor,
*               the specified Control-Sequence and a timestamp.
*
* \param[in] ClientControlMsg type - defines type of control message
* \param[in] QString strTimestamp - timestamp to append to the message
*
* \return TcpClient - feedback from the TcpSocket about operation success
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
*
* \todo maybe implement timestamp in the sendTcpMessage() function
*
****************************************************************************/
TcpClient Client::sendControlMessage(quint16 ctrl, QString strTimestamp)
{
    if (getConnectionState() != TcpConnected)
        return cErrNoConnection;

    QStringList stList;
    stList << QString::number(PREF_CONTROL) << nameAnchor;
    stList << QString::number(ctrl);
    stList << strTimestamp;

    return sendTcpMessage(stList.join(TCP_SEPARATOR));
}

/****************************************************************************
* SLOT:      sendKeepaliveMessage                                           *
****************************************************************************/
/*! \brief Slot to use from a timer, sends a periodic keepalive message
*
* Function : This function sends a keepalive message to the tcp server.
*               This message contains a Prefix, the name of the anchor
*               and a generated timestamp.
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
*
* \todo redefine timestamp
* <br>  maybe public and with TcpClient return value
*
****************************************************************************/
void Client::sendKeepaliveMessage()
{
    if (getConnectionState() != TcpConnected)
        return;

//    QDateTime time(QDateTime::currentDateTime());

//    QString strTimestamp = QString::number(time.toTime_t());

    QString strTimestamp = QString::number(QDateTime::currentMSecsSinceEpoch());

    QStringList stList;
    stList << QString::number(PREF_KEEPALIVE) << nameAnchor << strTimestamp;

    sendTcpMessage(stList.join(TCP_SEPARATOR));

    return;
}

/****************************************************************************
* SLOT:      sendTimedDummyDistanceMessage                                  *
****************************************************************************/
/*! \brief Slot to use from a timer, sends periodically a dummy message
*
* Function : This function sends a test distance message to the server, then
*               triggers himself for another message after a specified delay
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 29.05.16 - bunto1 - Created
*
*
* \todo delete when not used anymore
*
****************************************************************************/
void Client::sendTimedDummyDistanceMessage()
{
    sendDistanceMessage(tr("axiamote"),tcpOutMsgCount,QString::number(tcpOutMsgCount*2));
    QTimer::singleShot(300,this,SLOT(sendTimedDummyDistanceMessage()));
}

/****************************************************************************
* SLOT:      connectedToServer                                              *
****************************************************************************/
/*! \brief Slot who gets called when TcpConnection is established
*
* Function : In this function, a (Debug)-Hello-message is sent to the server
*               to check the connection. This should be replaced/deleted
*               later.
*               A timer is started to trigger the periodic Keepalive
*               messages.
*
* \param None
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 29.05.16 - bunto1 - Created
*
*
* \todo remove Hello message
* <br>  ev. add return
*
****************************************************************************/
void Client::connectedToServer()
{
    sendControlMessage(CTRL_FIRST_TX, QString::number(QDateTime::currentMSecsSinceEpoch()));

    qDebug() << tr("starting keepalive-timer");

    QObject::disconnect(timer, &QTimer::timeout, 0, 0);
    QObject::connect(timer, &QTimer::timeout, this, &Client::sendKeepaliveMessage);
    timer->setSingleShot(false);

    timer->start(TMR_KEEPALIVE);
}

/****************************************************************************
* SLOT:      readServerMessage                                              *
****************************************************************************/
/*! \brief Slot who's called when bytes are received via TcpConnection
*
* Function : Reading available bytes from the Tcp Connection
*
* \param None
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 29.05.16 - bunto1 - Created
*
*
* \todo parsing the message
*
****************************************************************************/
void Client::readServerMessage()
{
    QDataStream in(tcpSocket);
    in.setVersion(QDataStream::Qt_4_0);

    if (tcpInBlockSize == 0) {
        if (tcpSocket->bytesAvailable() < (int)sizeof(quint16))
            return;

        in >> tcpInBlockSize;
    }

    if (tcpSocket->bytesAvailable() < tcpInBlockSize)
        return;

    in >> tcpServerMessage;

    qDebug() << tcpServerMessage;
}

/****************************************************************************
* SLOT:      displayServerError                                             *
****************************************************************************/
/*! \brief Slot who's called on errors from the TcpSocket
*
* Function : Reacting to errors from the TcpSocket
*
* \param[in] QAbstractSocket::SocketError socketError - defines kind of error
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 29.05.16 - bunto1 - Created
*
*
* \todo ev. add hardware visualisation
*
****************************************************************************/
void Client::displayServerError(QAbstractSocket::SocketError socketError)
{
    qDebug() << "\n!! An error occurred !!";

    //QObject::disconnect(timer, &QTimer::timeout, 0, 0);
    QObject::connect(timer, &QTimer::timeout, this, &Client::setupServerConnection, Qt::UniqueConnection);
    timer->setSingleShot(true);

    switch (socketError) {
    case QAbstractSocket::RemoteHostClosedError:
        tcpOutMsgCount = 0;
        tcpInMsgCount = 0;
        timer->start(TMR_TCP_SETUP);
        qDebug() << tr("The remote host closed the connection.");
        break;

    case QAbstractSocket::HostNotFoundError:
        timer->start(TMR_TCP_SETUP);
        qDebug() << tr("The host was not found.");
        promptNewServerSettings();
        break;

    case QAbstractSocket::ConnectionRefusedError:
        timer->start(TMR_TCP_SETUP);
        qDebug() << tr("The connection was refused by the peer.");
        break;

    default:
        qDebug() << tr("The following error occurred: ") << tcpSocket->errorString();
    }
}

/****************************************************************************
* SLOT:      networkSessionOpened                                           *
****************************************************************************/
/*! \brief Slot who's called when a network session is opened
*
* Function : The used (and working) configurations are saved in QSettings
*
* \param None
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 29.05.16 - bunto1 - Created
*
*
* \todo maybe clean Settings
*
****************************************************************************/
void Client::networkSessionOpened()
{
    // Save the used configuration
    QNetworkConfiguration config = networkSession->configuration();
    QString id;
    if (config.type() == QNetworkConfiguration::UserChoice)
        id = networkSession->sessionProperty(QLatin1String("UserChoiceConfiguration")).toString();
    else
        id = config.identifier();

    QSettings settings(QSettings::UserScope, QLatin1String("QtProject"));
    settings.beginGroup(QLatin1String("QtNetwork"));
    settings.setValue(QLatin1String("DefaultNetworkConfiguration"), id);
    settings.endGroup();

    qDebug() << "\nNetwork session successfully opened.\n";
}

/****************************************************************************
* Function:  writeSettings                                                  *
****************************************************************************/
/*! \brief Writing of application settings using QSettings
*
* Function : This function writes values for tcpip address & port
*               in the device specific settings-storage using the
*               QSettings class.
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 29.05.16 - bunto1 - Created
*
*
* \todo add additional values or multiple addresses
*
****************************************************************************/
void Client::writeSettings()
{
    QSettings settings(QSettings::UserScope, "Axiamo", "DecaClient");

    settings.setValue("tcpip/address", tcpAddress);
    settings.setValue("tcpip/port", tcpPort);
}

/****************************************************************************
* Function:  readSettings                                                   *
****************************************************************************/
/*! \brief Reading of application settings using QSettings
*
* Function : This function reads values for tcpip address & port
*               out of the device specific settings-storage using the
*               QSettings class.
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 29.05.16 - bunto1 - Created
*
*
* \todo add additional values or multiple addresses
*
****************************************************************************/
void Client::readSettings()
{
    QSettings settings(QSettings::UserScope, "Axiamo", "DecaClient");

    if (settings.contains("tcpip/address"))
        qDebug() << "Address Settings exist";
    else
        qDebug() << "Address Settings doesn't exist";

    if (settings.contains("tcpip/port"))
        qDebug() << "Port Settings exist";
    else
        qDebug() << "Port Settings doesn't exist";

	tcpAddress = "192.168.43.175"; // settings.value("tcpip/address", "192.168.43.175").value<QString>();
    tcpPort = settings.value("tcpip/port", 42424).toInt();
    qDebug() << "Saved Address: " << tcpAddress;
    qDebug() << "Saved Port: " << tcpPort;
}

/****************************************************************************
* Function:  promptNewServerSettings                                        *
****************************************************************************/
/*! \brief Prompts the user for a new Tcp address
*
* Function : This function prompts the user on the console for a new
*               address to connect to. Press only <RETURN> to retry
*               the current address
*
* \param None
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 03.06.16 - bunto1 - Created
*
*
* \todo either open a new thread for this or delete the function
*
****************************************************************************/
void Client::promptNewServerSettings()
{
    QString newAddress;
//    quint16 newPort;

//    cout << tr("Enter new Address and Port to connect to. \nTo retry with current settings, press <RETURN> twice");
    cout << tr("\nEnter new Address to connect to. \nTo retry with current settings, press <RETURN>\n");
    cout << tr("\nEnter new Address: ");
    cout.flush();

    newAddress = cin.readLine();

//    cout << tr("Enter new Port: ");
//    cout.flush();

//    cin >> newPort;

    if (!newAddress.isEmpty())
        tcpAddress = newAddress;

    //setupServerConnection();
}

/****************************************************************************
* Function:  testDataRate                                                   *
****************************************************************************/
/*! \brief
*
* Function :
*
* \param
*
* \return None
*
* \author bunto1
*
* \version 0.0.1
*
* \date 08.06.16 - bunto1 - Created
*
*
* \todo
*
****************************************************************************/
void Client::testDataRate(quint16 messageCount, quint16 msInterval)
{
    for (; messageCount > 0; messageCount--) {
        sendDistanceMessage("testTag", messageCount, QString::number(QDateTime::currentMSecsSinceEpoch()));
    }
}
