/****************************************************************************
*  Header     : main (ClientApplication_SNS)                  Version 1.0   *
*****************************************************************************
*                                                                           *
*  Function   : main function                 *
*                                                                           *
*                                                                           *
*  Methodes   : main(int argc, char *argv[])                                *
*                                                                           *
*  Author     : bunto1                                                      *
*                                                                           *
*  History    : 26.05.2016  bo Created                                      *
*                                                                           *
*  File       : main.cpp                                                    *
*                                                                           *
*****************************************************************************
* BFH TI Biel / Axiamo                                                      *
****************************************************************************/

#include <QCoreApplication>
#include "edisondecaanchor.h"

int main(int argc, char *argv[])
{
	QCoreApplication app(argc, argv);

	EdisonDecaAnchor anchorFix;
	anchor_ = &anchorFix;


	QTimer::singleShot(1000, anchor_, SLOT(initEdisonDecaAnchor()));
	//anchor_->initEdisonDecaAnchor();

    return app.exec();
}
