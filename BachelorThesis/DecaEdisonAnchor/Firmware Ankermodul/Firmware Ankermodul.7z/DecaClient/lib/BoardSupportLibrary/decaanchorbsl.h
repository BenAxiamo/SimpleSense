#ifndef DECAANCHORBSL_H
#define DECAANCHORBSL_H

#include "../DecaClient/lib/DecaLibrary/deca_regs.h"
#include "SPI_Master.h"
#include "mraa.hpp"

#include <QtGlobal>
#include <QObject>
#include <QDebug>
#include <QTimer>

enum EnableStates {
	DISABLE = 0,
	ENABLE = 1
};

enum SpiCommands {
	WHOAMI = 0,
	COM_TEST = 1,
	SPI_CMD_INDEX = 0,
	SPI_BUFFER_SIZE = 40,
	SPI_ON = 0,
	SPI_OFF = 1
};

enum I2C_GaugeRegs {
	I2C_GAUGE_ADDR = 0x64, // 0b01100100
	I2C_GAUGE_STAT = 0x00,
	I2C_GAUGE_CTRL = 0x01
};

enum LedControls {
	LED_OFF = 0,
	LED_ON = 1,
	L1 = 1,
	L2 = 2,
	L3 = 4
};

enum BtnControls {
	BTN_PRESS = 0,
	PB1 = 1,
	PB2 = 2,
	PB3 = 4
};

enum GpioControls {
	GP0 = 0,
	GP1 = 1
};

enum BSL_ERROR_CODE {
	bslSuccess,
	bslError,
	bslParamError
};

class DecaAnchorBSL : public QObject
{
	Q_OBJECT

public:
	DecaAnchorBSL(QObject *parent);
	~DecaAnchorBSL();

	/* control power converters and levelshifter */
	void enablePC5V0(bool enable);
	void enablePC3V3(bool enable);
	void enableLS1(bool enable);
	void enableLS2(bool enable);

	/* SPI & DecaWave */
	/* -> SPI Master handles only one CS */
	SPI_Master* getSPIMaster();
	void initDecaIRQ(void (*fptr)(void *), QObject *par);

	/* free usable GPIOs */
	int getGPIO(GpioControls gpNbr, mraa::Gpio *gpPtr);

	/* on-board-peripherals */
	void setLED(LedControls ledMask);
	int getLED(LedControls ledMask);
	int getBTN(BtnControls btnMask);
	void rgbDutyCycle(float r, float g, float b);
	void rgbPulseWidth(int r, int g, int b);
	void rgbPeriod(int r, int g, int b);
	void rgbEnable(bool r, bool g, bool b);

signals:
	void pb1Pressed();
	void pb2Pressed();
	void pb3Pressed();
	void gaugeAlert();
	void chargeDone();
	void decaExton();

private:
	void initPowerConverters();
	void initLevelShifters();
	void initPowerManagement();
	void initDecaWave();
	void initPWM();
	void initLeds();
	void initButtons();
	void initGPIO();

	/* !!! neither fully implemented nor tested !!! */
	/* only UART1, UART2 is for USB/FTDI */
	void initUART();
	void sendCharUART();
	void sendStringUART();
	void receiveCharUART();
	void receiveStringUART();

	/* !!! neither fully implemented nor tested !!! */
	/* I2C Power Gauge */
	void initI2C();
	void writeI2C();
	void readI2C();

	/* for additional SPI usage apart from SPI_Master */
	void cleanSpiBuffers();
	void cleanSpiTxBuffer();
	void cleanSpiRxBuffer();
	void outputSpiRxBuffer(int byteCount = -1);

	/* testing functions */
	void toggleLed();

	/* monitoring interrupt service routines */
	static void isrGaugeAlert(void *args);
	static void isrChargeDone(void *args);
	static void isrDecaExton(void *args);

	/* bushputton interrupt service routines */
	static void isrPB1(void *args);
	static void isrPB2(void *args);
	static void isrPB3(void *args);

	/* data / instances */
	quint8 txBuf[SPI_BUFFER_SIZE];
	quint8 rxBuf[SPI_BUFFER_SIZE];

	mraa::Gpio *ena3V3;
	mraa::Gpio *ena5V0;
	mraa::Gpio *enaLS1;
	mraa::Gpio *enaLS2;

	mraa::Gpio *gaugeAlcc;
	mraa::Gpio *chgDone;

	mraa::Gpio *decaCS;
	mraa::Gpio *decaIRQ;
	mraa::Gpio *decaEXT;
	mraa::Gpio *decaWKU;
	mraa::Gpio *decaRST;

	mraa::Gpio *uartRx;
	mraa::Gpio *uartTx;

	mraa::Pwm *gpioRedPWM;
	mraa::Pwm *gpioGreenPWM;
	mraa::Pwm *gpioBluePWM;

	mraa::Gpio *gpioL1;
	mraa::Gpio *gpioL2;
	mraa::Gpio *gpioL3;

	mraa::Gpio *gpioPB1;
	mraa::Gpio *gpioPB2;
	mraa::Gpio *gpioPB3;

	mraa::Gpio *gpio0;
	mraa::Gpio *gpio1;

	mraa::Spi *spi;
	mraa::I2c *i2c;
	mraa::Uart *uart;

	SPI_Master* spiMaster_;

	QTimer *timer;

/*********************************************************************/
/* Abolutely need to update these with revision 2 of the hardware!!! */
/*********************************************************************/
	enum PinDefines1v0 {
		PIN_ENA3V3 = 36,	//GP14
		PIN_ENA5V0 = 48,	//GP15
		PIN_ENALS1 = 53,	//GP79
		PIN_ENALS2 = 54,	//GP80

		PIN_ALCC = 15,		//GP165
		PIN_CHG_DO = 40,	//GP82

		PIN_DECA_CS = 23,	//GP110
		PIN_DECA_IRQ = 38,  //GP43
		PIN_DECA_EXT = 37,  //GP40
		PIN_DECA_WKU = 51,  //GP41
		PIN_DECA_RST = 50,  //GP42

		PIN_UART_RX = 26,	//GP130
		PIN_UART_TX = 35,	//GP131

		PIN_RPWM = 14,		//GP13, PWM1
		PIN_GPWM = 20,		//GP12, PWM0
		PIN_BPWM =  0,		//GP182, PWM2

		PIN_L1 = 31,		//GP44, green
		PIN_L2 = 45,		//GP45, orange
		PIN_L3 = 32,		//GP46, red

		PIN_PB1 = 46,		//GP47
		PIN_PB2 = 33,		//GP48
		PIN_PB3 = 47,		//GP49

		PIN_GP0 = 39,		//GP77, unusable
		PIN_GP1 = 52,		//GP78
	};


/*********************************************************************/
/* Maybe use an IFDEF to determine BoardVersions					 */
/*********************************************************************/
//	enum PinDefines1v1 {
//		PIN_ENA3V3 = 36,	//GP14
//		PIN_ENA5V0 = 48,	//GP15
//		PIN_ENALS1 = 53,	//GP79
//		PIN_ENALS2 = 54,	//GP80

//		PIN_ALCC = 55,		//GP81
//		PIN_CHG_DO = 40,	//GP82

//		PIN_DECA_CS = 23,	//GP110
//		PIN_DECA_IRQ = 38,  //GP43
//		PIN_DECA_EXT = 37,  //GP40
//		PIN_DECA_WKU = 51,  //GP41
//		PIN_DECA_RST = 50,  //GP42

//		PIN_UART_RX = 26,	//GP130
//		PIN_UART_TX = 35,	//GP131

//		PIN_RPWM = 14,		//GP13, PWM1
//		PIN_GPWM = 20,		//GP12, PWM0
//		PIN_BPWM =  0,		//GP182, PWM2

//		PIN_L1 = 31,		//GP44, green
//		PIN_L2 = 45,		//GP45, orange
//		PIN_L3 = 32,		//GP46, red

//		PIN_PB1 = 46,		//GP47
//		PIN_PB2 = 33,		//GP48
//		PIN_PB3 = 47,		//GP49

//		PIN_GP0 = 41,		//GP83, unusable
//		PIN_GP1 = 49,		//GP84
//	};
};

#endif // DECAANCHORBSL_H
