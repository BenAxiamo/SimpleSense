#include "SPI_Master.h"

#define SPI_DEFAULT_BAUD   2800000

/**************************************************************************/
SPI_Master::SPI_Master(mraa::Spi *spi, mraa::Gpio *cs) : initialized_(false)
{
	/* Setup Chip Select GPIO */
	if ((cs == NULL) || (spi == NULL)) {
		qDebug() << "could not initialize SPI Master";
		return;
	}

	qDebug() << " init spi started ";

	/* Setup SPI Interface */
	spiIF = spi;

	/* Setup SPI Chip Select */
	spiCS = cs;

	/* Configure wordLength */
	spiIF->bitPerWord(8);

	/* Configure baudrate */
	int result_freq = spiIF->frequency(SPI_DEFAULT_BAUD);

	/* Debug */
	qDebug() << " init spi freq: " << result_freq;
	qDebug() << " SPI CS pin number: " << spiCS->getPin(true);
	qDebug() << ">init spi done.";
}

/**************************************************************************/
SPI_Master::~SPI_Master()
{
	qDebug() << "Destructor SPI_Master Start";



	qDebug() << "Destructor SPI_Master Stop";
}

/**************************************************************************/
int SPI_Master::SPI_setup(SPI_BUS spiBus, int spiBR) //remove SPI Bus
{
	/* Configure baudrate */
	int result_freq = spiIF->frequency(spiBR);

	/* -> guess all that stuff is made implicit by mraa <- */
	/* Using (synchronous) mode */
	/* Clearing old transfers/receptions, and disabling interrupts */
	/* Enabling pins and setting location */
	/* Enabling Master, TX and RX */
	/* Set GPIO config to master */
	/* Clear previous interrupts */
	/* IO configuration */

	/* Debug */
	qDebug() << " init spi freq: " << result_freq;

	return DWT_SUCCESS;
}

/**************************************************************************/
bool SPI_Master::isInitialized()
{
	return initialized_;
}

/**************************************************************************/
void SPI_Master::Initialize()
{
	/* Setup SPI */
	SPI_setup(SPI_USART0, SPI_DEFAULT_BAUD);

	initialized_ = true;
}

/**************************************************************************/
int SPI_Master::Terminate()
{
	initialized_ = false;

	/* TODO: free spi and spiCS (or maybe in BSL) */

	return 0;
}

void SPI_Master::SPI0_setupTXInt(char* transmitBuffer, int transmitBufferSize)
{
	/* shouldn't be used for the moment */
	qDebug() << "was used anyway - SPI0_setupTXInt";
}

void SPI_Master::SPI0_setupRXInt(char* receiveBuffer, int bytesToReceive)
{
	/* shouldn't be used for the moment */
	qDebug() << "was used anyway - SPI0_setupRXInt";
}

void SPI_Master::SPI0_setupMasterInt(char* receiveBuffer, int bytesToReceive,
		char* transmitBuffer, int transmitBufferSize)
{
	SPI0_setupRXInt(receiveBuffer, bytesToReceive);
	SPI0_setupTXInt(transmitBuffer, transmitBufferSize);

	/* shouldn't be used for the moment */
	qDebug() << "was used anyway - SPI0_setupMasterInt";
}

void SPI_Master::USART0_RX_IRQHandler(void)
{
	/* shouldn't be used for the moment */
	qDebug() << "was used anyway - USART0_RX_IRQHandler";
}

/**************************************************************************/
void SPI_Master::CS_pin_clr(void)
{
	spiCS->write(0);
}

/**************************************************************************/
void SPI_Master::CS_pin_set(void)
{
	spiCS->write(1);
}

/**************************************************************************/
int SPI_Master::transfer(unsigned char *txBuf, int txLen, unsigned char *rxBuf, int rxLen)
{
	/* prevent multiple access */
	SPI_Mutex.lock();

	int bytesTransfered = 0;
	int transLen = txLen + rxLen;
	unsigned char receiveBuf[transLen];
	mraa_result_t res = MRAA_SUCCESS;

	//qDebug() << "spi transfer with len: " << transLen;

	/* check for unusually long packets */
//	if(transLen>40){
//		qDebug() << " sth wrong here?";
//		return DWT_ERROR;
//	}

	/* spi transfer */
//	qDebug() << "tLen: " << transLen;
//	qDebug() << "bTra: " << bytesTransfered;
	CS_pin_clr();
	while (transLen > 32) {
		 if (spiIF->transfer((txBuf+bytesTransfered), &receiveBuf[bytesTransfered], 32) != MRAA_SUCCESS) {
			 res = MRAA_ERROR_UNSPECIFIED;
		 }
		 transLen -= 32;
		 bytesTransfered += 32;
		 qDebug() << "tLen: " << transLen;
		 qDebug() << "bTra: " << bytesTransfered;
		 qDebug() << "txBuf : " << txBuf;
		 qDebug() << "txBuf+: " << (txBuf + bytesTransfered);

	}
	if (spiIF->transfer((txBuf+bytesTransfered), &receiveBuf[bytesTransfered], transLen) != MRAA_SUCCESS) {
		res = MRAA_ERROR_UNSPECIFIED;
	}
	CS_pin_set();

	//qDebug() << "spi transfer with len: " << transLen << " done " << res;

	if (res != MRAA_SUCCESS) {
		qDebug() << "spi error";
		return DWT_ERROR;
	}

	/* only return valid bytes in rxBuf */
	for (int i = txLen; i < transLen; i++) {
		*rxBuf = receiveBuf[i];
		rxBuf++;
	}

	SPI_Mutex.unlock();

	return DWT_SUCCESS;
}
