/*
 * SPI_Master_Edison.h
 *
 *  Created on: June 20, 2016
 *      Author: bunto1
 */

#ifndef SPI_MASTER_EDISON_H
#define SPI_MASTER_EDISON_H

#include <QtGlobal>
#include <QDebug>
#include <QMutex>

#include "mraa.hpp"

enum DWT_RETURN {
	DWT_SUCCESS = 0,
	DWT_ERROR = -1
};


enum SPI_BUS {
    SPI_USART0,
    SPI_USART2
};

class SPI_Master
{

public:
	SPI_Master(mraa::Spi *spi = NULL, mraa::Gpio *cs = NULL);
    ~SPI_Master();

    void Initialize();
    int Terminate();
    bool isInitialized();
    int SPI_setup(SPI_BUS bus, int spiBR);

    void CS_pin_clr(void);
    void CS_pin_set(void);
	int transfer(unsigned char* txBuf, int txLen,
                  unsigned char* rxBuf, int rxLen);

private:
    bool initialized_;
	QMutex SPI_Mutex;
    mraa::Gpio *spiCS;
	mraa::Spi *spiIF;

    /* unused functions? */
    void SPI0_setupTXInt(char* transmitBuffer, int transmitBufferSize);
    void SPI0_setupRXInt(char* receiveBuffer, int bytesToReceive);
    void SPI0_setupMasterInt(char* receiveBuffer, int bytesToReceive,
        char* transmitBuffer, int transmitBufferSize);
    void USART0_RX_IRQHandler(void);

    //DISALLOW_COPY_AND_ASSIGN(SPI_Master)
};

#endif // SPI_MASTER_EDISON_H
