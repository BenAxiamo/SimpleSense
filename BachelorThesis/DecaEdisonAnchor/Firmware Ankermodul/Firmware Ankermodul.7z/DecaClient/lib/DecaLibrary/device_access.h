#ifndef DEVICE_ACCESS_H
#define DEVICE_ACCESS_H

/* this library provides functions to control the "parent device" of the DW1000
 * (either Axiamote or EdisonDecaAnchor for the moment)
 */

/* maybe not good idea, but since types are defined here.. */
#include <QtGlobal>

enum RGB_LED_COLOR {
	COLOR_BLACK,
	COLOR_RED
};

void calculatedDistance(float distance);

uint8_t setNextTimerTime(uint16_t time);
uint8_t RGBColorSet(uint8_t color);
uint8_t vTaskDelay(uint8_t time);

uint64_t getSettingsDecaNID();
uint8_t* getSettingsDecaEUI();


#endif // DEVICE_ACCESS_H
