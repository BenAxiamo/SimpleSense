/*
 * UWBDecaWave.h
 *
 *  Created on: May 8, 2015
 *      Author: pupuy1
 */

#ifndef UWBDW1000_H_
#define UWBDW1000_H_

//#include <string>

using namespace std;
#include "deca_regs.h"
#include "lib/BoardSupportLibrary/SPI_Master.h" //TODO change to compatible
#include "lib/DecaLibrary/device_access.h"
#include "UWBDW1000Time.h"

//#include "macros.h"
//#include "Structures.h"
//#include "Task.h"
//#include "em_adc.h"
//#include "em_gpio.h"
//#include "em_cmu.h"
//#include "em_timer.h"

#ifndef bitRead
#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#define bitWrite(value, bit, bitvalue) (bitvalue ? bitSet(value, bit) : bitClear(value, bit))
#endif

#define ERROR -1
#define SUCCESS 0

// device id register
#define LEN_REG_DEV_ID 4
#define DW1000_REG_DEV_ID 0x00
#define DW1000_DEV_ID 0xdeca0130

//GPIO control register
#define GPIO_MODE 0x26
#define LEN_GPIO_MODE 4
// time stamp byte length
#define LEN_STAMP 5

// enum to determine RX or TX mode of device
#define IDLE_MODE 0x00

// no sub-address for register write
#define NO_SUB 0x00

// PAN identifier, short address register
#define PANADR 0x03
#define LEN_PANADR 4

// device configuration register
#define SYS_CFG 0x04
#define LEN_SYS_CFG 4
#define FFEN_BIT 0
#define FFBC_BIT 1
#define FFAB_BIT 2
#define FFAD_BIT 3
#define FFAA_BIT 4
#define FFAM_BIT 5
#define FFAR_BIT 6
#define DIS_DRXB_BIT 12
#define DIS_STXP_BIT 18
#define HIRQ_POL_BIT 9
#define RXAUTR_BIT 29
#define RXWTOE_BIT 28
#define PHR_MODE_SUB 16
#define LEN_PHR_MODE_SUB 2
#define FCS_INIT2F_BIT 15
#define RXM110K_BIT 22
#define AUTOACK_BIT 30

//GPIO control register
#define GPIO_MODE 0x26
#define LEN_GPIO_MODE 4
#define MSGP2_BIT 9
#define MSGP3_BIT 11
#define GPIO_IDBE_SUB 0x24

// device control register
#define SYS_CTRL 0x0D
#define LEN_SYS_CTRL 4
#define SFCST_BIT 0
#define TXSTRT_BIT 1
#define TXDLYS_BIT 2
#define TRXOFF_BIT 6
#define WAIT4RESP_BIT 7
#define RXENAB_BIT 8
#define RXDLYS_BIT 9

// system event status register
#define SYS_STATUS 0x0F
#define LEN_SYS_STATUS 5
#define CPLOCK_BIT 1
#define AAT_BIT 3
#define TXFRB_BIT 4
#define TXPRS_BIT 5
#define TXPHS_BIT 6
#define TXFRS_BIT 7
#define LDEDONE_BIT 10
#define RXPHE_BIT 12
#define RXDFR_BIT 13
#define RXFCG_BIT 14
#define RXFCE_BIT 15
#define RXRFSL_BIT 16
#define RXRFTO_BIT 17
#define LDEERR_BIT 18
#define RFPLL_LL_BIT 24
#define CLKPLL_LL_BIT 25
#define HPDWARN_BIT 27

// system event mask register
// NOTE: uses the bit definitions of SYS_STATUS (below 32)
#define SYS_MASK 0x0E
#define LEN_SYS_MASK 4
#define MRXDFR_BIT 13
#define MTXFRS_BIT 7
#define MRXRFTO_BIT 17
// system time counter
#define SYS_TIME 0x06
#define LEN_SYS_TIME LEN_STAMP

// RX timestamp register
#define RX_TIME 0x15
#define LEN_RX_TIME 14
#define RX_STAMP_SUB 0x00
#define FP_AMPL1_SUB 0x07
#define LEN_RX_STAMP LEN_STAMP
#define LEN_FP_AMPL1 2

// RX frame quality
#define RX_FQUAL 0x12
#define LEN_RX_FQUAL 8
#define STD_NOISE_SUB 0x00
#define FP_AMPL2_SUB 0x02
#define FP_AMPL3_SUB 0x04
#define CIR_PWR_SUB 0x06
#define LEN_STD_NOISE 2
#define LEN_FP_AMPL2 2
#define LEN_FP_AMPL3 2
#define LEN_CIR_PWR 2

// TX timestamp register
#define TX_TIME 0x17
#define LEN_TX_TIME 10
#define TX_STAMP_SUB 0
#define LEN_TX_STAMP LEN_STAMP

// timing register (for delayed RX/TX)
#define DX_TIME 0x0A
#define LEN_DX_TIME LEN_STAMP

// transmit data buffer
#define TX_BUFFER 0x09
#define LEN_TX_BUFFER 1024
#define LEN_UWB_FRAMES 127
#define LEN_EXT_UWB_FRAMES 1023

// RX frame info
#define RX_FINFO 0x10
#define LEN_RX_FINFO 4

// receive data buffer
#define RX_BUFFER 0x11
#define LEN_RX_BUFFER 1024

// transmit control
#define TX_FCTRL 0x08
#define LEN_TX_FCTRL 5

// channel control
#define CHAN_CTRL 0x1F
#define LEN_CHAN_CTRL 4
#define DWSFD_BIT 17
#define TNSSFD_BIT 20
#define RNSSFD_BIT 21

// user-defined SFD
#define USR_SFD 0x21
#define LEN_USR_SFD 41
#define SFD_LENGTH_SUB 0x00
#define LEN_SFD_LENGTH 1

// OTP control (for LDE micro code loading only)
#define OTP_IF 0x2D
#define OTP_ADDR_SUB 0x04
#define OTP_CTRL_SUB 0x06
#define OTP_RDAT_SUB 0x0A
#define LEN_OTP_ADDR 2
#define LEN_OTP_CTRL 2
#define LEN_OTP_RDAT 4

// AGC_TUNE1/2 (for re-tuning only)
#define AGC_TUNE 0x23
#define AGC_TUNE1_SUB 0x04
#define AGC_TUNE2_SUB 0x0C
#define AGC_TUNE3_SUB 0x12
#define LEN_AGC_TUNE1 2
#define LEN_AGC_TUNE2 4
#define LEN_AGC_TUNE3 2

// DRX_TUNE2 (for re-tuning only)
#define DRX_TUNE 0x27
#define DRX_TUNE0b_SUB 0x02
#define DRX_TUNE1a_SUB 0x04
#define DRX_TUNE1b_SUB 0x06
#define DRX_TUNE2_SUB 0x08
#define DRX_PRETOC 0x24
#define LEN_DRX_PRETOC 2
#define DRX_TUNE4H_SUB 0x26
#define LEN_DRX_TUNE0b 2
#define LEN_DRX_TUNE1a 2
#define LEN_DRX_TUNE1b 2
#define LEN_DRX_TUNE2 4
#define LEN_DRX_TUNE4H 2

// LDE_CFG1 (for re-tuning only)
#define LDE_IF 0x2E
#define LDE_CFG1_SUB 0x0806
#define LDE_RXANTD_SUB 0x1804
#define LDE_CFG2_SUB 0x1806
#define LDE_REPC_SUB 0x2804
#define LEN_LDE_CFG1 1
#define LEN_LDE_CFG2 2
#define LEN_LDE_REPC 2
#define LEN_LDE_RXANTD 2

// TX_POWER (for re-tuning only)
#define TX_POWER 0x1E
#define LEN_TX_POWER 4

// RF_CONF (for re-tuning only)
#define RF_CONF 0x28
#define RF_RXCTRLH_SUB 0x0B
#define RF_TXCTRL_SUB 0x0C
#define LEN_RF_RXCTRLH 1
#define LEN_RF_TXCTRL 4
#define RF_STATUS_SUB 0x2C

#define RX_FWTO 0x0C

// TX_CAL (for re-tuning only)
#define TX_CAL 0x2A
#define TC_PGDELAY_SUB 0x0B
#define LEN_TC_PGDELAY 1

// FS_CTRL (for re-tuning only)
#define FS_CTRL 0x2B
#define FS_PLLCFG_SUB 0x07
#define FS_PLLTUNE_SUB 0x0B
#define FS_XTALT_SUB 0x0E
#define LEN_FS_PLLCFG 4
#define LEN_FS_PLLTUNE 1
#define LEN_FS_XTALT 1

// PMSC
#define PMSC 0x36
#define PMSC_CTRL0_SUB 0x00
#define LEN_PMSC_CTRL0 4

// TX_ANTD Antenna delays
#define TX_ANTD 0x18
#define LEN_TX_ANTD 2
//Orders
#define ORDER_SET_TIME 0
#define STATE_WRONG_SLOT 20
#define STATE_OFFLINE 0
#define STATE_ONLINE 10

// Defines for enable_clocks function
#define FORCE_SYS_XTI  0
#define ENABLE_ALL_SEQ 1
#define FORCE_SYS_PLL  2
#define READ_ACC_ON    7
#define READ_ACC_OFF   8
#define FORCE_OTP_ON   11
#define FORCE_OTP_OFF  12
#define FORCE_TX_PLL   13

//DW1000 interrupt events
#define DWT_INT_TFRS			0x00000080			// frame sent
#define DWT_INT_LDED            0x00000400			// micro-code has finished execution
#define DWT_INT_RFCG			0x00004000			// frame received with good CRC
#define DWT_INT_RPHE			0x00001000			// receiver PHY header error
#define DWT_INT_RFCE			0x00008000			// receiver CRC error
#define DWT_INT_RFSL			0x00010000			// receiver sync loss error
#define DWT_INT_RFTO			0x00020000			// frame wait timeout
#define DWT_INT_RXOVRR			0x00100000			// receiver overrun
#define DWT_INT_RXPTO			0x00200000			// preamble detect timeout
#define DWT_INT_SFDT			0x04000000			// SFD timeout
#define DWT_INT_ARFE			0x20000000			// frame rejected (due to frame filtering configuration)
#define PMSC 0x36
#define PMSC_CTRL0_SUB 0x00
#define PMSC_CTRL1_SUB 0x04
#define LEN_PMSC_CTRL0 4
#define LEN_PMSC_CTRL1 4
#define PMSC_GPDCE_BIT 18
//youyou
#define NO_SUB 0x00
#define PANADR 0x03
#define LEN_PANADR 4
#define SYS_CFG 0x04
#define LEN_SYS_CFG 4
#define SYS_CTRL 0x0D
#define LEN_SYS_CTRL 4
#define CHAN_CTRL 0x1F
#define LEN_CHAN_CTRL 4
#define TX_FCTRL 0x08
#define LEN_TX_FCTRL 5
#define SYS_MASK 0x0E
#define LEN_SYS_MASK 4
#define LEN_SYS_STATUS 5
#define LEN_STAMP 5
#define TX_ANTD 0x18
#define LEN_TX_ANTD 2
// extended unique identifier register
#define EUI_REG 0x01
#define LEN_EUI 8
#define LEN_EC_CTRL 4
#define LEN_NID 6
// LDE_CFG1 (for re-tuning only)
#define LDE_IF 0x2E
#define LDE_CFG1_SUB 0x0806
#define LDE_RXANTD_SUB 0x1804
#define LDE_CFG2_SUB 0x1806
#define LDE_REPC_SUB 0x2804
#define LEN_LDE_CFG1 1
#define LEN_LDE_CFG2 2
#define LEN_LDE_REPC 2
#define LEN_LDE_RXANTD 2
//lengths including the Decaranging Message Function Code byte
#define TAG_POLL_MSG_LEN                    1				// FunctionCode(1),
#define ANCH_RESPONSE_MSG_LEN               9               // FunctionCode(1), RespOption (1), OptionParam(2), Measured_TOF_Time(5)
#define TAG_FINAL_MSG_LEN                   16              // FunctionCode(1), Poll_TxTime(5), Resp_RxTime(5), Final_TxTime(5)
#define RANGINGINIT_MSG_LEN					7				// FunctionCode(1), Tag Address (2), Response Time (2) * 2
#define MAX_MAC_MSG_DATA_LEN                (TAG_FINAL_MSG_LEN) //max message len of the above
#define ADDR_BYTE_SIZE_L            8
#define ADDR_BYTE_SIZE_S            2
#define STANDARD_FRAME_SIZE         127
#define FRAME_DEST_ADDRESS_S          (ADDR_BYTE_SIZE_S)
#define FRAME_SOURCE_ADDRESS_S        (ADDR_BYTE_SIZE_S)
#define FRAME_DEST_ADDRESS_L          (ADDR_BYTE_SIZE_L)
#define FRAME_SOURCE_ADDRESS_L        (ADDR_BYTE_SIZE_L)
#define TAG_FINAL_MSG_LEN                   16              // FunctionCode(1), Poll_TxTime(5), Resp_RxTime(5), Final_TxTime(5)
#define FRAME_CONTROL_BYTES         2
#define FRAME_SEQ_NUM_BYTES         1
#define FRAME_PANID                 2
#define FRAME_CRC					2
#define FRAME_CTRLP					(FRAME_CONTROL_BYTES + FRAME_SEQ_NUM_BYTES + FRAME_PANID) //5
#define FRAME_CRTL_AND_ADDRESS_L    (FRAME_DEST_ADDRESS_L + FRAME_SOURCE_ADDRESS_L + FRAME_CTRLP) //21 bytes for 64-bit addresses)
#define FRAME_CRTL_AND_ADDRESS_S    (FRAME_DEST_ADDRESS_S + FRAME_SOURCE_ADDRESS_S + FRAME_CTRLP) //9 bytes for 16-bit addresses)
#define FRAME_CRTL_AND_ADDRESS_LS	(FRAME_DEST_ADDRESS_L + FRAME_SOURCE_ADDRESS_S + FRAME_CTRLP) //15 bytes for 1 16-bit address and 1 64-bit address)
#define MAX_USER_PAYLOAD_STRING_LL     (STANDARD_FRAME_SIZE-FRAME_CRTL_AND_ADDRESS_L-TAG_FINAL_MSG_LEN-FRAME_CRC) //127 - 21 - 16 - 2 88
#define MAX_USER_PAYLOAD_STRING_SS     (STANDARD_FRAME_SIZE-FRAME_CRTL_AND_ADDRESS_S-TAG_FINAL_MSG_LEN-FRAME_CRC) //127 - 9 - 16 - 2 100
#define MAX_USER_PAYLOAD_STRING_LS     (STANDARD_FRAME_SIZE-FRAME_CRTL_AND_ADDRESS_LS-TAG_FINAL_MSG_LEN-FRAME_CRC) //127 - 15 - 16 - 2 94
#define BLINK_FRAME_CONTROL_BYTES       (1)
#define BLINK_FRAME_SEQ_NUM_BYTES       (1)
#define BLINK_FRAME_CRC					(FRAME_CRC)
#define BLINK_FRAME_SOURCE_ADDRESS      (ADDR_BYTE_SIZE_L)
#define BLINK_FRAME_CTRLP				(BLINK_FRAME_CONTROL_BYTES + BLINK_FRAME_SEQ_NUM_BYTES) //2
#define BLINK_FRAME_CRTL_AND_ADDRESS    (BLINK_FRAME_SOURCE_ADDRESS + BLINK_FRAME_CTRLP) //10 bytes
#define BLINK_FRAME_LEN_BYTES           (BLINK_FRAME_CRTL_AND_ADDRESS + BLINK_FRAME_CRC)

#define TIME_PER_PERIOD 33
#define MAX_TAGS 1 //max TIME_PER_PERIOD / (TIME_PER_ANCHOR * MAX_ANCHOR)
#define MAX_ANCHOR 4
#define LOGFILE_PATH "/home/pi/DecaWave/logfile"
#define CONFFILE_PATH "/home/pi/DecaWave/loadfile.txt"
#define DISTFILE_PATH "/home/pi/DecaWave/distfile"

#define FIX_DEV_ID 0xDECA0130
#define usleep(x) QThread::usleep(x)
#define msleep(x) QThread::msleep(x)
#define CORRECTION 28650769//28650659//935
#define TIME_TO_METER 4.3181 //to centimeter
#define DWT_SUCCESS SUCCESS
#define DWT_ERROR ERROR

#define IO_INT 25
#define IO_RST 24
#define MAX_EVENT_NUMBER (4)

#define FLENGTH_MSG_POLL  		(FRAME_CRTL_AND_ADDRESS_L + TAG_POLL_MSG_LEN + FRAME_CRC)//24
#define FLENGTH_MSG_RESPONSE  	(FRAME_CRTL_AND_ADDRESS_L + ANCH_RESPONSE_MSG_LEN + FRAME_CRC)//32
#define FLENGTH_MSG_FINAL  		(FRAME_CRTL_AND_ADDRESS_L + TAG_FINAL_MSG_LEN + FRAME_CRC)//39
#define FLENGTH_MSG_RANGINGINIT (FRAME_CRTL_AND_ADDRESS_L + RANGINGINIT_MSG_LEN + FRAME_CRC)//30
#define FLENGTH_MSG_BLINK  		(BLINK_FRAME_CRTL_AND_ADDRESS + FRAME_CRC)//12
//// modes of operation
enum decaDataRate {
	TRX_RATE_110KBPS = 0x00, TRX_RATE_850KBPS = 0x01, TRX_RATE_6800KBPS = 0x02
};

enum decaPreambleLength {
	TX_PREAMBLE_LEN_64 = 0x01,
	TX_PREAMBLE_LEN_128 = 0x05,
	TX_PREAMBLE_LEN_256 = 0x09,
	TX_PREAMBLE_LEN_512 = 0x0D,
	TX_PREAMBLE_LEN_1024 = 0x02,
	TX_PREAMBLE_LEN_1536 = 0x06,
	TX_PREAMBLE_LEN_2048 = 0x0A,
	TX_PREAMBLE_LEN_4096 = 0x03
};

// transmission pulse frequency
// 0x00 is 4MHZ, but receiver in DW1000 does not support it (!??)
enum decaPulseFreq {
	TX_PULSE_FREQ_16MHZ = 0x01, TX_PULSE_FREQ_64MHZ = 0x02
};

/* preamble codes. */
enum decaPreambleCode {
	PREAMBLE_CODE_16MHZ_1 = 1,
	PREAMBLE_CODE_16MHZ_2 = 2,
	PREAMBLE_CODE_16MHZ_3 = 3,
	PREAMBLE_CODE_16MHZ_4 = 4,
	PREAMBLE_CODE_16MHZ_5 = 5,
	PREAMBLE_CODE_16MHZ_6 = 6,
	PREAMBLE_CODE_16MHZ_7 = 7,
	PREAMBLE_CODE_16MHZ_8 = 8,
	PREAMBLE_CODE_64MHZ_9 = 9,
	PREAMBLE_CODE_64MHZ_10 = 10,
	PREAMBLE_CODE_64MHZ_11 = 11,
	PREAMBLE_CODE_64MHZ_12 = 12,
	PREAMBLE_CODE_64MHZ_17 = 17,
	PREAMBLE_CODE_64MHZ_18 = 18,
	PREAMBLE_CODE_64MHZ_19 = 19,
	PREAMBLE_CODE_64MHZ_20 = 20
};
// PAC size. */
enum decaPACSize {
	PAC_SIZE_8 = 8, PAC_SIZE_16 = 16, PAC_SIZE_32 = 32, PAC_SIZE_64 = 64
};

/* channel of operation. */
enum DecaChannel {
	CHANNEL_1 = 1,
	CHANNEL_2 = 2,
	CHANNEL_3 = 3,
	CHANNEL_4 = 4,
	CHANNEL_5 = 5,
	CHANNEL_7 = 7
};

enum extFrameLength {
	EXT_FRAMELENGTH_DEFAULT = 0x00
};

enum DecaSmartPower {
	smart = 0, manual = 1
};
struct DECA_OPERATION_MODE {
	extFrameLength extFrameLen;
	decaDataRate dataRate;
	decaPulseFreq pulseFreq;
	decaPreambleLength preambleLen;
	decaPACSize pacSize;
	decaPreambleCode preambleCode;
	DecaChannel channel;
	DecaSmartPower stxp;
};

//TODO : enum for magicValue!!!
enum tuneRegister {
	//AGC Tuning register 1. Sub-Register 0x23:04
	AGC_TUNE1_DEFAULT = 0x889B,
	AGC_TUNE1_TUNED_RXPRF16 = 0x8870, //optimal value for the default PRF of 16MHz, should be set before proceeding to use the default device configuration
	AGC_TUNE1_TUNED_RXPRF64 = 0x889B,

	//AGC Tuning register 2. Sub-Register 0x23:0C
	AGC_TUNE2_TUNED = 0x2502A907, //optimal value of AGC. Please take care not to write other values to this register.

	//AGC Tuning register 3. Sub-Register 0x23:12
	AGC_TUNE3_TUNED = 0x0035,

	//Digital Tuning Register 0b. Sub-Register 0x27:02
	DRX_TUNE0B_TUNED_DATARATE110_SFD = 0x000A,
	DRX_TUNE0B_TUNED_DATARATE110_NON_SFD = 0x0016,
	DRX_TUNE0B_TUNED_DATARATE850_SFD = 0x0001,
	DRX_TUNE0B_TUNED_DATARATE850_NON_SFD = 0x0006,
	DRX_TUNE0B_TUNED_DATARATE6800_SFD = 0x0001,
	DRX_TUNE0B_TUNED_DATARATE6800_NON_SFD = 0x0002,

	//Digital Tuning Register 1a. Sub-Register 0x27:04
	DRX_TUNE1A_TUNED_RXPRF16 = 0x0087,
	DRX_TUNE1A_TUNED_RXPRF64 = 0x008D,

	//Digital Tuning Register 1b. Sub-Register 0x27:06
	DRX_TUNE1B_DATARATE110 = 0x0064,
	DRX_TUNE1B_DATARATE850 = 0x0020,
	DRX_TUNE1B_DATARATE6800 = 0x0010,

	//Digital Tuning Register 2. Sub-Register 0x27:08
	DRX_TUNE2_DEFAULT = 0x311E0035,
	DRX_TUNE2_TUNED_PAC8_RXPRF16 = 0x311A002D, //optimal value for the default PRF and PAC, should be set before proceeding to use the default device configuration
	DRX_TUNE2_TUNED_PAC8_RXPRF64 = 0x313B006B,
	DRX_TUNE2_TUNED_PAC16_RXPRF16 = 0x331A0052,
	DRX_TUNE2_TUNED_PAC16_RXPRF64 = 0x333B00BE,
	DRX_TUNE2_TUNED_PAC32_RXPRF16 = 0x351A009A,
	DRX_TUNE2_TUNED_PAC32_RXPRF64 = 0x353B015E,
	DRX_TUNE2_TUNED_PAC64_RXPRF16 = 0x371A011D,
	DRX_TUNE2_TUNED_PAC64_RXPRF64 = 0x373B0296,

	//Digital Tuning Register 4h. Sub-Register 0x27:26
	DRX_TUNE4H_PREAMBLE_LENGTH_64 = 0x0010, // Expected Receive Preamble Length in Symbols
	DRX_TUNE4H_PREAMBLE_LENGTH_128 = 0x0028, //128 or greater

	//Analog TX ControlRegister. Sub-Register 0x28:0B
	RF_RXCTRLH_TUNED_CHANNEL1_2_3_5 = 0xD8,
	RF_RXCTRLH_TUNED_CHANNEL4_7 = 0xBC,

	//Analog TX ControlRegister. Sub-Register 0x28:0C
	RF_TXCTRL_TUNED_CHANNEL1 = 0x00005C40,
	RF_TXCTRL_TUNED_CHANNEL2 = 0x00045CA0,
	RF_TXCTRL_TUNED_CHANNEL3 = 0x00086CC0,
	RF_TXCTRL_TUNED_CHANNEL4 = 0x00045C80,
	RF_TXCTRL_TUNED_CHANNEL5 = 0x001E3FE0,
	RF_TXCTRL_TUNED_CHANNEL7 = 0x001E7DE0,

	//Transmitter Calibration –Pulse Generator Delay. Sub-Register 0x2A:0B
	TC_PGDELAY_DEFAULT = 0xC5,
	TC_PGDELAY_TUNED_CHANNEL1 = 0xC9,
	TC_PGDELAY_TUNED_CHANNEL2 = 0xC2,
	TC_PGDELAY_TUNED_CHANNEL3 = 0xC5,
	TC_PGDELAY_TUNED_CHANNEL4 = 0x95,
	TC_PGDELAY_TUNED_CHANNEL5 = 0xC0,
	TC_PGDELAY_TUNED_CHANNEL7 = 0x93,

	//Frequency synthesiser – PLL configuration. Sub-Register 0x2B:07
	FS_PLLCFG_TUNED_CHANNEL1 = 0x09000407,
	FS_PLLCFG_TUNED_CHANNEL2_CHANNEL4 = 0x08400508,
	FS_PLLCFG_TUNED_CHANNEL3 = 0x08401009,
	FS_PLLCFG_TUNED_CHANNEL5_CHANNEL7 = 0x0800041D,

	//Frequency synthesiser – PLL Tuning. Sub-Register 0x2B:0B
	FS_PLLTUNE_DEFAULT = 0x46,
	FS_PLLTUNE_TUNED_CHANNEL1 = 0x1E,
	FS_PLLTUNE_TUNED_CHANNEL2_CHANNEL4 = 0x26,
	FS_PLLTUNE_TUNED_CHANNEL3 = 0x5E,
	FS_PLLTUNE_TUNED_CHANNEL5_CHANNEL7 = 0xA6,

	//Transmit Power Control.  0x1E
	TX_POWER_DEFAULT = 0x1E080222,
	TX_POWER_TUNED_CHANNEL1_CHANNEL2_PRF16_STXP = 0x15355575, //channle 1 or channel 2, 16MHz PRF, DIS_STXP = 0(SMART TX POWER ENABLED)
	TX_POWER_TUNED_CHANNEL1_CHANNEL2_PRF64_STXP = 0x07274767,
	TX_POWER_TUNED_CHANNEL3_PRF16_STXP = 0x0F2F4F6F,
	TX_POWER_TUNED_CHANNEL3_PRF64_STXP = 0x2B4B6B8B,
	TX_POWER_TUNED_CHANNEL4_PRF16_STXP = 0x1F1F3F5F,
	TX_POWER_TUNED_CHANNEL4_PRF64_STXP = 0x3A5A7A9A,
	TX_POWER_TUNED_CHANNEL5_PRF16_STXP = 0x0E082848,
	TX_POWER_TUNED_CHANNEL5_PRF64_STXP = 0x25456585,
	TX_POWER_TUNED_CHANNEL7_PRF16_STXP = 0x32527292,
	TX_POWER_TUNED_CHANNEL7_PRF64_STXP = 0x5171B1D1,

	TX_POWER_TUNED_CHANNEL1_CHANNEL2_PRF16_MANUAL = 0x75757575,
	TX_POWER_TUNED_CHANNEL1_CHANNEL2_PRF64_MANUAL = 0x67676767,
	TX_POWER_TUNED_CHANNEL3_PRF16_MANUAL = 0x6F6F6F6F,
	TX_POWER_TUNED_CHANNEL3_PRF64_MANUAL = 0x8B8B8B8B,
	TX_POWER_TUNED_CHANNEL4_PRF16_MANUAL = 0x5F5F5F5F,
	TX_POWER_TUNED_CHANNEL4_PRF64_MANUAL = 0x9A9A9A9A,
	TX_POWER_TUNED_CHANNEL5_PRF16_MANUAL = 0x48484848,
	TX_POWER_TUNED_CHANNEL5_PRF64_MANUAL = 0x85858585,
	TX_POWER_TUNED_CHANNEL7_PRF16_MANUAL = 0x92929292,
	TX_POWER_TUNED_CHANNEL7_PRF64_MANUAL = 0xD1D1D1D1,

	//LDE Configuration Register 1. Sub-Register 0x2E:0806
	LDE_CFG1_NTM_DEFAULT = 0x0C,
	LDE_CFG1_NTM_TUNED = 0x0D,

	//LDE Configuration Register 2. Sub-Register 0x2E:1806
	LDE_CFG2_DEFAULT = 0x0000,
	LDE_CFG2_TUNED_RXPRF16 = 0x1607,
	LDE_CFG2_TUNED_RXPRF64 = 0x0607,

	//LDE Replica Coefficient configuration. Sub-Register 0x2E:2804  (850 kbps & 6.8 Mbps)
	LDE_REPC_TUNED_RX_PCODE1_2 = 0x5998,
	LDE_REPC_TUNED_RX_PCODE3_8 = 0x51EA,
	LDE_REPC_TUNED_RX_PCODE4 = 0x428E,
	LDE_REPC_TUNED_RX_PCODE5 = 0x451E,
	LDE_REPC_TUNED_RX_PCODE6 = 0x2E14,
	LDE_REPC_TUNED_RX_PCODE7 = 0x8000,
	LDE_REPC_TUNED_RX_PCODE9 = 0x28F4,
	LDE_REPC_TUNED_RX_PCODE10_17 = 0x3332,
	LDE_REPC_TUNED_RX_PCODE11 = 0x3AE0,
	LDE_REPC_TUNED_RX_PCODE12 = 0x3D70,
	LDE_REPC_TUNED_RX_PCODE13 = 0x3AE0,
	LDE_REPC_TUNED_RX_PCODE14 = 0x35C2,
	LDE_REPC_TUNED_RX_PCODE15 = 0x2B84,
	LDE_REPC_TUNED_RX_PCODE16 = 0x35C2,
	LDE_REPC_TUNED_RX_PCODE18_19 = 0x35C2,
	LDE_REPC_TUNED_RX_PCODE20 = 0x47AE,
	LDE_REPC_TUNED_RX_PCODE21 = 0x3AE0,
	LDE_REPC_TUNED_RX_PCODE22 = 0x3850,
	LDE_REPC_TUNED_RX_PCODE23 = 0x30A2,
	LDE_REPC_TUNED_RX_PCODE24 = 0x3850,

	//LDE
	LDE_DEFAULT = 0,
	LDE_LOAD = 1,
	LDERUNE = 0,

};

#define BIAS_500_16_ZERO 10
#define BIAS_500_64_ZERO  8
#define BIAS_900_16_ZERO  7
#define BIAS_900_64_ZERO  7

/* offset from DIG_DIAG_ID in bytes */
#define EVC_CTRL_OFFSET			0x00		/* Event Counter Control */
#define EVC_CTRL_LEN			(4)
#define EVC_CTRL_MASK			0x00000003UL/* access mask to Register for bits should always be set to zero to avoid any malfunction of the device. */
#define EVC_EN					0x00000001UL/* Event Counters Enable bit */
#define EVC_CLR					0x00000002UL

/* frame length settings. */
#define FRAME_LENGTH_NORMAL   0x00
#define FRAME_LENGTH_EXTENDED 0x03

#define AUTO_CLOCK 0x00
#define XTI_CLOCK  0x01
#define PLL_CLOCK  0x02

#define SPEED_OF_LIGHT 	299792458
#define CLOCK_PERIOD 	8101246892822720032 //pow(2,40)
#ifndef bitRead
#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#define bitWrite(value, bit, bitvalue) (bitvalue ? bitSet(value, bit) : bitClear(value, bit))
#endif

/*
 chConfig_t chConfig[1] ={
 //mode 1 - S1: 7 off, 6 off, 5 off
 {
 CHANNEL_5,              // channel
 TX_PULSE_FREQ_16MHZ,    // prf
 TRX_RATE_6800KBPS,    // datarate
 3,             // preambleCode
 TX_PREAMBLE_LEN_128,  // preambleLength
 PAC_SIZE_8,      // pacSize
 0,       // non-standard SFD
 (129 + 8 - 8) //SFD timeout
 }

 };
 */

// range bias tables (500 MHz in [mm] and 900 MHz in [2mm] - to fit into bytes)
const uint8_t BIAS_500_16[] = { 198, 187, 179, 163, 143, 127, 109, 84, 59, 31,
		0, 36, 65, 84, 97, 106, 110, 112 };
const uint8_t BIAS_500_64[] = { 110, 105, 100, 93, 82, 69, 51, 27, 0, 21, 35,
		42, 49, 62, 71, 76, 81, 86 };
const uint8_t BIAS_900_16[] = { 137, 122, 105, 88, 69, 47, 25, 0, 21, 48, 79,
		105, 127, 147, 160, 169, 178, 197 };
const uint8_t BIAS_900_64[] = { 147, 133, 117, 99, 75, 50, 29, 0, 24, 45, 63,
		76, 87, 98, 116, 122, 132, 142 };

enum LEDSetting {
	BLNKEN = 1, BLINK_TIM = 0x05  // 5 * 14ms = 70ms
};
enum EventType {
	EVENT_TYPE_NONE = 1 << 0, EVENT_TYPE_TX_IRQ = 1 << 1, EVENT_TYPE_RX_IRQ = 1
			<< 2, EVENT_TYPE_GPIO = 1 << 3, EVENT_TYPE_TIMER = 1 << 4
};

enum DecaStates {
	STATE_TAG_BLINK,
	STATE_TAG_POLL,
	STATE_TAG_FINAL,
	STATE_TAG_WAIT_ANSWER,
	STATE_ANCHOR_WAIT_REQUEST,
	STATE_ANCHOR_RANGING_INIT,
	STATE_ANCHOR_RESPONSE
};

enum Timeouts {
	TIMEOUT_TAG_BLINK = 1,
	TIMEOUT_TAG_POLL = 1,
	TIMEOUT_TAG_FINAL = 1,
	TIMEOUT_TAG_WAIT_RX = 1,
	TIMEOUT_ANCHOR_WAIT_RX = 1,
	TIMEOUT_ANCHOR_RANGING_INIT = 1,
	TIMEOUT_ANCHOR_RESPONSE = 1
};

enum TimeoutType {
	TimeoutType_TAG_BLINK,
	TimeoutType_TAG_POLL,
	TimeoutType_TAG_FINAL,
	TimeoutType_TAG_WAIT_RX,
	TimeoutType_ANCHOR_WAIT_RX,
	TimeoutType_ANCHOR_RANGING_INIT,
	TimeoutType_ANCHOR_RESPONSE

};
enum MsgType {
	MSG_TYPE_NONE = 0x00,
	MSG_TYPE_BLINK = 0xC5,
	MSG_TYPE_POLL = 0x21,
	MSG_TYPE_RESPONSE = 0x10,
	MSG_TYPE_FINAL = 0x29,
	MSG_TYPE_RANGING_INIT = 0x20,
	MSG_TYPE_ERR = 0xFF
};

enum FrameCtrl {
	NONE_BLINK_FRAME_CTRL = 0X41,
	BLINK_FRAME_CTRL = 0xC5,
	LENGTH_DEST_ADDR_SHORT = 0x08,
	LENGTH_DEST_ADDR_LONG = 0x0C,
	LENGTH_SOUR_ADDR_SHORT = 0x80,
	LENGTH_SOUR_ADDR_LONG = 0xC0
};

// 5111821086 * 15.65 = 79999999995ps ~ 80ms
enum DelayedSendTime {
	SEND_DELAYED_200MS = 12779552715,
	SEND_DELAYED_80MS = 5111821086,
	SEND_DELAYED_50MS = 3194888178,
	SEND_DELAYED_20MS = 1277955271,
	SEND_DELAYED_15MS = 958466453,
	SEND_DELAYED_10MS = 638977635,
	SEND_DELAYED_5MS = 319488817,
	SEND_DELAYED_3MS = 191693289,
	SEND_DELAYED_2MS = 127795526,
	SEND_DELAYED_1MS = 63897763
};

enum SendType {
	SEND_IMMEDIATELY, SEND_DELAYED
};

struct fsmVars {
	MsgType condition;
	DecaStates thisState;
	DecaStates nextState;
	uint8_t timeoutCounter;
};

struct msgIndexes {
	uint8_t MSG_TYPE_INDEX;
	uint8_t MSG_SRC_ADDRESS;
};

struct srd_msg_dlsl {
	uint8_t frameCtrl[2];                         //  frame control bytes 00-01
	uint8_t seqNum;                               	//  sequence_number 02
	uint8_t panID[2];                             	//  PAN ID 03-04
	uint8_t destAddr[ADDR_BYTE_SIZE_L];         //  05-12 using 64 bit addresses
	uint8_t sourceAddr[ADDR_BYTE_SIZE_L];       //  13-20 using 64 bit addresses
	uint8_t messageData[MAX_USER_PAYLOAD_STRING_LL]; //  22-124 (application data and any user payload)
	uint8_t fcs[2]; //  125-126  we allow space for the CRC as it is logically part of the message. However ScenSor TX calculates and adds these bytes.
};

struct srd_msg_dsss {
	uint8_t frameCtrl[2];                         //  frame control bytes 00-01
	uint8_t seqNum;                               	//  sequence_number 02
	uint8_t panID[2];                             	//  PAN ID 03-04
	uint8_t destAddr[ADDR_BYTE_SIZE_S];             	//  05-06
	uint8_t sourceAddr[ADDR_BYTE_SIZE_S];           	//  07-08
	uint8_t messageData[MAX_USER_PAYLOAD_STRING_SS]; //  09-124 (application data and any user payload)
	uint8_t fcs[2]; //  125-126  we allow space for the CRC as it is logically part of the message. However ScenSor TX calculates and adds these bytes.
};

struct srd_msg_dlss {
	uint8_t frameCtrl[2];                         //  frame control bytes 00-01
	uint8_t seqNum;                               	//  sequence_number 02
	uint8_t panID[2];                             	//  PAN ID 03-04
	uint8_t destAddr[ADDR_BYTE_SIZE_L];         //  05-12 using 64 bit addresses
	uint8_t sourceAddr[ADDR_BYTE_SIZE_S];           	//  13-14
	uint8_t messageData[MAX_USER_PAYLOAD_STRING_LS]; //  15-124 (application data and any user payload)
	uint8_t fcs[2]; //  125-126  we allow space for the CRC as it is logically part of the message. However ScenSor TX calculates and adds these bytes.
};

struct srd_msg_dssl {
	uint8_t frameCtrl[2];                         //  frame control bytes 00-01
	uint8_t seqNum;                               	//  sequence_number 02
	uint8_t panID[2];                             	//  PAN ID 03-04
	uint8_t destAddr[ADDR_BYTE_SIZE_S];             	//  05-06
	uint8_t sourceAddr[ADDR_BYTE_SIZE_L];       //  07-14 using 64 bit addresses
	uint8_t messageData[MAX_USER_PAYLOAD_STRING_LS]; //  15-124 (application data and any user payload)
	uint8_t fcs[2]; //  125-126  we allow space for the CRC as it is logically part of the message. However ScenSor TX calculates and adds these bytes.
};

//12 octets for Minimum IEEE ID blink
struct iso_IEEE_EUI64_blink_msg {
	uint8_t frameCtrl;                         		//  frame control bytes 00
	uint8_t seqNum;                               	//  sequence_number 01
	uint8_t tagID[BLINK_FRAME_SOURCE_ADDRESS];        //  02-09 64 bit address
	uint8_t fcs[2]; //  10-11  we allow space for the CRC as it is logically part of the message. However ScenSor TX calculates and adds these bytes.
};

//18 octets for IEEE ID blink with Temp and Vbat values
struct iso_IEEE_EUI64_blinkdw_msg {
	uint8_t frameCtrl;                         		//  frame control bytes 00
	uint8_t seqNum;                               	//  sequence_number 01
	uint8_t tagID[BLINK_FRAME_SOURCE_ADDRESS];        //  02-09 64 bit addresses
	uint8_t enchead[2];	//  10-11 2 bytes (encoded header and header extension)
	uint8_t messageID;				//  12 message ID (0xD1) - DecaWave message
	uint8_t temp;										//  13 temperature value
	uint8_t vbat;										//  14 voltage value
	uint8_t gpio;										//  15 gpio status
	uint8_t fcs[2]; //  16-17  we allow space for the CRC as it is logically part of the message. However ScenSor TX calculates and adds these bytes.
};

struct ack_msg {
	uint8_t frameCtrl[2];                         //  frame control bytes 00-01
	uint8_t seqNum;                               	//  sequence_number 02
	uint8_t fcs[2];                              	//  03-04  CRC
};

//NOTE: Accumulators don't need to be stored as part of the event structure as when reading them only one RX event can happen...
//the receiver is singly buffered and will stop after a frame is received

struct event_data_t {
	MsgType msgtype;
	EventType eventType;
	uint16_t rxLength;
	union msgu {
		//holds received frame (after a good RX frame event)
		uint8_t frame[STANDARD_FRAME_SIZE];
		srd_msg_dlsl rxmsg_ll; //64 bit addresses
		srd_msg_dssl rxmsg_sl;
		srd_msg_dlss rxmsg_ls;
		srd_msg_dsss rxmsg_ss; //16 bit addresses
		ack_msg rxackmsg; //holds received ACK frame
		iso_IEEE_EUI64_blink_msg rxblinkmsg;
		iso_IEEE_EUI64_blinkdw_msg rxblinkmsgdw;
	} messageUnion;
};

// Defines for enable_clocks function
#define FORCE_SYS_XTI  0
#define ENABLE_ALL_SEQ 1
#define FORCE_SYS_PLL  2
#define READ_ACC_ON    7
#define READ_ACC_OFF   8
#define FORCE_OTP_ON   11
#define FORCE_OTP_OFF  12
#define FORCE_TX_PLL   13

#define NO_SUB 0x00
#define PANADR 0x03
#define LEN_PANADR 4
#define SYS_CFG 0x04
#define LEN_SYS_CFG 4
#define SYS_CTRL 0x0D
#define LEN_SYS_CTRL 4
#define CHAN_CTRL 0x1F
#define LEN_CHAN_CTRL 4
#define TX_FCTRL 0x08
#define LEN_TX_FCTRL 5
#define SYS_MASK 0x0E
#define LEN_SYS_MASK 4
#define LEN_SYS_STATUS 5
#define DEV_ID 0x00
#define LEN_DEVICE_ID 4
#define LEN_STAMP 5
#define TX_ANTD 0x18
#define LEN_TX_ANTD 2

/****************************************************************************//**
 * @brief Bit definitions for register PMSC
 **/
#define PMSC_ID                 0x36            /* Power Management System Control Block */
#define PMSC_LEN				(48)
/* offset from PMSC_ID in bytes */
#define	PMSC_CTRL0_OFFSET		0x00
#define	PMSC_CTRL0_LEN			(4)
#define	PMSC_CTRL0_MASK			0xF08F847FUL	/* access mask to register PMSC_CTRL0 */
#define	PMSC_CTRL0_SYSCLKS_AUTO	0x00000000UL	/* The system clock will run off the 19.2 MHz XTI clock until the PLL is calibrated and locked, then it will switch over the 125 MHz PLL clock */
#define	PMSC_CTRL0_SYSCLKS_19M	0x00000001UL	/* Force system clock to be the 19.2 MHz XTI clock. */
#define	PMSC_CTRL0_SYSCLKS_125M	0x00000002UL	/* Force system clock to the 125 MHz PLL clock. */
#define	PMSC_CTRL0_RXCLKS_AUTO	0x00000000UL	/* The RX clock will be disabled until it is required for an RX operation */
#define	PMSC_CTRL0_RXCLKS_19M	0x00000004UL	/* Force RX clock enable and sourced clock from the 19.2 MHz XTI clock */
#define	PMSC_CTRL0_RXCLKS_125M	0x00000008UL	/* Force RX clock enable and sourced from the 125 MHz PLL clock */
#define	PMSC_CTRL0_RXCLKS_OFF	0x0000000CUL	/* Force RX clock off. */
#define	PMSC_CTRL0_TXCLKS_AUTO	0x00000000UL	/* The TX clock will be disabled until it is required for a TX operation */
#define	PMSC_CTRL0_TXCLKS_19M	0x00000010UL	/* Force TX clock enable and sourced clock from the 19.2 MHz XTI clock */
#define	PMSC_CTRL0_TXCLKS_125M	0x00000020UL	/* Force TX clock enable and sourced from the 125 MHz PLL clock */
#define	PMSC_CTRL0_TXCLKS_OFF	0x00000030UL	/* Force TX clock off */
#define	PMSC_CTRL0_FACE			0x00000040UL	/* Force Accumulator Clock Enable */
/* offset from PMSC_ID in bytes */
#define	PMSC_CTRL1_OFFSET		0x04
#define	PMSC_CTRL1_LEN			(4)
#define PMSC_CTRL1_MASK			0xFC02F802UL	/* access mask to register PMSC_CTRL1 */
#define PMSC_CTRL1_ARX2INIT		0x00000002UL	/* Automatic transition from receive mode into the INIT state */
#define PMSC_CTRL1_ATXSLP		0x00000800UL	/* If this bit is set then the DW1000 will automatically transition into SLEEP or DEEPSLEEP mode after transmission of a frame */
#define PMSC_CTRL1_ARXSLP		0x00001000UL	/* this bit is set then the DW1000 will automatically transition into SLEEP mode after a receive attempt */
#define PMSC_CTRL1_SNOZE		0x00002000UL	/* Snooze Enable */
#define PMSC_CTRL1_SNOZR		0x00004000UL	/* The SNOZR bit is set to allow the snooze timer to repeat twice */
#define PMSC_CTRL1_PLLSYN		0x00008000UL	/* This enables a special 1 GHz clock used for some external SYNC modes */
#define PMSC_CTRL1_LDERUNE		0x00020000UL	/* This bit enables the running of the LDE algorithm */
#define PMSC_CTRL1_KHZCLKDIV_MASK	0xFC000000UL	/* Kilohertz clock divisor */
#define PMSC_CTRL1_PKTSEQ_DISABLE   0x00		/* writing this to PMSC CONTROL 1 register (bits 10-3) disables PMSC control of analog RF subsystems */
#define PMSC_CTRL1_PKTSEQ_ENABLE    0xE7		/* writing this to PMSC CONTROL 1 register (bits 10-3) enables PMSC control of analog RF subsystems */
/* offset from PMSC_ID in bytes */
#define	PMSC_RES1_OFFSET		0x08
/* offset from PMSC_ID in bytes */
#define	PMSC_SNOZT_OFFSET		0x0C			/* PMSC Snooze Time Register */
#define	PMSC_SNOZT_LEN			(1)
/* offset from PMSC_ID in bytes */
#define	PMSC_RES2_OFFSET		0x10
/* offset from PMSC_ID in bytes */
#define	PMSC_RES3_OFFSET		0x24
/* offset from PMSC_ID in bytes */
#define PMSC_TXFINESEQ_OFFSET        0x26		/* Writing PMSC_TXFINESEQ_DIS_MASK disables fine grain sequencing in the transmitter*/
#define PMSC_TXFINESEQ_DIS_MASK      (0x0)
#define PMSC_TXFINESEQ_EN_MASK      (0B74)      /* Writing PMSC_TXFINESEQ_EN_MASK enables fine grain sequencing in the transmitter*/
/* offset from PMSC_ID in bytes */
#define	PMSC_LEDC_OFFSET		0x28
#define	PMSC_LEDC_LEN			(4)
#define PMSC_LEDC_MASK			0x000001FFUL	/* 32-bit LED control register. */
#define PMSC_LEDC_BLINK_TIM_MASK	0x000000FFUL	/* This field determines how long the LEDs remain lit after an event that causes them to be set on. default 0x20 give 0x20 * 14mS = 400mS */
#define PMSC_LEDC_BLNKEN		0x00000100UL	/* Blink Enable. When this bit is set to 1 the LED blink feature is enabled. */

/* should be moved to lib device_access*/
#define TIMER_DECA_TOP_VALUE 		46875			// gives a second period
#define TIMER_DECA_TICKS_PER_SEC 	10			// gives 10Hz step SM tick
enum TIMER_INCREMENTS {
	TIMER_DECA_TICK_INCREMENT = 46875 / TIMER_DECA_TICKS_PER_SEC,
	TIMER_DECA_FAST_INCREMENT = 47, // gives 1ms increment for deca immediate response
	TIMER_DECA_TIMEOUT_INCREMENT = 188 // gives 4ms increment for deca immediate response
};

/* Debug */
enum DecaRole {
    ROLE_ANCHOR,
    ROLE_TAG
};

class UWBDW1000 {
public:
	UWBDW1000(SPI_Master* spiMaster);
	~UWBDW1000();

	bool Initialize(DecaRole role);

	bool stepTagStateMachine(EventType eventType, MsgType msgType);
	bool stepAnchorStateMachine(EventType eventType, MsgType msgType);
	bool (*stepStateMachine)();

	void readNetworkIdAndDeviceAddress();

	MsgType getMessageType();

	EventType getIRQEvent();
	float getResult();

	DecaRole _role;
private:
	SPI_Master* spiMaster_;

	event_data_t decaMessage;
	msgIndexes MSG_INDEXES_BLINK = { 0x00, 0x02 };
	msgIndexes MSG_INDEXES_RANGING_INIT = { 0x0F, 0x0D };
	msgIndexes MSG_INDEXES_POLL_RESPONSE_FINAL = { 0x09, 0x07 };
	fsmVars fsmVariables;
	long long int delayedSendValue;

	long long int txTsPoll;
	long long int rxTsPoll;
	long long int txTsResponse;
	long long int rxTsResponse;
	long long int txTsFinal;
	long long int rxTsFinal;

	void newReceive();
	void setEUI(uint8_t eui[]);
	void GetId(uint8_t rx_buffer[]);
	void copyReceivedData(int length);
	void clearMessageData();
	void initiateTransmitting(MsgType msgType, SendType type);

	void buildBlinkMessage(event_data_t *newMessage);
	void buildPollMessage(event_data_t *newMessage);
	void buildFinalMessage(event_data_t *newMessage);
	void buildRangingInitMessage(event_data_t *newMessage);
	void buildResponseMessage(event_data_t *newMessage);
	//void getReceivedTimestamp(long long int &timestamp);
	void getReceivedTimestamp(uint8_t *timestamp);
	//void getTransmitTimestamp(long long int &timestamp);
	void getTransmitTimestamp(uint8_t *timestamp);
	void uint8ToLong(uint8_t *time, long long int *timestamp);
	void addDelayedTime(uint8_t *timestamp);

	void stateTransition(MsgType condition, DecaStates newState);
	void checkTimeout(Timeouts timeout, DecaStates timeoutState,
			TimeoutType type);

	uint8_t prependHeaderSend(uint8_t *headerBuffer, int headerLength,
			uint8_t *bodyBuffer, int bodyLength);

	uint8_t SPI_readFromDevice(uint16_t recordNumber, uint16_t index,
			uint32_t length, uint8_t *buffer);
	uint8_t SPI_writeToDevice(uint16_t recordNumber, uint16_t index,
			uint32_t length, uint8_t *buffer);

	uint32_t toUint32_t(uint8_t rx_buffer[]);

	void initialisation();
	uint8_t getId();
	uint32_t readDevId();

	long long getSysTime();

	void delayedTransmitter();

	void setupDefaultConfig();
	void setSystemEventMask();

	void setMode(DECA_OPERATION_MODE *mode);
	void channelSetting(DecaChannel channel, decaPulseFreq freq);
	void setPreambleLength(decaPreambleLength prealen);
	void setChannel(DecaChannel channel);
	void setSTXP(DecaSmartPower stxp);
	void setPreambleCode(decaPreambleCode preacode);
	void useSmartPower(bool smartPower);
	void enableLED();
	void setGPIOforEXTTRX();
	void setGPIOforRXTXLED();
	void setupDecaAddresses();
	void setDataRate(decaDataRate rate);
	void setPulseFreq(decaPulseFreq freq);
	void setTuneRegisters();
	void writeBytes(uint8_t *reg, uint32_t tuneValue, uint8_t length);

	/* transmit and receive configuration. */
	void setData(uint8_t data[], unsigned int n);
	int getMessageLength();

	void newTransmit();
	void startTransmit();
	void startReceive();
	void clearReceiveStatus();
	void clearTransmitStatus();
	void enableClocks(uint8_t clocks);
	void softReset();
	void setIdleMode();
	void correctTimestamp(uint8_t *timestamp);

	void buildAndSendMessage(MsgType msgtype, SendType type);
	void rxEnable();

	void readSystemEventStatusRegister();
	void readSystemEventMaskRegister();
	void readPMSC0ControlRegister();
	void readPMSC1ControlRegister();
	void readTransmitFrameControlRegister();
	void readRFStatus();
	void writeRFStatus();
	void readGPIOInterruptDeBounceEnableRegister();
	void writeGPIOInterruptDeBounceEnableRegister();
	void writeLEDEnableRegister();
	void readLEDEnableRegister();
	void readDRXTune2Register();
	void writeDRXTune2Register();
	//void readNetworkIdAndDeviceAddress();
	void writeNetworkIdAndDeviceAddress();
	void readSystemConfigurationRegister();
	void writeSystemConfigurationRegister();
	void readChannelControlRegister();
	void writeChannelControlRegister();
	void writeTransmitFrameControlRegister();
	void writeSystemEventMaskRegister();
	void readSystemControlRegister();
	void writeSystemControlRegister();
	void readGPIOControlRegister();
	void writeGPIOControlRegister();
	void writePMSC0ControlRegister();

	/* receive quality information. */
	float getReceivePower();
	float getFirstPathPower();
	float getReceiveQuality();

	void rangingCalc();
	void distLog(double distance);
	void enableFrameFilter(bool isFFEN);

	void afterSending();
	void rxReset(void);

	uint8_t _sysstatus[LEN_SYS_STATUS];
	uint16_t _rxframeinfo[LEN_RX_FINFO];
	uint8_t _syscfg[LEN_SYS_CFG];
	uint8_t _sysctrl[LEN_SYS_CTRL];
	uint8_t _dbenable[LEN_GPIO_MODE];
	uint8_t _ledenable[LEN_PMSC_CTRL0];
	uint8_t _ecctrl[LEN_EC_CTRL];
	uint8_t _txfctrl[LEN_TX_FCTRL];
	uint8_t _drxtune2[LEN_DRX_TUNE2];

	uint8_t _rxfwto[2];
	uint8_t _pretoc[LEN_DRX_PRETOC];
	uint8_t _sysmask[LEN_SYS_MASK];
	uint8_t _chanctrl[LEN_CHAN_CTRL];
	uint8_t _gpioctrl[LEN_GPIO_MODE];
	uint8_t _agctune1[LEN_AGC_TUNE1];
	uint8_t _pmsc0ctrl[LEN_PMSC_CTRL0];
	uint8_t _pmsc1ctrl[LEN_PMSC_CTRL1];
	uint8_t _rfstatus[LEN_RF_TXCTRL];

	bool _smartPower;

	float result[30];
	int distCnt;
	uint8_t txTimestampPoll[LEN_STAMP];
	uint8_t rxTimestampPoll[LEN_STAMP];
	uint8_t txTimestampFinal[LEN_STAMP];
	uint8_t rxTimestampFinal[LEN_STAMP];
	uint8_t txTimestampResponse[LEN_STAMP];
	uint8_t rxTimestampResponse[LEN_STAMP];
	uint8_t _NID[LEN_NID];
	uint8_t _EUI[LEN_EUI];

	uint8_t frameSequenceNumber;

	/*! SPI */
	uint32_t read32bitoffsetreg(uint8_t regId, uint8_t regOffset);
	uint8_t write32bitoffsetreg(uint16_t regFileID, uint16_t regOffset,
			uint32_t regval);
	uint16_t read16bitoffsetreg(uint16_t regFileID, uint16_t regOffset);
	uint8_t write16bitoffsetreg(uint16_t regFileID, uint16_t regOffset,
			uint16_t regval);
	uint8_t read8bitoffsetreg(uint16_t regFileID, uint16_t regOffset);
	uint8_t write8bitoffsetreg(uint16_t regFileID, uint16_t regOffset,
			uint8_t regval);
	uint8_t readFromDevice(uint16_t recordNumber, uint16_t index,
			uint32_t length, uint8_t *buffer);
	uint8_t writeToDevice(uint16_t recordNumber, uint16_t index,
			uint32_t length, const uint8_t *buffer);

	uint16_t timeOutCounter;

	bool getBit(uint8_t data[], unsigned int n, unsigned int bit);
	void setBit(uint8_t data[], unsigned int n, unsigned int bit, bool val);

	bool _frameCheck;
	long long int sysTimeStamp[30];

	// TODO: init all missing enum values.
	extFrameLength extFrameLen;
	decaDataRate dataRate;
	decaPulseFreq pulseFreq;
	decaPreambleLength preambleLen;
	decaPACSize pacSize;
	decaPreambleCode preambleCode;
	DecaChannel channel;

	DECA_OPERATION_MODE MODE_LONGDATA_RANGE_LOWPOWER = {
			EXT_FRAMELENGTH_DEFAULT, TRX_RATE_110KBPS, TX_PULSE_FREQ_16MHZ,
			TX_PREAMBLE_LEN_2048, PAC_SIZE_64, PREAMBLE_CODE_16MHZ_3, CHANNEL_5,
			smart };
	DECA_OPERATION_MODE MODE_SHORTDATA_FAST_LOWPOWER = {
			EXT_FRAMELENGTH_DEFAULT, TRX_RATE_6800KBPS, TX_PULSE_FREQ_16MHZ,
			TX_PREAMBLE_LEN_128, PAC_SIZE_8, PREAMBLE_CODE_16MHZ_3, CHANNEL_5,
			smart };
	DECA_OPERATION_MODE MODE_LONGDATA_FAST_LOWPOWER = { EXT_FRAMELENGTH_DEFAULT,
			TRX_RATE_6800KBPS, TX_PULSE_FREQ_16MHZ, TX_PREAMBLE_LEN_1024,
			PAC_SIZE_32, PREAMBLE_CODE_16MHZ_3, CHANNEL_5, smart };
	DECA_OPERATION_MODE MODE_SHORTDATA_FAST_ACCURACY = {
			EXT_FRAMELENGTH_DEFAULT, TRX_RATE_6800KBPS, TX_PULSE_FREQ_64MHZ,
			TX_PREAMBLE_LEN_128, PAC_SIZE_8, PREAMBLE_CODE_64MHZ_9, CHANNEL_5,
			smart };
	DECA_OPERATION_MODE MODE_LONGDATA_FAST_ACCURACY = { EXT_FRAMELENGTH_DEFAULT,
			TRX_RATE_6800KBPS, TX_PULSE_FREQ_64MHZ, TX_PREAMBLE_LEN_1024,
			PAC_SIZE_32, PREAMBLE_CODE_64MHZ_9, CHANNEL_5, smart };
	DECA_OPERATION_MODE MODE_LONGDATA_RANGE_ACCURACY = {
			EXT_FRAMELENGTH_DEFAULT, TRX_RATE_110KBPS, TX_PULSE_FREQ_64MHZ,
			TX_PREAMBLE_LEN_2048, PAC_SIZE_64, PREAMBLE_CODE_64MHZ_9, CHANNEL_5,
			smart };
	DECA_OPERATION_MODE DEFAULT_MODE = { EXT_FRAMELENGTH_DEFAULT,
			TRX_RATE_6800KBPS, TX_PULSE_FREQ_16MHZ, TX_PREAMBLE_LEN_128,
			PAC_SIZE_8, PREAMBLE_CODE_16MHZ_3, CHANNEL_5, smart };
    DECA_OPERATION_MODE *selectedMode;

    //DISALLOW_COPY_AND_ASSIGN(UWBDW1000)
};

#endif /* UWBDW1000 */
