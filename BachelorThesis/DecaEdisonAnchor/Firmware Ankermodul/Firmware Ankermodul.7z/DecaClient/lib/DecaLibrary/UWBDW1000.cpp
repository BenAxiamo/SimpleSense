/*
 * UWBDW1000.cpp
 *
 *  Created on: May 8, 2015
 *      Author: Axiamo
 * */

#include "UWBDW1000.h"

#include <QDebug>
#include <QTimer>

//#include "Axiamote.h"

//extern Axiamote* axiamote;

/***************************************************************************//**
 * \brief Constructor of the UWBDW1000 class.
 * \param[in] name The name of the task.
 * \param[in] stackSize The stack size in words.
 * \param[in] priority The priority of the task.
 ******************************************************************************/
UWBDW1000::UWBDW1000(SPI_Master* spiMaster) {
	spiMaster_ = spiMaster;

	clearMessageData();

	delayedSendValue = SEND_DELAYED_80MS*5;
}

/***************************************************************************//**
 * \brief Destructor of the UWBDW1000 class.
 ******************************************************************************/
UWBDW1000::~UWBDW1000() {

	qDebug() << "Destructor UWB Start";
	qDebug() << "Destructor UWB Stop";
}

void UWBDW1000::clearMessageData() {
	uint8_t msgSize = sizeof(decaMessage);
	memset(&decaMessage, 0x00, msgSize);
}

bool UWBDW1000::Initialize(DecaRole role) {
	_role = role;
	// static anchor setup:
	/*::axiamote->controlTask->GetSettings()->enabledFeatures |= FEATURE_DECA_ROLE;
	 ::axiamote->controlTask->GetSettings()->decaEUI = 0x7D0022EA82603B9C;
	 ::axiamote->controlTask->GetSettings()->decaNID = 0x00000101DECA0202;
	 ::axiamote->storageTask->WriteSettings(::axiamote->controlTask->GetSettings());*/

	// static tag setup:
	/*::axiamote->controlTask->GetSettings()->enabledFeatures &= ~FEATURE_DECA_ROLE;
	 ::axiamote->controlTask->GetSettings()->decaEUI = 0x7D0022EA82603B9A;
	 ::axiamote->controlTask->GetSettings()->decaNID = 0x00000202DECA0101;
	 ::axiamote->storageTask->WriteSettings(::axiamote->controlTask->GetSettings());*/

	switch (_role) {
	case ROLE_ANCHOR:
		fsmVariables = {MSG_TYPE_NONE, STATE_ANCHOR_WAIT_REQUEST, STATE_ANCHOR_WAIT_REQUEST, 0};
		break;
	case ROLE_TAG:
		fsmVariables = {MSG_TYPE_NONE, STATE_TAG_BLINK, STATE_TAG_BLINK, 0};
		break;
	default:
		return -1;
	}

	frameSequenceNumber = 0;

	_frameCheck = true;

	distCnt = 0;

	uint8_t rx_buffer[LEN_REG_DEV_ID];
	GetId(rx_buffer);
	uint32_t DevID = toUint32_t(rx_buffer); // 00001200
	// check the response for validity
	if (DevID == DW1000_DEV_ID) {
		setupDefaultConfig();
		timeOutCounter = 0;

		return true;
	} else {
		return false;
	}

	//transmitter();
	// delayedTransmitter();

}



void UWBDW1000::stateTransition(MsgType condition, DecaStates newState) {
	fsmVariables.condition = condition;
	fsmVariables.nextState = newState;
	fsmVariables.timeoutCounter = 0;
	fsmVariables.thisState = STATE_TAG_WAIT_ANSWER;
}

void UWBDW1000::checkTimeout(Timeouts timeout, DecaStates timeoutState,
		TimeoutType type) {

	if (fsmVariables.timeoutCounter++ == timeout) {
		if (type == TimeoutType_TAG_WAIT_RX) {
			int foo = 0;
			foo++;
		}
		if (type == TimeoutType_TAG_BLINK) {
			int foo = 0;
			foo++;
		}
		if (type == TimeoutType_TAG_FINAL) {
			int foo = 0;
			foo++;
		}

		if (type == TimeoutType_ANCHOR_RESPONSE) {
			int foo = 0;
			foo++;
		}
		if (type == TimeoutType_ANCHOR_RESPONSE) {
			int foo = 0;
			foo++;
		}
		if (type == TimeoutType_ANCHOR_RANGING_INIT) {
			int foo = 0;
			foo++;
		}
		fsmVariables.timeoutCounter = 0;
		fsmVariables.thisState = timeoutState;

		setNextTimerTime(TIMER_DECA_TIMEOUT_INCREMENT);
		//::axiamote->decawaveTask->setNextTimerTime(
		//		TIMER_DECA_TIMEOUT_INCREMENT);
	}
}

float UWBDW1000::getResult() {
	return result[0];
}

bool UWBDW1000::stepTagStateMachine(EventType eventType, MsgType msgType) {
	switch (fsmVariables.thisState) {
	case STATE_TAG_BLINK:
		switch (eventType) {
		case EVENT_TYPE_TIMER:
			qDebug() << "TAG_BLINK_TIMER";
			if (fsmVariables.timeoutCounter == 0) {
				buildAndSendMessage(MSG_TYPE_BLINK, SEND_IMMEDIATELY);
			}
			checkTimeout(TIMEOUT_TAG_BLINK, STATE_TAG_BLINK,
					TimeoutType_TAG_BLINK);
			break;
		case EVENT_TYPE_TX_IRQ:
			qDebug() << "TAG_BLINK_TX";
			stateTransition(MSG_TYPE_RANGING_INIT, STATE_TAG_POLL);
			setNextTimerTime(TIMER_DECA_FAST_INCREMENT);
			//::axiamote->decawaveTask->setNextTimerTime(
			//		TIMER_DECA_FAST_INCREMENT);
			break;
		default:
			qDebug() << "TAG_BLINK_DEF";
			break;
		}
		break;

	case STATE_TAG_POLL:
		switch (eventType) {
		case EVENT_TYPE_TIMER:
			qDebug() << "TAG_POLL_TIMER";
			RGBColorSet(COLOR_BLACK);
			//axiamote->ledTask->RGBColorSet(COLOR_BLACK);
			if (fsmVariables.timeoutCounter == 0) {
				buildAndSendMessage(MSG_TYPE_POLL, SEND_IMMEDIATELY);
			}
			checkTimeout(TIMEOUT_TAG_POLL, STATE_TAG_BLINK,
					TimeoutType_TAG_POLL);
			break;
		case EVENT_TYPE_TX_IRQ:
			qDebug() << "TAG_POLL_RX";
			getTransmitTimestamp(txTimestampPoll);
			stateTransition(MSG_TYPE_RESPONSE, STATE_TAG_FINAL);
			break;
		default:
			qDebug() << "TAG_POLL_DEF";
			break;
		}
		break;

	case STATE_TAG_FINAL:
		switch (eventType) {
		case EVENT_TYPE_TIMER:
			qDebug() << "TAG_FINAL_TIMER";
			if (fsmVariables.timeoutCounter == 0) {
				buildAndSendMessage(MSG_TYPE_FINAL, SEND_DELAYED);
			}
			checkTimeout(TIMEOUT_TAG_FINAL, STATE_TAG_BLINK,
					TimeoutType_TAG_FINAL);
			break;
		case EVENT_TYPE_TX_IRQ:
			qDebug() << "TAG_FINAL_TX";
			fsmVariables.thisState = STATE_TAG_POLL;
			RGBColorSet(COLOR_RED);
			//axiamote->ledTask->RGBColorSet(COLOR_RED);
			fsmVariables.timeoutCounter = 0;
			setNextTimerTime(TIMER_DECA_FAST_INCREMENT);
			//::axiamote->decawaveTask->setNextTimerTime(
			//		TIMER_DECA_FAST_INCREMENT);
			break;
		default:
			qDebug() << "TAG_FINAL_DEF";
			break;
		}
		break;

	case STATE_TAG_WAIT_ANSWER:
		switch (eventType) {
		case EVENT_TYPE_RX_IRQ:
			qDebug() << "TAG_WAIT_RX";
			// if message type of received message is same as fsmVariables.condition, then goto next state
			if (msgType == fsmVariables.condition) {
				fsmVariables.thisState = fsmVariables.nextState;
				fsmVariables.timeoutCounter = 0;

				sysTimeStamp[1] = getSysTime();
				setNextTimerTime(TIMER_DECA_FAST_INCREMENT);
				//::axiamote->decawaveTask->setNextTimerTime(
				//		TIMER_DECA_FAST_INCREMENT);
			}
			break;
		case EVENT_TYPE_TIMER:
			qDebug() << "TAG_WAIT_TIMER";
			checkTimeout(TIMEOUT_TAG_WAIT_RX, STATE_TAG_BLINK,
					TimeoutType_TAG_WAIT_RX);

			break;
		default:
			qDebug() << "TAG_WAIT_DEF";
			break;
		}
		break;
	default:
		qDebug() << "TAG_DEF";
		break;
	}

	if (eventType == EVENT_TYPE_TIMER) {
		return false;
	}
	return true;
}



bool UWBDW1000::stepAnchorStateMachine(EventType eventType, MsgType msgType) {
	switch (fsmVariables.thisState) {
	case STATE_ANCHOR_WAIT_REQUEST:
		rxEnable();
		RGBColorSet(COLOR_BLACK);
		//axiamote->ledTask->RGBColorSet(COLOR_BLACK);
		switch (eventType) {
		case EVENT_TYPE_TIMER:
			checkTimeout(TIMEOUT_ANCHOR_WAIT_RX, STATE_ANCHOR_WAIT_REQUEST,
					TimeoutType_ANCHOR_WAIT_RX);
			qDebug() << "ANC_WAIT_TIMER";
			break;
		case EVENT_TYPE_RX_IRQ:
			switch (msgType) {
			case MSG_TYPE_BLINK:
				qDebug() << "ANC_WAIT_RX_BLINK";
				// for now, this is the immediate state transition
				fsmVariables.thisState = STATE_ANCHOR_RANGING_INIT;
				fsmVariables.timeoutCounter = 0;
				setNextTimerTime(TIMER_DECA_FAST_INCREMENT);
				//::axiamote->decawaveTask->setNextTimerTime(
				//		TIMER_DECA_FAST_INCREMENT);
				break;
			case MSG_TYPE_POLL:
				qDebug() << "ANC_WAIT_RX_POLL";
				// for now, this is the immediate state transition
				fsmVariables.thisState = STATE_ANCHOR_RESPONSE;
				fsmVariables.timeoutCounter = 0;
				setNextTimerTime(TIMER_DECA_FAST_INCREMENT);
				//::axiamote->decawaveTask->setNextTimerTime(
				//		TIMER_DECA_FAST_INCREMENT);

				break;
			case MSG_TYPE_FINAL:
				// stay in this state and trigger ranging calculation
				fsmVariables.timeoutCounter = 0;
				RGBColorSet(COLOR_RED);
				qDebug() << "ANC_WAIT_RX_FINAL";
				//axiamote->ledTask->RGBColorSet(COLOR_RED);
				rangingCalc();
				break;
			default:
				// TODO: handle invalid message types
				qDebug() << "ANC_WAIT_RX_DEF";
				break;
			}
			break;
		default:
			qDebug() << "ANC_WAIT_DEF";
			break;
		}
		break;

	case STATE_ANCHOR_RANGING_INIT:
		switch (eventType) {
		case EVENT_TYPE_TIMER:
			qDebug() << "ANC_RANG_TIMER";
			if (fsmVariables.timeoutCounter == 0) {
				buildAndSendMessage(MSG_TYPE_RANGING_INIT, SEND_IMMEDIATELY);
			}
			checkTimeout(TIMEOUT_ANCHOR_RANGING_INIT, STATE_ANCHOR_WAIT_REQUEST,
					TimeoutType_ANCHOR_RANGING_INIT);
			break;
		case EVENT_TYPE_TX_IRQ:
			qDebug() << "ANC_RANG_TX";
			// for now, this is the immediate state transition
			fsmVariables.thisState = STATE_ANCHOR_WAIT_REQUEST;
			fsmVariables.timeoutCounter = 0;
			setNextTimerTime(TIMER_DECA_FAST_INCREMENT);
			//::axiamote->decawaveTask->setNextTimerTime(
			//		TIMER_DECA_FAST_INCREMENT);
			break;
		default:
			qDebug() << "ANC_RANG_DEF";
			break;
		}
		break;

	case STATE_ANCHOR_RESPONSE:
		switch (eventType) {
		case EVENT_TYPE_TIMER:
			qDebug() << "ANC_RESP_TIMER";
			if (fsmVariables.timeoutCounter == 0) {
				buildAndSendMessage(MSG_TYPE_RESPONSE, SEND_DELAYED);
			}
			checkTimeout(TIMEOUT_ANCHOR_RESPONSE, STATE_ANCHOR_WAIT_REQUEST,
					TimeoutType_ANCHOR_RESPONSE);
			break;
		case EVENT_TYPE_TX_IRQ:
			qDebug() << "ANC_RESP_TX";
			getTransmitTimestamp(txTimestampResponse);
			// for now, this is the immediate state transition
			fsmVariables.thisState = STATE_ANCHOR_WAIT_REQUEST;
			fsmVariables.timeoutCounter = 0;
			setNextTimerTime(TIMER_DECA_FAST_INCREMENT);
			//::axiamote->decawaveTask->setNextTimerTime(
			//		TIMER_DECA_FAST_INCREMENT);
			break;
		default:
			qDebug() << "ANC_RESP_DEF";
			break;
		}
		break;

	default:
		qDebug() << "ANC_DEF";
		break;
	}
	if (eventType == EVENT_TYPE_TIMER) {
		return false;
	}
	return true;
}

EventType UWBDW1000::getIRQEvent() {
	readSystemEventStatusRegister();
	bool irqBit = _sysstatus[0] & (1 << 0);
	bool TXFRS = _sysstatus[0] & (1 << 7);
	bool RXDFR = _sysstatus[1] & (1 << 5);

	if (TXFRS & irqBit) {
		clearTransmitStatus();
		return EVENT_TYPE_TX_IRQ;
	} else if (RXDFR & irqBit) {
		clearReceiveStatus();
		// disable rx when it already received one frame, rx will be enabled automatically after sending responsemsg
		readSystemControlRegister();
		setBit(_sysctrl, LEN_SYS_CTRL, TRXOFF_BIT, true);
		writeSystemControlRegister();
		return EVENT_TYPE_RX_IRQ;
	}
	clearTransmitStatus();
	clearReceiveStatus();
	return EVENT_TYPE_NONE;
}

void UWBDW1000::rangingCalc() {
	uint8ToLong(txTimestampPoll, &txTsPoll);
	uint8ToLong(rxTimestampPoll, &rxTsPoll);
	uint8ToLong(txTimestampResponse, &txTsResponse);
	uint8ToLong(rxTimestampResponse, &rxTsResponse);
	uint8ToLong(txTimestampFinal, &txTsFinal);
	uint8ToLong(rxTimestampFinal, &rxTsFinal);

	long long int Tround1 = rxTsResponse - txTsPoll;
	long long int Treply1 = txTsResponse - rxTsPoll;
	long long int Treply2 = txTsFinal - rxTsResponse;
	long long int Tround2 = rxTsFinal - txTsResponse;

	if (Tround1 < 0) {
		Tround1 = Tround1 + CLOCK_PERIOD;
	}
	if (Treply1 < 0) {
		Treply1 = Treply1 + CLOCK_PERIOD;
	}
	if (Treply2 < 0) {
		Treply2 = Treply2 + CLOCK_PERIOD;
	}
	if (Tround2 < 0) {
		Tround2 = Tround2 + CLOCK_PERIOD;
	}

	double TOF = (Tround1 * Tround2 - Treply1 * Treply2)
			/ (Tround1 + Tround2 + Treply1 + Treply2) * 15.65 * pow(10, -6);

	double distance = TOF * pow(10, -6) * SPEED_OF_LIGHT;

	distLog(distance);
}

void UWBDW1000::distLog(double distance) {
	if (distCnt < 30) {
		result[distCnt++] = distance;
	} else if (distCnt == 30) {
		distCnt = 0;
	}
	qDebug() << "------------------> Distance: " << distance;
}

void UWBDW1000::rxReset(void) {
	uint8_t resetrx = 0xe0;
//set rx reset
	write8bitoffsetreg(PMSC_ID, 0x3, resetrx);

	resetrx = 0xf0; //clear RX reset
	write8bitoffsetreg(PMSC_ID, 0x3, resetrx);
}

MsgType UWBDW1000::getMessageType() {
	decaMessage.msgtype = MSG_TYPE_NONE;
	decaMessage.rxLength = getMessageLength();
	if(decaMessage.rxLength > 40) {
		qDebug() << " Spurious interrupt?" << decaMessage.rxLength;
		return MSG_TYPE_ERR;
	}
	SPI_readFromDevice(RX_BUFFER, NO_SUB, decaMessage.rxLength,
			decaMessage.messageUnion.frame);
	switch (decaMessage.rxLength) {

	case FLENGTH_MSG_BLINK:
		if (decaMessage.messageUnion.rxblinkmsg.frameCtrl == MSG_TYPE_BLINK) {
			decaMessage.msgtype = MSG_TYPE_BLINK;
		} else {
			decaMessage.msgtype = MSG_TYPE_ERR;
		}
		break;
	case FLENGTH_MSG_RANGINGINIT:
		if (decaMessage.messageUnion.rxmsg_ls.messageData[0]
				== MSG_TYPE_RANGING_INIT) {
			decaMessage.msgtype = MSG_TYPE_RANGING_INIT;
		} else {
			decaMessage.msgtype = MSG_TYPE_ERR;
		}
		break;
	case FLENGTH_MSG_POLL:
	case FLENGTH_MSG_RESPONSE:
	case FLENGTH_MSG_FINAL:
		switch (decaMessage.messageUnion.rxmsg_ss.messageData[0]) {
		case MSG_TYPE_POLL:
			decaMessage.msgtype = MSG_TYPE_POLL;
			getReceivedTimestamp(rxTimestampPoll);
			break;
		case MSG_TYPE_RESPONSE:
			decaMessage.msgtype = MSG_TYPE_RESPONSE;
			getReceivedTimestamp(rxTimestampResponse);
			break;
		case MSG_TYPE_FINAL:
			decaMessage.msgtype = MSG_TYPE_FINAL;
			getReceivedTimestamp(rxTimestampFinal);

			memcpy(txTimestampPoll,
					&decaMessage.messageUnion.rxmsg_ss.messageData[1],
					LEN_STAMP);
			memcpy(rxTimestampResponse,
					&decaMessage.messageUnion.rxmsg_ss.messageData[6],
					LEN_STAMP);
			memcpy(txTimestampFinal,
					&decaMessage.messageUnion.rxmsg_ss.messageData[11],
					LEN_STAMP);
			break;
		default:
			decaMessage.msgtype = MSG_TYPE_ERR;
			break;
		}
		break;
	default:
		decaMessage.msgtype = MSG_TYPE_ERR;
		break;
	}
	return decaMessage.msgtype;
}

void UWBDW1000::GetId(uint8_t rx_buffer[]) {
	SPI_readFromDevice(DW1000_REG_DEV_ID, 0, LEN_REG_DEV_ID, rx_buffer); //read device ID
}

uint32_t UWBDW1000::toUint32_t(uint8_t rx_buffer[]) {
	uint32_t rx_buffer_32 = ((rx_buffer[3] & 0x000000ff) << 24)
			| ((rx_buffer[2] & 0x000000ff) << 16)
			| ((rx_buffer[1] & 0x000000ff) << 8)
			| ((rx_buffer[0] & 0x000000ff));
	return rx_buffer_32;
}

void UWBDW1000::enableClocks(uint8_t clocks) {
	uint8_t reg[2] = { 0 };
	switch (clocks) {
	case ENABLE_ALL_SEQ:
		reg[0] = 0x00;
		reg[1] = reg[1] & 0xfe;
		break;
	case FORCE_SYS_XTI:
		//system and rx
		reg[0] = 0x01 | (reg[0] & 0xfc);
		break;
	case FORCE_SYS_PLL:
		//system
		reg[0] = 0x02 | (reg[0] & 0xfc);
		break;
	case READ_ACC_ON:
		reg[0] = 0x48 | (reg[0] & 0xb3);
		reg[1] = 0x80 | reg[1];
		break;
	case READ_ACC_OFF:
		reg[0] = reg[0] & 0xb3;
		reg[1] = 0x7f & reg[1];
		break;
	case FORCE_OTP_ON:
		reg[1] = 0x02 | reg[1];
		break;
	case FORCE_OTP_OFF:
		reg[1] = reg[1] & 0xfd;
		break;
	case FORCE_TX_PLL:
		reg[0] = 0x20 | (reg[0] & 0xcf);
		break;
	default:
		break;
	}

// Need to write lower byte separately before setting the higher byte(s)
	SPI_writeToDevice(PMSC_ID, PMSC_CTRL0_OFFSET, 1, &reg[0]);
	SPI_writeToDevice(PMSC_ID, 0x1, 1, &reg[1]);
}
//only use softreset
void UWBDW1000::softReset() {
	uint8_t temp[1] = { 0 };
	enableClocks(FORCE_SYS_XTI);

//reset HIF, TX, RX and PMSC
	SPI_readFromDevice(PMSC_ID, 0x3, 1, temp);

	temp[0] &= 0x0F;
	SPI_writeToDevice(PMSC_ID, 0x3, 1, &temp[0]);

//DW1000 needs a 10us sleep to let clk PLL lock after reset - the PLL will automatically lock after the reset
	/* Note: Task Delay from DeviceAccess */
	vTaskDelay(1);
//Can also poll the PLL lock flag, but then the SPI needs to be < 3MHz !!

	temp[0] |= 0xF0;
	SPI_writeToDevice(PMSC_ID, 0x3, 1, &temp[0]);
	setIdleMode();
}

void UWBDW1000::setIdleMode() {
	memset(_sysctrl, 0, LEN_SYS_CTRL);
	setBit(_sysctrl, LEN_SYS_CTRL, TRXOFF_BIT, true);

	SPI_writeToDevice(SYS_CTRL, NO_SUB, LEN_SYS_CTRL, _sysctrl);
}
void UWBDW1000::setupDefaultConfig() {
	enableClocks(AUTO_CLOCK);
	softReset();
	enableLED();
	setGPIOforRXTXLED();
	setGPIOforEXTTRX();
	setMode(&DEFAULT_MODE);
// the default configuration(16MHz, 6.8Mbps, preamble 128, channel 5)
// 10.LDE_LOAD
	write16bitoffsetreg(PMSC_ID, PMSC_CTRL0_OFFSET, 0x0301);
	write16bitoffsetreg(OTP_IF_ID, OTP_CTRL, 0x8000);
	/* Note: Task Delay from DeviceAccess */
	vTaskDelay(1);
	write16bitoffsetreg(PMSC_ID, PMSC_CTRL0_OFFSET, 0x0200);
//
//	// set preamble code
//	uint32_t chanctrl = read32bitoffsetreg(CHAN_CTRL_ID, 0);
//	chanctrl &= 0x003FFFFF;	//*set TNSSFD,RNSSFD  to 0
//	chanctrl |= (3 << 22) | (3 << 27);	//*set TX/RX_PCODE to 11
//	chanctrl |= (1 << 17);
//	write32bitoffsetreg(CHAN_CTRL_ID, 0, chanctrl);
//
	readTransmitFrameControlRegister();
// set Non-SFD
	readChannelControlRegister();
	_chanctrl[2] = 0xC4;
	writeChannelControlRegister();
	readSystemConfigurationRegister();

// setBit(_syscfg, LEN_SYS_CFG, RXM110K_BIT, true);
	setBit(_syscfg, LEN_SYS_CFG, RXAUTR_BIT, true);
// setBit(_syscfg, LEN_SYS_CFG, FCS_INIT2F_BIT, true);
// setBit(_syscfg, LEN_SYS_CFG, RXWTOE_BIT, true);
// setBit(_syscfg, LEN_SYS_CFG, AUTOACK_BIT, true);
// setBit(_syscfg, LEN_SYS_CFG, DIS_DRXB_BIT, false);

	setBit(_syscfg, LEN_SYS_CFG, DIS_STXP_BIT, false);
	writeSystemConfigurationRegister();
	readSystemConfigurationRegister();
	readPMSC1ControlRegister();
//Event counter control
	write8bitoffsetreg(DIG_DIAG_ID, EVC_CTRL_OFFSET, 0x01);

//antenna delay
	//TODO: calibrate antenna delay
	write16bitoffsetreg(TX_ANTD_ID, 0, 0xAA00);
	setSystemEventMask();

	/*  */
	//spiMaster_->SPI_setup(SPI_USART0, 5000000);
	setupDecaAddresses();

	if (_role == ROLE_ANCHOR) {
		enableFrameFilter(false);
		//bool (UWBDW1000::*stepStateMachine)(bool) = stepAnchorStateMachine;

	} else {
		enableFrameFilter(true);
	}
}
void UWBDW1000::enableLED() {
	readLEDEnableRegister();
	_ledenable[1] |= BLNKEN;
	_ledenable[0] = BLINK_TIM; //determines how long the LEDs remain lit
	writeLEDEnableRegister();

	readPMSC0ControlRegister();
	_pmsc0ctrl[2] |= (PMSC_CTRL0_GPDCE_8 + PMSC_CTRL0_KHZCLKEN_8);
	writePMSC0ControlRegister();
}

void UWBDW1000::setGPIOforEXTTRX() {
	uint8_t buf[GPIO_MODE_LEN];
	SPI_readFromDevice(GPIO_MODE, NO_SUB, LEN_GPIO_MODE, buf);
	buf[2] |= (GPIO_MSGP5_EXTTXE_8 + GPIO_MSGP6_EXTRXE_8);
	SPI_writeToDevice(GPIO_MODE, NO_SUB, LEN_GPIO_MODE, buf);
}

void UWBDW1000::setGPIOforRXTXLED() {
	uint8_t buf[GPIO_MODE_LEN];
	SPI_readFromDevice(GPIO_MODE, NO_SUB, LEN_GPIO_MODE, buf);
	buf[1] |= (GPIO_MSGP3_TXLED_8 + GPIO_MSGP2_RXLED_8); //TX LED, RX_on LED
	buf[0] |= GPIO_MSGP0_RXOKLED_8; //RX_OK_LED
	SPI_writeToDevice(GPIO_MODE, NO_SUB, LEN_GPIO_MODE, buf);
}
void UWBDW1000::setDataRate(decaDataRate rate) {
	uint8_t dataRate = (uint8_t) rate;
	dataRate &= 0x03;
	_txfctrl[1] &= 0x83;
	_txfctrl[1] |= (uint8_t)((rate << 5) & 0xFF);
	// special 110kbps flag
	if (rate == TRX_RATE_110KBPS) {
		setBit(_syscfg, LEN_SYS_CFG, RXM110K_BIT, true);
	} else {
		setBit(_syscfg, LEN_SYS_CFG, RXM110K_BIT, false);
	}
	// SFD mode and type (non-configurable, as in Table )
	if (rate == TRX_RATE_6800KBPS) {
		setBit(_chanctrl, LEN_CHAN_CTRL, DWSFD_BIT, false);
		setBit(_chanctrl, LEN_CHAN_CTRL, TNSSFD_BIT, false);
		setBit(_chanctrl, LEN_CHAN_CTRL, RNSSFD_BIT, false);
	} else {
		setBit(_chanctrl, LEN_CHAN_CTRL, DWSFD_BIT, true);
		setBit(_chanctrl, LEN_CHAN_CTRL, TNSSFD_BIT, true);
		setBit(_chanctrl, LEN_CHAN_CTRL, RNSSFD_BIT, true);

	}
	uint8_t sfdLength;
	if (rate == TRX_RATE_6800KBPS) {
		sfdLength = 0x08;
	} else if (rate == TRX_RATE_850KBPS) {
		sfdLength = 0x10;
	} else {
		sfdLength = 0x40;
	}
	SPI_writeToDevice(USR_SFD, SFD_LENGTH_SUB, LEN_SFD_LENGTH, &sfdLength);
	selectedMode->dataRate = rate;
}
void UWBDW1000::setPulseFreq(decaPulseFreq freq) {
	uint8_t frequency = (uint8_t) freq;
	frequency &= 0x03;
	_txfctrl[2] &= 0xFC;
	_txfctrl[2] |= (uint8_t)(frequency & 0xFF);
	_chanctrl[2] &= 0xF3;
	_chanctrl[2] |= (uint8_t)((frequency << 2) & 0xFF);
	selectedMode->pulseFreq = freq;
}
void UWBDW1000::setPreambleLength(decaPreambleLength prealen) {
	uint8_t preLen = (uint8_t) prealen;
	preLen &= 0x0F;
	selectedMode->preambleLen = (decaPreambleLength) preLen;
	_txfctrl[2] &= 0xC3;
	_txfctrl[2] |= (uint8_t)((prealen << 2) & 0xFF);
	if (prealen == TX_PREAMBLE_LEN_64 || prealen == TX_PREAMBLE_LEN_128) {
		selectedMode->pacSize = PAC_SIZE_8;
	} else if (prealen == TX_PREAMBLE_LEN_256
			|| prealen == TX_PREAMBLE_LEN_512) {
		selectedMode->pacSize = PAC_SIZE_16;
	} else if (prealen == TX_PREAMBLE_LEN_1024) {
		selectedMode->pacSize = PAC_SIZE_32;
	} else {
		selectedMode->pacSize = PAC_SIZE_64;
	}
	selectedMode->preambleLen = prealen;
}
void UWBDW1000::setPreambleCode(decaPreambleCode preacode) {
	selectedMode->preambleCode = preacode;

	uint8_t preambleCode = (uint8_t) preacode;
	preambleCode &= 0x1F;
	_chanctrl[2] &= 0x3F;
	_chanctrl[2] |= ((preambleCode << 6) & 0xFF);//set TX_PCODE
	_chanctrl[3] = 0x00;
	_chanctrl[3] =
			((((preambleCode >> 2) & 0x07) | (preambleCode << 3)) & 0xFF); //set RX_PCODE
}
void UWBDW1000::setChannel(DecaChannel channel) {
	uint8_t selectedChannel = (uint8_t) channel;
	selectedChannel &= 0xF;
	_chanctrl[0] = ((selectedChannel | (selectedChannel << 4)) & 0xFF);
	selectedMode->channel = channel;
}
void UWBDW1000::setSTXP(DecaSmartPower stxp){
	readSystemConfigurationRegister();
	setBit(_syscfg, LEN_SYS_CFG, DIS_STXP_BIT,selectedMode->stxp);
}
void UWBDW1000::setMode(DECA_OPERATION_MODE *mode) {
	selectedMode = mode;

	// first read all relevant registers
	readChannelControlRegister();
	readTransmitFrameControlRegister();
	readSystemConfigurationRegister();

	setDataRate(selectedMode->dataRate);
	setPulseFreq(selectedMode->pulseFreq);
	setPreambleCode(selectedMode->preambleCode);
	setPreambleLength(selectedMode->preambleLen);
	setChannel(selectedMode->channel);
	setSTXP(selectedMode->stxp);
	// finally send all relevant registers back to deca module
	writeChannelControlRegister();
	writeTransmitFrameControlRegister();
	writeSystemConfigurationRegister();
	// TODO: find out why it troubles us
	setTuneRegisters();
}

void UWBDW1000::channelSetting(DecaChannel channel, decaPulseFreq pulsefreq) {
	switch (pulsefreq) {

	case TX_PULSE_FREQ_16MHZ:
		switch (channel) {
		case CHANNEL_1:

			break;
		case CHANNEL_2:

			break;
		case CHANNEL_3:

			break;
		case CHANNEL_4:

			break;
		case CHANNEL_5:

			break;
		case CHANNEL_7:

			break;

		}
		break;
	case TX_PULSE_FREQ_64MHZ:
		break;

		/*case CHANNEL_1: //Center frequency 3494.4MHz, Bandwidth 499.2Mhz
		 if (pulsefreq == TX_PULSE_FREQ_16MHZ) {
		 setPreambleCode(PREAMBLE_CODE_16MHZ_1);
		 //setPreambleCode(PREAMBLE_CODE_16MHZ_2);

		 } else {
		 setPreambleCode(PREAMBLE_CODE_64MHZ_9);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_10);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_11);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_12);
		 }
		 break;
		 case CHANNEL_2: //Center frequency 3993.6MHz, Bandwidth 499.2Mhz
		 if (pulsefreq == TX_PULSE_FREQ_16MHZ) {
		 setPreambleCode(PREAMBLE_CODE_16MHZ_3);
		 //setPreambleCode(PREAMBLE_CODE_16MHZ_4);

		 } else {
		 setPreambleCode(PREAMBLE_CODE_64MHZ_9);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_10);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_11);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_12);
		 }
		 break;
		 case CHANNEL_3: //Center frequency 4492.8MHz, Bandwidth 499.2Mhz
		 if (pulsefreq == TX_PULSE_FREQ_16MHZ) {
		 setPreambleCode(PREAMBLE_CODE_16MHZ_5);
		 //setPreambleCode(PREAMBLE_CODE_16MHZ_6);

		 } else {
		 setPreambleCode(PREAMBLE_CODE_64MHZ_9);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_10);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_11);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_12);
		 }
		 break;
		 case CHANNEL_4: //Center frequency 3993.6MHz, Bandwidth 1331.2Mhz*    *The DW1000 has a maximum receive bandwidth of 900 MHz
		 if (pulsefreq == TX_PULSE_FREQ_16MHZ) {
		 setPreambleCode(PREAMBLE_CODE_16MHZ_7);
		 //setPreambleCode(PREAMBLE_CODE_16MHZ_8);

		 } else {
		 setPreambleCode(PREAMBLE_CODE_64MHZ_17);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_18);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_19);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_20);
		 }
		 break;
		 case CHANNEL_5: //Center frequency 6489.6MHz, Bandwidth 499.2Mhz*
		 if (pulsefreq == TX_PULSE_FREQ_16MHZ) {
		 setPreambleCode(PREAMBLE_CODE_16MHZ_3);
		 //setPreambleCode(PREAMBLE_CODE_16MHZ_4);

		 } else {
		 setPreambleCode(PREAMBLE_CODE_64MHZ_9);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_10);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_11);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_12);
		 }
		 break;
		 case CHANNEL_7: //Center frequency 6489.6, Bandwidth 1081.6Mhz*       *The DW1000 has a maximum receive bandwidth of 900 MHz
		 if (pulsefreq == TX_PULSE_FREQ_16MHZ) {
		 setPreambleCode(PREAMBLE_CODE_16MHZ_7);
		 //setPreambleCode(PREAMBLE_CODE_16MHZ_8);

		 } else {
		 setPreambleCode(PREAMBLE_CODE_64MHZ_17);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_18);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_19);
		 //				setPreambleCode(PREAMBLE_CODE_64MHZ_20);
		 }
		 break;*/

	}
}
void UWBDW1000::writeBytes(uint8_t *reg, uint32_t tuneValue, uint8_t length) {
	memcpy(reg, &tuneValue, length);
}

void UWBDW1000::setTuneRegisters() {
	// these registers are going to be tuned/configured
	uint8_t agctune1[LEN_AGC_TUNE1];
	uint8_t agctune2[LEN_AGC_TUNE2];
	uint8_t agctune3[LEN_AGC_TUNE3];
	uint8_t drxtune0b[LEN_DRX_TUNE0b];
	uint8_t drxtune1a[LEN_DRX_TUNE1a];
	uint8_t drxtune1b[LEN_DRX_TUNE1b];
	uint8_t drxtune2[LEN_DRX_TUNE2];
	uint8_t drxtune4H[LEN_DRX_TUNE4H];
	uint8_t ldecfg1[LEN_LDE_CFG1];
	uint8_t ldecfg2[LEN_LDE_CFG2];
	uint8_t lderepc[LEN_LDE_REPC];
	uint8_t txpower[LEN_TX_POWER];
	uint8_t rfrxctrlh[LEN_RF_RXCTRLH];
	uint8_t rftxctrl[LEN_RF_TXCTRL];
	uint8_t tcpgdelay[LEN_TC_PGDELAY];
	uint8_t fspllcfg[LEN_FS_PLLCFG];
	uint8_t fsplltune[LEN_FS_PLLTUNE];
//	uint8_t fsxtalt[LEN_FS_XTALT];
	// AGC_TUNE1

	if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
		writeBytes(agctune1, AGC_TUNE1_TUNED_RXPRF16, LEN_AGC_TUNE1);

	} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
		writeBytes(agctune1, AGC_TUNE1_TUNED_RXPRF64, LEN_AGC_TUNE1);
	} else {
		// TODO proper error/warning handling
	}
	// AGC_TUNE2
		writeBytes(agctune2, AGC_TUNE2_TUNED, LEN_AGC_TUNE2);
	// AGC_TUNE3
		//need to check sfd
		writeBytes(agctune3, AGC_TUNE3_TUNED, LEN_AGC_TUNE3);
	// DRX_TUNE0b (already optimized according to Table 20 of user manual)
	if (selectedMode->dataRate == TRX_RATE_110KBPS) {
		writeBytes(drxtune0b, DRX_TUNE0B_TUNED_DATARATE110_NON_SFD, LEN_DRX_TUNE0b);
	} else if (selectedMode->dataRate == TRX_RATE_850KBPS) {
		writeBytes(drxtune0b, DRX_TUNE0B_TUNED_DATARATE850_NON_SFD, LEN_DRX_TUNE0b);
	} else if (selectedMode->dataRate == TRX_RATE_6800KBPS) {
		writeBytes(drxtune0b, DRX_TUNE0B_TUNED_DATARATE6800_SFD, LEN_DRX_TUNE0b);//SFD is recommended for 6.8Mbps  ref. user manual Table 20: Recommended SFD sequence configurations for best performance
	} else {
		// TODO proper error/warning handling
	}
	// DRX_TUNE1a
	if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
		writeBytes(drxtune1a, DRX_TUNE1A_TUNED_RXPRF16, LEN_DRX_TUNE1a);
	} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
		writeBytes(drxtune1a, DRX_TUNE1A_TUNED_RXPRF64, LEN_DRX_TUNE1a);
	} else {
		// TODO proper error/warning handling
	}
	// DRX_TUNE1b
	if (selectedMode->preambleLen == TX_PREAMBLE_LEN_1536
			|| selectedMode->preambleLen == TX_PREAMBLE_LEN_2048
			|| selectedMode->preambleLen == TX_PREAMBLE_LEN_4096) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(drxtune1b, DRX_TUNE1B_DATARATE110, LEN_DRX_TUNE1b);
		} else {
			// TODO proper error/warning handling
		}
	} else if (selectedMode->preambleLen != TX_PREAMBLE_LEN_64) {
		if (selectedMode->dataRate == TRX_RATE_850KBPS
				|| selectedMode->dataRate == TRX_RATE_6800KBPS) {
			writeBytes(drxtune1b, DRX_TUNE1B_DATARATE850, LEN_DRX_TUNE1b);
		} else {
			// TODO proper error/warning handling
		}
	} else {
		if (selectedMode->dataRate == TRX_RATE_6800KBPS) {
			writeBytes(drxtune1b, DRX_TUNE1B_DATARATE6800, LEN_DRX_TUNE1b);
		} else {
			// TODO proper error/warning handling
		}
	}
	// DRX_TUNE2
	if (selectedMode->pacSize == PAC_SIZE_8) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			writeBytes(drxtune2, DRX_TUNE2_TUNED_PAC8_RXPRF16, LEN_DRX_TUNE2);
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			writeBytes(drxtune2, DRX_TUNE2_TUNED_PAC8_RXPRF64, LEN_DRX_TUNE2);
		} else {
			// TODO proper error/warning handling
		}
	} else if (selectedMode->pacSize == PAC_SIZE_16) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			writeBytes(drxtune2, DRX_TUNE2_TUNED_PAC16_RXPRF16, LEN_DRX_TUNE2);
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			writeBytes(drxtune2, DRX_TUNE2_TUNED_PAC16_RXPRF64, LEN_DRX_TUNE2);
		} else {
			// TODO proper error/warning handling
		}
	} else if (selectedMode->pacSize == PAC_SIZE_32) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			writeBytes(drxtune2, DRX_TUNE2_TUNED_PAC32_RXPRF16, LEN_DRX_TUNE2);
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			writeBytes(drxtune2, DRX_TUNE2_TUNED_PAC32_RXPRF64, LEN_DRX_TUNE2);
		} else {
			// TODO proper error/warning handling
		}
	} else if (selectedMode->pacSize == PAC_SIZE_64) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			writeBytes(drxtune2, DRX_TUNE2_TUNED_PAC64_RXPRF16, LEN_DRX_TUNE2);
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			writeBytes(drxtune2, DRX_TUNE2_TUNED_PAC64_RXPRF64, LEN_DRX_TUNE2);
		} else {
			// TODO proper error/warning handling
		}
	} else {
		// TODO proper error/warning handling
	}
	// DRX_TUNE4H
	if (selectedMode->preambleLen == TX_PREAMBLE_LEN_64) {
		writeBytes(drxtune4H, DRX_TUNE4H_PREAMBLE_LENGTH_64, LEN_DRX_TUNE4H);
	} else {
		writeBytes(drxtune4H, DRX_TUNE4H_PREAMBLE_LENGTH_128, LEN_DRX_TUNE4H);
	}
	// RF_RXCTRLH
	if (selectedMode->channel != CHANNEL_4
			&& selectedMode->channel != CHANNEL_7) {
		writeBytes(rfrxctrlh, RF_RXCTRLH_TUNED_CHANNEL1_2_3_5, LEN_RF_RXCTRLH);
	} else {
		writeBytes(rfrxctrlh, RF_RXCTRLH_TUNED_CHANNEL4_7, LEN_RF_RXCTRLH);
	}
	// RX_TXCTRL
	if (selectedMode->channel == CHANNEL_1) {
		writeBytes(rftxctrl, RF_TXCTRL_TUNED_CHANNEL1, LEN_RF_TXCTRL);
	} else if (selectedMode->channel == CHANNEL_2) {
		writeBytes(rftxctrl, RF_TXCTRL_TUNED_CHANNEL2, LEN_RF_TXCTRL);
	} else if (selectedMode->channel == CHANNEL_3) {
		writeBytes(rftxctrl, RF_TXCTRL_TUNED_CHANNEL3, LEN_RF_TXCTRL);
	} else if (selectedMode->channel == CHANNEL_4) {
		writeBytes(rftxctrl, RF_TXCTRL_TUNED_CHANNEL4, LEN_RF_TXCTRL);
	} else if (selectedMode->channel == CHANNEL_5) {
		writeBytes(rftxctrl, RF_TXCTRL_TUNED_CHANNEL5, LEN_RF_TXCTRL);
	} else if (selectedMode->channel == CHANNEL_7) {
		writeBytes(rftxctrl, RF_TXCTRL_TUNED_CHANNEL7, LEN_RF_TXCTRL);
	} else {
		// TODO proper error/warning handling
	}
	// TC_PGDELAY
	if (selectedMode->channel == CHANNEL_1) {
		writeBytes(tcpgdelay, TC_PGDELAY_TUNED_CHANNEL1, LEN_TC_PGDELAY);
	} else if (selectedMode->channel == CHANNEL_2) {
		writeBytes(tcpgdelay, TC_PGDELAY_TUNED_CHANNEL2, LEN_TC_PGDELAY);
	} else if (selectedMode->channel == CHANNEL_3) {
		writeBytes(tcpgdelay, TC_PGDELAY_TUNED_CHANNEL3, LEN_TC_PGDELAY);
	} else if (selectedMode->channel == CHANNEL_4) {
		writeBytes(tcpgdelay, TC_PGDELAY_TUNED_CHANNEL4, LEN_TC_PGDELAY);
	} else if (selectedMode->channel == CHANNEL_5) {
		writeBytes(tcpgdelay, TC_PGDELAY_TUNED_CHANNEL5, LEN_TC_PGDELAY);
	} else if (selectedMode->channel == CHANNEL_7) {
		writeBytes(tcpgdelay, TC_PGDELAY_TUNED_CHANNEL7, LEN_TC_PGDELAY);
	} else {
		// TODO proper error/warning handling
	}
	// FS_PLLCFG and FS_PLLTUNE
	if (selectedMode->channel == CHANNEL_1) {
		writeBytes(fspllcfg, FS_PLLCFG_TUNED_CHANNEL1, LEN_FS_PLLCFG);
		writeBytes(fsplltune, FS_PLLTUNE_TUNED_CHANNEL1, LEN_FS_PLLTUNE);
	} else if (selectedMode->channel == CHANNEL_2
			|| selectedMode->channel == CHANNEL_4) {
		writeBytes(fspllcfg, FS_PLLCFG_TUNED_CHANNEL2_CHANNEL4, LEN_FS_PLLCFG);
		writeBytes(fsplltune, FS_PLLTUNE_TUNED_CHANNEL2_CHANNEL4, LEN_FS_PLLTUNE);
	} else if (selectedMode->channel == CHANNEL_3) {
		writeBytes(fspllcfg, FS_PLLCFG_TUNED_CHANNEL3, LEN_FS_PLLCFG);
		writeBytes(fsplltune, FS_PLLTUNE_TUNED_CHANNEL3, LEN_FS_PLLTUNE);
	} else if (selectedMode->channel == CHANNEL_5
			|| selectedMode->channel == CHANNEL_7) {
		writeBytes(fspllcfg, FS_PLLCFG_TUNED_CHANNEL5_CHANNEL7, LEN_FS_PLLCFG);
		writeBytes(fsplltune, FS_PLLTUNE_TUNED_CHANNEL5_CHANNEL7, LEN_FS_PLLTUNE);// A6 or BE ?
	} else {
		// TODO proper error/warning handling
	}
	// LDE_CFG1
	writeBytes(ldecfg1, LDE_CFG1_NTM_TUNED, LEN_LDE_CFG1);
	// LDE_CFG2
	if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
		writeBytes(ldecfg2, LDE_CFG2_TUNED_RXPRF16, LEN_LDE_CFG2);
	} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
		writeBytes(ldecfg2, LDE_CFG2_TUNED_RXPRF64, LEN_LDE_CFG2);
	} else {
		// TODO proper error/warning handling
	}
	// LDE_REPC
	if (selectedMode->preambleCode == PREAMBLE_CODE_16MHZ_1
			|| selectedMode->preambleCode == PREAMBLE_CODE_16MHZ_2) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE1_2 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE1_2, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_16MHZ_3
			|| selectedMode->preambleCode == PREAMBLE_CODE_16MHZ_8) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE3_8 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE3_8, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_16MHZ_4) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE4 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE4, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_16MHZ_5) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE5 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE5, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_16MHZ_6) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE6 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE6, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_16MHZ_7) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE7 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE7, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_64MHZ_9) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE9 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE9, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_64MHZ_10
			|| selectedMode->preambleCode == PREAMBLE_CODE_64MHZ_17) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE10_17 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE10_17, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_64MHZ_11) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE11 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE11, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_64MHZ_12) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE12 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE12, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_64MHZ_18
			|| selectedMode->preambleCode == PREAMBLE_CODE_64MHZ_19) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE18_19 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE18_19, LEN_LDE_REPC);
		}
	} else if (selectedMode->preambleCode == PREAMBLE_CODE_64MHZ_20) {
		if (selectedMode->dataRate == TRX_RATE_110KBPS) {
			writeBytes(lderepc, ((LDE_REPC_TUNED_RX_PCODE20 >> 3) & 0xFFFF), LEN_LDE_REPC);
		} else {
			writeBytes(lderepc, LDE_REPC_TUNED_RX_PCODE20, LEN_LDE_REPC);
		}
	} else {
		// TODO proper error/warning handling
	}
	// TX_POWER (enabled smart transmit power control)
	if (selectedMode->channel == CHANNEL_1
			|| selectedMode->channel == CHANNEL_2) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL1_CHANNEL2_PRF16_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL1_CHANNEL2_PRF16_MANUAL, LEN_TX_POWER);
			}
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL1_CHANNEL2_PRF64_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL1_CHANNEL2_PRF64_MANUAL, LEN_TX_POWER);
			}
		} else {
			// TODO proper error/warning handling
		}
	} else if (selectedMode->channel == CHANNEL_3) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL3_PRF16_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL3_PRF16_MANUAL, LEN_TX_POWER);
			}
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL3_PRF64_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL3_PRF64_MANUAL, LEN_TX_POWER);
			}
		} else {
			// TODO proper error/warning handling
		}
	} else if (selectedMode->channel == CHANNEL_4) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL4_PRF16_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL4_PRF16_MANUAL, LEN_TX_POWER);
			}
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL4_PRF64_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL4_PRF64_MANUAL, LEN_TX_POWER);
			}
		} else {
			// TODO proper error/warning handling
		}
	} else if (selectedMode->channel == CHANNEL_5) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL5_PRF16_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL5_PRF16_MANUAL, LEN_TX_POWER);
			}
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL5_PRF64_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL5_PRF64_MANUAL, LEN_TX_POWER);
			}
		} else {
			// TODO proper error/warning handling
		}
	} else if (selectedMode->channel == CHANNEL_7) {
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL7_PRF16_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL7_PRF16_MANUAL, LEN_TX_POWER);
			}
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			if (_smartPower) {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL7_PRF64_STXP, LEN_TX_POWER);
			} else {
				writeBytes(txpower, TX_POWER_TUNED_CHANNEL7_PRF64_MANUAL, LEN_TX_POWER);
			}
		} else {
			// TODO proper error/warning handling
		}
	} else {
		// TODO proper error/warning handling
	}
	// mid range XTAL trim (TODO here we assume no calibration data available in OTP)
	//memset(fsxtalt, 0x60, LEN_FS_XTALT);
	// write configuration back to chip
	SPI_writeToDevice(AGC_TUNE, AGC_TUNE1_SUB, LEN_AGC_TUNE1, agctune1);
	SPI_writeToDevice(AGC_TUNE, AGC_TUNE2_SUB, LEN_AGC_TUNE2, agctune2);
	SPI_writeToDevice(AGC_TUNE, AGC_TUNE3_SUB, LEN_AGC_TUNE3, agctune3);
	SPI_writeToDevice(DRX_TUNE, DRX_TUNE0b_SUB, LEN_DRX_TUNE0b, drxtune0b);
	SPI_writeToDevice(DRX_TUNE, DRX_TUNE1a_SUB, LEN_DRX_TUNE1a, drxtune1a);
	SPI_writeToDevice(DRX_TUNE, DRX_TUNE1b_SUB, LEN_DRX_TUNE1b, drxtune1b);
	SPI_writeToDevice(DRX_TUNE, DRX_TUNE2_SUB, LEN_DRX_TUNE2, drxtune2);
	SPI_writeToDevice(DRX_TUNE, DRX_TUNE4H_SUB, LEN_DRX_TUNE4H, drxtune4H);
	SPI_writeToDevice(LDE_IF, LDE_CFG1_SUB, LEN_LDE_CFG1, ldecfg1);
	SPI_writeToDevice(LDE_IF, LDE_CFG2_SUB, LEN_LDE_CFG2, ldecfg2);
	SPI_writeToDevice(LDE_IF, LDE_REPC_SUB, LEN_LDE_REPC, lderepc);
	SPI_writeToDevice(TX_POWER, NO_SUB, LEN_TX_POWER, txpower);
	SPI_writeToDevice(RF_CONF, RF_RXCTRLH_SUB, LEN_RF_RXCTRLH, rfrxctrlh);
	SPI_writeToDevice(RF_CONF, RF_TXCTRL_SUB, LEN_RF_TXCTRL, rftxctrl);
	SPI_writeToDevice(TX_CAL, TC_PGDELAY_SUB, LEN_TC_PGDELAY, tcpgdelay);
	SPI_writeToDevice(FS_CTRL, FS_PLLTUNE_SUB, LEN_FS_PLLTUNE, fsplltune);
	SPI_writeToDevice(FS_CTRL, FS_PLLCFG_SUB, LEN_FS_PLLCFG, fspllcfg);
	//SPI_writeToDevice(FS_CTRL, FS_XTALT_SUB, LEN_FS_XTALT, fsxtalt);
}
void UWBDW1000::setupDecaAddresses() {
	uint64_t nid = getSettingsDecaNID();

	//uint64_t nid = ::axiamote->controlTask->GetSettings()->decaNID;
	uint8_t *nidPt = (uint8_t*) &nid;
	_NID[0] = *nidPt++;
	_NID[1] = *nidPt++;
	_NID[2] = *nidPt++;
	_NID[3] = *nidPt++;
	_NID[4] = *nidPt++;
	_NID[5] = *nidPt++;

	setEUI(getSettingsDecaEUI());
	//setEUI((uint8_t*) &::axiamote->controlTask->GetSettings()->decaEUI);

	writeNetworkIdAndDeviceAddress();
}

void UWBDW1000::enableFrameFilter(bool isFFEN) {
	readSystemConfigurationRegister();
	setBit(_syscfg, LEN_SYS_CFG, FFEN_BIT, isFFEN);
	setBit(_syscfg, LEN_SYS_CFG, FFAD_BIT, isFFEN);
	setBit(_syscfg, LEN_SYS_CFG, FFAM_BIT, isFFEN);
	setBit(_syscfg, LEN_SYS_CFG, FFBC_BIT, isFFEN);
	writeSystemConfigurationRegister();
}

void UWBDW1000::setSystemEventMask() {
	uint32_t syseventmask = read32bitoffsetreg(SYS_MASK, 0);
	qDebug() << "sysmask before: " << syseventmask;
	syseventmask |= (1 << 7);
	syseventmask |= (1 << 14);
	write32bitoffsetreg(SYS_MASK, 0, syseventmask);
	qDebug() << "sysmask after: " << read32bitoffsetreg(SYS_MASK, 0);
}

void UWBDW1000::readSystemConfigurationRegister() {
	SPI_readFromDevice(SYS_CFG, NO_SUB, LEN_SYS_CFG, _syscfg);
}

void UWBDW1000::writeSystemConfigurationRegister() {
	SPI_writeToDevice(SYS_CFG, NO_SUB, LEN_SYS_CFG, _syscfg);
}

void UWBDW1000::readSystemEventStatusRegister() {
	SPI_readFromDevice(SYS_STATUS, NO_SUB, LEN_SYS_STATUS, _sysstatus);
}

void UWBDW1000::readNetworkIdAndDeviceAddress() {
	SPI_readFromDevice(PANADR, NO_SUB, LEN_PANADR, _NID);
}

void UWBDW1000::writeNetworkIdAndDeviceAddress() {
	SPI_writeToDevice(PANADR, NO_SUB, LEN_PANADR, _NID);
}
void UWBDW1000::readRFStatus() {
	SPI_readFromDevice(RF_CONF, RF_STATUS_SUB, LEN_RF_TXCTRL, _rfstatus);
}

void UWBDW1000::writeRFStatus() {
	SPI_writeToDevice(RF_CONF, RF_STATUS_SUB, LEN_RF_TXCTRL, _rfstatus);
}

void UWBDW1000::readSystemEventMaskRegister() {
	SPI_readFromDevice(SYS_MASK, NO_SUB, LEN_SYS_MASK, _sysmask);
}

void UWBDW1000::writeSystemEventMaskRegister() {
	SPI_writeToDevice(SYS_MASK, NO_SUB, LEN_SYS_MASK, _sysmask);
}

void UWBDW1000::readChannelControlRegister() {
	SPI_readFromDevice(CHAN_CTRL, NO_SUB, LEN_CHAN_CTRL, _chanctrl);
}

void UWBDW1000::writeChannelControlRegister() {
	SPI_writeToDevice(CHAN_CTRL, NO_SUB, LEN_CHAN_CTRL, _chanctrl);
}

void UWBDW1000::readTransmitFrameControlRegister() {
	SPI_readFromDevice(TX_FCTRL, NO_SUB, LEN_TX_FCTRL, _txfctrl);
}

void UWBDW1000::writeTransmitFrameControlRegister() {
	SPI_writeToDevice(TX_FCTRL, NO_SUB, LEN_TX_FCTRL, _txfctrl);
}

void UWBDW1000::readGPIOControlRegister() {
	SPI_readFromDevice(GPIO_MODE, NO_SUB, LEN_GPIO_MODE, _gpioctrl);
}

void UWBDW1000::writeGPIOControlRegister() {
	SPI_writeToDevice(GPIO_MODE, NO_SUB, LEN_GPIO_MODE, _gpioctrl);
}

void UWBDW1000::readPMSC0ControlRegister() {
	SPI_readFromDevice(PMSC, NO_SUB, LEN_PMSC_CTRL0, _pmsc0ctrl);
}

void UWBDW1000::readPMSC1ControlRegister() {
	SPI_readFromDevice(PMSC, PMSC_CTRL1_SUB, LEN_PMSC_CTRL1, _pmsc1ctrl);
}

void UWBDW1000::writePMSC0ControlRegister() {
	SPI_writeToDevice(PMSC, NO_SUB, LEN_PMSC_CTRL0, _pmsc0ctrl);
}

void UWBDW1000::readSystemControlRegister() {
	SPI_readFromDevice(SYS_CTRL, NO_SUB, LEN_SYS_CTRL, _sysctrl);
}
void UWBDW1000::writeSystemControlRegister() {
	SPI_writeToDevice(SYS_CTRL, NO_SUB, LEN_SYS_CTRL, _sysctrl);
}

void UWBDW1000::writeGPIOInterruptDeBounceEnableRegister() {
	SPI_writeToDevice(GPIO_MODE, GPIO_IDBE_SUB, LEN_GPIO_MODE, _dbenable);
}

void UWBDW1000::readGPIOInterruptDeBounceEnableRegister() {
	SPI_readFromDevice(GPIO_MODE, GPIO_IDBE_SUB, LEN_GPIO_MODE, _dbenable);
}

void UWBDW1000::writeLEDEnableRegister() {
	SPI_writeToDevice(PMSC_ID, PMSC_LEDC_OFFSET, LEN_PMSC_CTRL0, _ledenable);
}

void UWBDW1000::readLEDEnableRegister() {
	SPI_readFromDevice(PMSC_ID, PMSC_LEDC_OFFSET, LEN_PMSC_CTRL0, _ledenable);
}

void UWBDW1000::readDRXTune2Register() {
	SPI_readFromDevice(DRX_TUNE, DRX_TUNE2_SUB, LEN_DRX_TUNE2, _drxtune2);
}

void UWBDW1000::writeDRXTune2Register() {
	SPI_writeToDevice(DRX_TUNE, DRX_TUNE2_SUB, LEN_DRX_TUNE2, _drxtune2);
}

uint32_t UWBDW1000::read32bitoffsetreg(uint8_t regId, uint8_t regOffset) {
	uint32_t regval = ERROR;
	uint8_t buffer[4];

	uint8_t result = SPI_readFromDevice(regId, regOffset, 4, buffer); // read 4 bytes (32-bits) register into buffer

	if (result == SUCCESS) {
		for (int8_t i = 3; i >= 0; i--) {
			regval = (regval << 8) + buffer[i];        // sum
		}
	}
	return regval;
}

uint8_t UWBDW1000::write32bitoffsetreg(uint16_t regFileID, uint16_t regOffset,
		uint32_t regval) {
	uint8_t reg;
	uint8_t buffer[4];

	for (uint8_t j = 0; j < 4; j++) {
		buffer[j] = regval & 0xff;
		regval >>= 8;
	}

	reg = SPI_writeToDevice(regFileID, regOffset, 4, buffer);

	return reg;
}

uint16_t UWBDW1000::read16bitoffsetreg(uint16_t regFileID, uint16_t regOffset) {
	uint16_t regval = DWT_ERROR;
	uint8_t buffer[2];

	uint16_t result = SPI_readFromDevice(regFileID, regOffset, 2, buffer); // read 2 bytes (16-bits) register into buffer

	if (result == DWT_SUCCESS) {
		regval = (buffer[1] << 8) + buffer[0];        // sum
	}
	return regval;
}

uint8_t UWBDW1000::write16bitoffsetreg(uint16_t regFileID, uint16_t regOffset,
		uint16_t regval) {
	uint8_t reg;
	uint8_t buffer[2];

	buffer[0] = regval & 0xFF;
	buffer[1] = regval >> 8;

	reg = SPI_writeToDevice(regFileID, regOffset, 2, buffer);

	return reg;
}

uint8_t UWBDW1000::read8bitoffsetreg(uint16_t regFileID, uint16_t regOffset) {
	uint8_t regval = DWT_ERROR;
	SPI_readFromDevice(regFileID, regOffset, 1, &regval); // read 2 bytes (16-bits) register into buffer
	return regval;
}

uint8_t UWBDW1000::write8bitoffsetreg(uint16_t regFileID, uint16_t regOffset,
		uint8_t regval) {
	uint8_t reg;

	reg = SPI_writeToDevice(regFileID, regOffset, 1, &regval);

	return reg;
}
void UWBDW1000::setBit(uint8_t data[], unsigned int n, unsigned int bit,
		bool val) {
	unsigned int idx;
	int shift;

	idx = bit / 8;
	if (idx >= n) {
		return; // TODO proper error handling: out of bounds
	}
	uint8_t* targetByte = &data[idx];
	shift = bit % 8;
	if (val) {
		bitSet(*targetByte, shift);
	} else {
		bitClear(*targetByte, shift);
	}
}

void UWBDW1000::delayedTransmitter() {
	/*uint8_t data[12];
	 while (true) {
	 sysTimeStamp[0] = getSysTime();
	 buildAndSendMessage(MSG_TYPE_BLINK, true);

	 long long int delayedTX = 109803776 + getSysTime(); //17.1ms  vTaskDelay(1)
	 uint8 delayed_time[DX_TIME_LEN];
	 for (int n = 0; n < LEN_STAMP; n++) {
	 delayed_time[n] = ((delayedTX) >> 8 * n) & 0xff;
	 }
	 SPI_writeToDevice(DX_TIME_ID, NO_SUB, LEN_STAMP, delayed_time);
	 newTransmit();
	 readSystemEventStatusRegister();
	 _sysctrl[0] |= 0x06;
	 SPI_writeToDevice(SYS_CTRL, NO_SUB, LEN_SYS_CTRL, _sysctrl);

	 getTransmitTimestamp (newSentTime);
	 txTimestampFinal = newSentTime.getReceivedTimestamp();
	 SPI_readFromDevice(TX_BUFFER, NO_SUB, 12, data);
	 }*/
}

void UWBDW1000::newTransmit() {
	setIdleMode();
	memset(_sysctrl, 0, LEN_SYS_CTRL);
	clearTransmitStatus();
	readSystemEventStatusRegister();
	readRFStatus();
}

void UWBDW1000::startTransmit() {
	_sysctrl[0] |= 0x82;
	SPI_writeToDevice(SYS_CTRL, NO_SUB, LEN_SYS_CTRL, _sysctrl);
}

void UWBDW1000::clearTransmitStatus() {
// clear latched TX bits
	readSystemEventStatusRegister();
	setBit(_sysstatus, LEN_SYS_STATUS, TXFRB_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, TXPRS_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, TXPHS_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, TXFRS_BIT, true);
	SPI_writeToDevice(SYS_STATUS, NO_SUB, LEN_SYS_STATUS, _sysstatus);
}

void UWBDW1000::setData(uint8_t data[], unsigned int n) {
	if (_frameCheck) {
		n += 2; // two bytes CRC-16
	}
	if (n > LEN_EXT_UWB_FRAMES) {
		return; // TODO proper error handling: frame/buffer size
	}
	if (n > LEN_UWB_FRAMES && !selectedMode->extFrameLen) {
		return; // TODO proper error handling: frame/buffer size
	}
// transmit data and length
	SPI_writeToDevice(TX_BUFFER, NO_SUB, n, data);
	SPI_readFromDevice(TX_BUFFER, NO_SUB, n, data);

	_txfctrl[0] = (uint8_t)(n & 0xFF); // 1 byte (regular length + 1 bit)
	_txfctrl[1] &= 0xE0;
	_txfctrl[1] |= (uint8_t)((n >> 8) & 0x03); // 2 added bits if extended length
}

void UWBDW1000::buildBlinkMessage(event_data_t *newMessage) {
	newMessage->messageUnion.rxblinkmsg.frameCtrl = MSG_TYPE_BLINK; //the first Octet(byte) of blink frame is FrameControl(FC), 0xC5. This value is defined by decawave.
	qDebug() << "FC: " << newMessage->messageUnion.rxblinkmsg.frameCtrl;
	newMessage->messageUnion.rxblinkmsg.seqNum = frameSequenceNumber++;
	memcpy(newMessage->messageUnion.rxblinkmsg.tagID, _EUI, ADDR_BYTE_SIZE_L); //64-bit tagID.
	SPI_writeToDevice(TX_BUFFER, NO_SUB, FLENGTH_MSG_BLINK,
			(uint8_t *) (newMessage->messageUnion.frame));

	_txfctrl[0] = (uint8_t)(FLENGTH_MSG_BLINK);
//the length of blink message is 12 Octet(byte), the last two Octet(byte) are FCS(a CRC frame check sequence following the IEEE standard).
	writeTransmitFrameControlRegister();
}

void UWBDW1000::buildPollMessage(event_data_t *newMessage) {
	newMessage->messageUnion.rxmsg_ss.frameCtrl[0] = NONE_BLINK_FRAME_CTRL;
	newMessage->messageUnion.rxmsg_ss.frameCtrl[1] = LENGTH_DEST_ADDR_SHORT
			| LENGTH_SOUR_ADDR_SHORT /*src short address (16bits)*/;
	newMessage->messageUnion.rxmsg_ss.seqNum = frameSequenceNumber++;
	newMessage->messageUnion.rxmsg_ss.sourceAddr[0] = _NID[0];
	newMessage->messageUnion.rxmsg_ss.sourceAddr[1] = _NID[1];
	newMessage->messageUnion.rxmsg_ss.destAddr[0] = _NID[4];
	newMessage->messageUnion.rxmsg_ss.destAddr[1] = _NID[5];
	newMessage->messageUnion.rxmsg_ss.panID[0] = _NID[2];
	newMessage->messageUnion.rxmsg_ss.panID[1] = _NID[3];
	newMessage->messageUnion.rxmsg_ss.messageData[0] = MSG_TYPE_POLL;
	SPI_writeToDevice(TX_BUFFER, NO_SUB, FLENGTH_MSG_POLL,
			(uint8_t *) (newMessage->messageUnion.frame));
	_txfctrl[0] = (uint8_t)(FLENGTH_MSG_POLL); //the length of poll message is 24 Octet(byte).
	writeTransmitFrameControlRegister();
}

void UWBDW1000::buildFinalMessage(event_data_t *newMessage) {
	newMessage->messageUnion.rxmsg_ss.frameCtrl[0] = NONE_BLINK_FRAME_CTRL;
	newMessage->messageUnion.rxmsg_ss.frameCtrl[1] = LENGTH_DEST_ADDR_SHORT
			| LENGTH_SOUR_ADDR_SHORT;
	newMessage->messageUnion.rxmsg_ss.sourceAddr[0] = _NID[0];
	newMessage->messageUnion.rxmsg_ss.sourceAddr[1] = _NID[1];
	newMessage->messageUnion.rxmsg_ss.destAddr[0] =
			decaMessage.messageUnion.rxmsg_ss.sourceAddr[0];
	newMessage->messageUnion.rxmsg_ss.destAddr[1] =
			decaMessage.messageUnion.rxmsg_ss.sourceAddr[1];
	newMessage->messageUnion.rxmsg_ss.panID[0] = _NID[2];
	newMessage->messageUnion.rxmsg_ss.panID[1] = _NID[3];

	memcpy(&newMessage->messageUnion.rxmsg_ss.messageData[1], txTimestampPoll,
			LEN_STAMP);
	memcpy(&newMessage->messageUnion.rxmsg_ss.messageData[6],
			rxTimestampResponse, LEN_STAMP);

	uint8_t rxTimestampResponseDelayed[LEN_STAMP];
	memcpy(rxTimestampResponseDelayed, rxTimestampResponse, LEN_STAMP);
	addDelayedTime(rxTimestampResponseDelayed);

	SPI_writeToDevice(DX_TIME_ID, NO_SUB, LEN_STAMP,
			rxTimestampResponseDelayed);
	memcpy(&newMessage->messageUnion.rxmsg_ss.messageData[11],
			rxTimestampResponseDelayed, LEN_STAMP);

	newMessage->messageUnion.rxmsg_ss.messageData[0] = MSG_TYPE_FINAL;
	SPI_writeToDevice(TX_BUFFER, NO_SUB, FLENGTH_MSG_FINAL,
			(uint8 *) (newMessage->messageUnion.frame));
	_txfctrl[0] = (uint8) (FLENGTH_MSG_FINAL); //the length of final message is 39 Octet(byte).
	SPI_writeToDevice(TX_FCTRL, NO_SUB, LEN_TX_FCTRL, _txfctrl);
}

void UWBDW1000::buildRangingInitMessage(event_data_t *newMessage) {
	newMessage->messageUnion.rxmsg_ls.frameCtrl[0] = NONE_BLINK_FRAME_CTRL;
	newMessage->messageUnion.rxmsg_ls.frameCtrl[1] = LENGTH_DEST_ADDR_LONG
			| LENGTH_SOUR_ADDR_SHORT;
	newMessage->messageUnion.rxmsg_ls.seqNum = frameSequenceNumber++;
	newMessage->messageUnion.rxmsg_ls.sourceAddr[0] = _NID[0];
	newMessage->messageUnion.rxmsg_ls.sourceAddr[1] = _NID[1];
	memcpy(newMessage->messageUnion.rxmsg_ls.destAddr,
			decaMessage.messageUnion.rxblinkmsg.tagID, LEN_EUI);
	newMessage->messageUnion.rxmsg_ls.panID[0] = _NID[2];
	newMessage->messageUnion.rxmsg_ls.panID[1] = _NID[3];
	newMessage->messageUnion.rxmsg_ls.messageData[0] = MSG_TYPE_RANGING_INIT;
	SPI_writeToDevice(TX_BUFFER, NO_SUB, FLENGTH_MSG_RANGINGINIT,
			(uint8_t *) (&newMessage->messageUnion.frame));
	_txfctrl[0] = (uint8_t)(FLENGTH_MSG_RANGINGINIT);
	writeTransmitFrameControlRegister();
}

void UWBDW1000::buildResponseMessage(event_data_t *newMessage) {
	newMessage->messageUnion.rxmsg_ss.frameCtrl[0] = NONE_BLINK_FRAME_CTRL;
	newMessage->messageUnion.rxmsg_ss.frameCtrl[1] = LENGTH_DEST_ADDR_SHORT
			| LENGTH_SOUR_ADDR_SHORT /*src short address (16bits)*/;
	newMessage->messageUnion.rxmsg_ss.sourceAddr[0] = _NID[0];
	newMessage->messageUnion.rxmsg_ss.sourceAddr[1] = _NID[1];
	newMessage->messageUnion.rxmsg_ss.destAddr[0] =
			decaMessage.messageUnion.rxmsg_ss.sourceAddr[0];
	newMessage->messageUnion.rxmsg_ss.destAddr[1] =
			decaMessage.messageUnion.rxmsg_ss.sourceAddr[1];
	newMessage->messageUnion.rxmsg_ss.panID[0] = _NID[2];
	newMessage->messageUnion.rxmsg_ss.panID[1] = _NID[3];
	uint8_t rxTimestampPollDelayed[LEN_STAMP];
	memcpy(rxTimestampPollDelayed, rxTimestampPoll, LEN_STAMP);
	addDelayedTime(rxTimestampPollDelayed);
	SPI_writeToDevice(DX_TIME_ID, NO_SUB, LEN_STAMP, rxTimestampPollDelayed);
	//qDebug() << "set dx_time: " << rxTimestampPollDelayed << ", " << SPI_writeToDevice(DX_TIME_ID, NO_SUB, LEN_STAMP, rxTimestampPollDelayed);
	newMessage->messageUnion.rxmsg_ss.messageData[0] = MSG_TYPE_RESPONSE;
	newMessage->messageUnion.rxmsg_ss.messageData[1] = 0x02;
	newMessage->messageUnion.rxmsg_ss.messageData[2] = 0x00;
	newMessage->messageUnion.rxmsg_ss.messageData[3] = 0x00;
	SPI_writeToDevice(TX_BUFFER, NO_SUB, FLENGTH_MSG_RESPONSE,
			(uint8_t *) (newMessage->messageUnion.frame));
	_txfctrl[0] = (uint8_t)(FLENGTH_MSG_RESPONSE); //the length of response message is 32 Octet(byte).
	writeTransmitFrameControlRegister();
	qDebug() << "build response end";
}

void UWBDW1000::addDelayedTime(uint8_t *timestamp) {
	uint64_t time = 0;
	memcpy(&time, timestamp, LEN_STAMP);
	time &= 0xFFFFFFFFFF;
	time += delayedSendValue;
	memcpy(timestamp, &time, LEN_STAMP);
}

void UWBDW1000::buildAndSendMessage(MsgType msgType, SendType type) {
	event_data_t newMessage;

	switch (msgType) {
	case MSG_TYPE_BLINK:
		buildBlinkMessage(&newMessage);
		break;
	case MSG_TYPE_POLL:
		buildPollMessage(&newMessage);
		break;
	case MSG_TYPE_RANGING_INIT:
		buildRangingInitMessage(&newMessage);
		break;
	case MSG_TYPE_FINAL:
		buildFinalMessage(&newMessage);
		break;
	case MSG_TYPE_RESPONSE:
		buildResponseMessage(&newMessage);
		break;
	case MSG_TYPE_NONE:
		break;
	default:
		// should never happen
		break;

	}
	initiateTransmitting(msgType, type);
}

void UWBDW1000::initiateTransmitting(MsgType msgType, SendType type) {
	uint8_t res;
	newTransmit();
	if (msgType != MSG_TYPE_FINAL) {
		switch (type) {
		case SEND_DELAYED:
			readSystemEventStatusRegister();
			_sysctrl[0] |= 0x86;
			res = SPI_writeToDevice(SYS_CTRL, NO_SUB, LEN_SYS_CTRL, _sysctrl);
			qDebug() << "Send delayed: " << res;
			break;
		case SEND_IMMEDIATELY:
			startTransmit();
			break;
		}
	} else {
		readSystemEventStatusRegister();
		_sysctrl[0] |= 0x06;
		SPI_writeToDevice(SYS_CTRL, NO_SUB, LEN_SYS_CTRL, _sysctrl);
	}
}

long long int UWBDW1000::getSysTime() {
	uint8_t systime[5];
	long long int sys_time = 0;
	SPI_readFromDevice(0x06, NO_SUB, 5, systime);
	for (int i = 4; i >= 0; i--) {
		sys_time = sys_time << 8;
		sys_time |= systime[i];
	}
	return sys_time;
}

void UWBDW1000::rxEnable() {
	newReceive();
	startReceive();
}

/** check message length of received frame */
int UWBDW1000::getMessageLength() {
	return read16bitoffsetreg(RX_FINFO, 0) & 0x3FF;
}

void UWBDW1000::uint8ToLong(uint8_t *time, long long int *timestamp) {
	*timestamp = 0;
	for (int i = 0; i < LEN_STAMP; i++) {
		*timestamp |= ((long long int) time[i] << (i * 8));
	}
}

void UWBDW1000::getTransmitTimestamp(uint8_t *timestamp) {
	SPI_readFromDevice(TX_TIME, TX_STAMP_SUB, LEN_TX_STAMP, timestamp);
}

void UWBDW1000::getReceivedTimestamp(uint8_t *timestamp) {
	SPI_readFromDevice(RX_TIME, RX_STAMP_SUB, LEN_RX_STAMP, timestamp);
	correctTimestamp(timestamp);
}

void UWBDW1000::correctTimestamp(uint8_t *timestamp) {
// base line dBm, which is -61, 2 dBm steps, total 18 data points (down to -95 dBm)
	float rxPowerBase = -(getReceivePower() + 61.0f) * 0.5f;
	int rxPowerBaseLow = (int) rxPowerBase;
	int rxPowerBaseHigh = rxPowerBaseLow + 1;
	if (rxPowerBaseLow < 0) {
		rxPowerBaseLow = 0;
		rxPowerBaseHigh = 0;
	} else if (rxPowerBaseHigh > 17) {
		rxPowerBaseLow = 17;
		rxPowerBaseHigh = 17;
	}
// select range low/high values from corresponding table
	int rangeBiasHigh = 0;
	int rangeBiasLow = 0;
	if (selectedMode->channel == CHANNEL_4 || selectedMode->channel == CHANNEL_7) {
		// 900 MHz receiver bandwidth
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			rangeBiasHigh = (
					rxPowerBaseHigh < BIAS_900_16_ZERO ?
							-BIAS_900_16[rxPowerBaseHigh] :
							BIAS_900_16[rxPowerBaseHigh]);
			rangeBiasHigh <<= 1;
			rangeBiasLow = (
					rxPowerBaseLow < BIAS_900_16_ZERO ?
							-BIAS_900_16[rxPowerBaseLow] :
							BIAS_900_16[rxPowerBaseLow]);
			rangeBiasLow <<= 1;
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			rangeBiasHigh = (
					rxPowerBaseHigh < BIAS_900_64_ZERO ?
							-BIAS_900_64[rxPowerBaseHigh] :
							BIAS_900_64[rxPowerBaseHigh]);
			rangeBiasHigh <<= 1;
			rangeBiasLow = (
					rxPowerBaseLow < BIAS_900_64_ZERO ?
							-BIAS_900_64[rxPowerBaseLow] :
							BIAS_900_64[rxPowerBaseLow]);
			rangeBiasLow <<= 1;
		} else {
			// TODO proper error handling
		}
	} else {
		// 500 MHz receiver bandwidth
		if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
			rangeBiasHigh = (
					rxPowerBaseHigh < BIAS_500_16_ZERO ?
							-BIAS_500_16[rxPowerBaseHigh] :
							BIAS_500_16[rxPowerBaseHigh]);
			rangeBiasLow = (
					rxPowerBaseLow < BIAS_500_16_ZERO ?
							-BIAS_500_16[rxPowerBaseLow] :
							BIAS_500_16[rxPowerBaseLow]);
		} else if (selectedMode->pulseFreq == TX_PULSE_FREQ_64MHZ) {
			rangeBiasHigh = (
					rxPowerBaseHigh < BIAS_500_64_ZERO ?
							-BIAS_500_64[rxPowerBaseHigh] :
							BIAS_500_64[rxPowerBaseHigh]);
			rangeBiasLow = (
					rxPowerBaseLow < BIAS_500_64_ZERO ?
							-BIAS_500_64[rxPowerBaseLow] :
							BIAS_500_64[rxPowerBaseLow]);
		} else {
			// TODO proper error handling
		}
	}
// linear interpolation of bias values
	float rangeBias = rangeBiasLow
			+ (rxPowerBase - rxPowerBaseLow) * (rangeBiasHigh - rangeBiasLow);
// range bias [mm] to timestamp modification value conversion
	uint64_t adjustmentTime = (rangeBias * DISTANCE_OF_RADIO_INV * 0.001f);
	uint64_t thisTimestamp = 0;
	memcpy(&thisTimestamp, timestamp, LEN_STAMP);
	thisTimestamp += adjustmentTime;
	memcpy(timestamp, &thisTimestamp, LEN_STAMP);
}

void UWBDW1000::newReceive() {
	setIdleMode();
	memset(_sysctrl, 0, LEN_SYS_CTRL);
	clearReceiveStatus();
	readSystemEventStatusRegister();
}

void UWBDW1000::startReceive() {
	readSystemEventStatusRegister();
	setBit(_sysctrl, LEN_SYS_CTRL, SFCST_BIT, !_frameCheck);
	setBit(_sysctrl, LEN_SYS_CTRL, RXENAB_BIT, true);
	SPI_writeToDevice(SYS_CTRL, NO_SUB, LEN_SYS_CTRL, _sysctrl);
}

void UWBDW1000::clearReceiveStatus() {
// clear latched RX bits (i.e. write 1 to clear)
	readSystemEventStatusRegister();
	setBit(_sysstatus, LEN_SYS_STATUS, RXDFR_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, LDEDONE_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, LDEERR_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, RXPHE_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, RXFCE_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, RXFCG_BIT, true);
	setBit(_sysstatus, LEN_SYS_STATUS, RXRFSL_BIT, true);
	SPI_writeToDevice(SYS_STATUS, NO_SUB, LEN_SYS_STATUS, _sysstatus);
}

float UWBDW1000::getReceivePower() {
	uint8_t cirPwrBytes[LEN_CIR_PWR];
	uint8_t rxFrameInfo[LEN_RX_FINFO];
	unsigned long twoPower17 = 131072;
	unsigned int C, N;
	float A, corrFac;
	SPI_readFromDevice(RX_FQUAL, CIR_PWR_SUB, LEN_CIR_PWR, cirPwrBytes);
	SPI_readFromDevice(RX_FINFO, NO_SUB, LEN_RX_FINFO, rxFrameInfo);
	C = (unsigned int) cirPwrBytes[0] | ((unsigned int) cirPwrBytes[1] << 8);
	N = (((unsigned int) rxFrameInfo[2] >> 4) & 0xFF)
			| ((unsigned int) rxFrameInfo[3] << 4);
	if (selectedMode->pulseFreq == TX_PULSE_FREQ_16MHZ) {
		A = 115.72;
		corrFac = 2.3334;
	} else {
		A = 121.74;
		corrFac = 1.1667;
	}
	float estRxPwr = 10.0
			* log10(((float) C * (float) twoPower17) / ((float) N * (float) N))
			- A;
	if (estRxPwr <= -88) {
		return estRxPwr;
	} else {
		// approximation of Fig. 22 in user manual for dbm correction
		estRxPwr += (estRxPwr + 88) * corrFac;
	}
	return estRxPwr;
}

void UWBDW1000::setEUI(uint8_t eui[]) {
	SPI_writeToDevice(EUI_REG, NO_SUB, LEN_EUI, eui);
	memcpy(_EUI, eui, LEN_EUI);
}

uint8_t UWBDW1000::SPI_readFromDevice(uint16_t recordNumber, uint16_t index,
		uint32_t length, uint8_t *buffer) {
	uint8_t header[3] = { 0 };                    // buffer to compose header in
	uint8_t cnt = 0;                             // counter for length of header
	if (recordNumber > 0x3F)
		return ERROR;                     // record number is limited to 6-bits.

// Write message header selecting READ operation and addresses as appropriate (this is one to three bytes long)

	if (index == 0) {                // for index of 0, no sub-index is required
		header[cnt++] = (uint8_t) recordNumber; // bit-7 zero is READ operation, bit-6 zero=NO sub-addressing, bits 5-0 is reg file id
	} else {
		if (index > 0x7FFF)
			return ERROR;                      // index is limited to 15-bits.
		if ((index + length) > 0x7FFF)
			return ERROR;         // sub-addressible area is limited to 15-bits.

		header[cnt++] = (uint8_t)(0x40 | recordNumber); // bit-7 zero is READ operation, bit-6 one=sub-address follows, bits 5-0 is reg file id

		if (index <= 127) { // for non-zero index < 127, just a single sub-index byte is required
			header[cnt++] = (uint8_t) index; // bit-7 zero means no extension, bits 6-0 is index.
		} else {
			header[cnt++] = 0x80 | (uint8_t)(index); // bit-7 one means extended index, bits 6-0 is low seven bits of index.
			header[cnt++] = (uint8_t)(index >> 7); // 8-bit value = high eight bits of index.
		}
	}

// do the read from the SPI
	uint8_t ret = spiMaster_->transfer(header, cnt, buffer, length);
	return ret;

}

uint8_t UWBDW1000::SPI_writeToDevice(uint16_t recordNumber, uint16_t index,
		uint32_t length, uint8_t *buffer) {
	uint8_t header[3] = { 0 };                    // buffer to compose header in
	uint8_t cnt = 0;                             // counter for length of header
	if (recordNumber > 0x3F)
		return ERROR;                     // record number is limited to 6-bits.

// Write message header selecting WRITE operation and addresses as appropriate (this is one to three bytes long)
	if (index == 0) {                // for index of 0, no sub-index is required
		header[cnt++] = 0x80 | recordNumber; // bit-7 is WRITE operation, bit-6 zero=NO sub-addressing, bits 5-0 is reg file id
	} else {

		if (index > 0x7FFF)
			return ERROR;                      // index is limited to 15-bits.
		if ((index + length) > 0x7FFF)
			return ERROR;         // sub-addressable area is limited to 15-bits.

		header[cnt++] = 0xC0 | recordNumber; // bit-7 is WRITE operation, bit-6 one=sub-address follows, bits 5-0 is reg file id

		if (index <= 127) // for non-zero index < 127, just a single sub-index byte is required
				{
			header[cnt++] = (uint8_t) index; // bit-7 zero means no extension, bits 6-0 is index.
		} else {
			header[cnt++] = 0x80 | (uint8_t) (index); // bit-7 one means extended index, bits 6-0 is low seven bits of index.
			header[cnt++] = (uint8_t) (index >> 7); // 8-bit value = high eight bits of index.
		}
	}

	uint8_t ret = prependHeaderSend(header, cnt, buffer, length);
	//qDebug() << "prependHeaderSend: spiTransfer end";
	return ret;
}

uint8_t UWBDW1000::prependHeaderSend(uint8_t *headerBuffer, int headerLength,
		uint8_t *bodyBuffer, int bodyLength) {
	unsigned char sendBuf[headerLength + bodyLength];
	for (int i = 0; i < headerLength; i++) {
		sendBuf[i] = headerBuffer[i];
	}
	for (int i = 0; i < bodyLength; i++) {
		sendBuf[i + headerLength] = bodyBuffer[i];
	}
	//qDebug() << "prependHeaderSend: spiTransfer " << (bodyLength + headerLength);
	return spiMaster_->transfer(sendBuf, (bodyLength + headerLength), nullptr, 0);
	//return 0;
}
