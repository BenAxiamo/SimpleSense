/*
 * Copyright (c) 2015 by Thomas Trojer <thomas@trojer.net>
 * Decawave DW1000 library for arduino.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @file DW1000Time.h
 * Arduino driver library timestamp wrapper (header file) for the Decawave
 * DW1000 UWB transceiver IC.
 */

#ifndef _UWBDW1000Time_H_INCLUDED_
#define _UWBDW1000Time_H_INCLUDED_

// Time resolution in micro-seconds of time based registers/values.
// Each bit in a timestamp counts for a period of approx. 15.65ps
#define TIME_RES 0.000015650040064103f
#define TIME_RES_INV 63897.6f

// Speed of radio waves [m/s] * timestamp resolution [~15.65ps] of DW1000
#define DISTANCE_OF_RADIO 0.0046917639786159f
#define DISTANCE_OF_RADIO_INV 213.139451293f

// time stamp byte length
#define LEN_STAMP 5

// timer/counter overflow (40 bits)
#define TIME_OVERFLOW 1099511627776

// time factors (relative to [us]) for setting delayed transceive
#define DW_SECONDS 1e6
#define DW_MILLISECONDS 1e3
#define DW_MICROSECONDS 1
#define DW_NANOSECONDS 1e-3
#ifndef uint8
#ifndef _DECA_UINT8_
#define _DECA_UINT8_
typedef unsigned char uint8;
#endif
#endif

class UWBDW1000Time {
public:
	UWBDW1000Time();
	UWBDW1000Time(long long int time);
	UWBDW1000Time(float timeUs);
	UWBDW1000Time(uint8 data[]);
	UWBDW1000Time(long value, float factorUs);
	UWBDW1000Time(const UWBDW1000Time& copy);
	~UWBDW1000Time();

	void setTime(float timeUs);
	void setTime(long value, float factorUs);

	float getAsFloat() const;
	void getAsBytes(uint8 data[]) const;
	float getAsMeters() const;

	void getTimestamp(uint8 data[]) const;
	long long int getTimestamp() const;
	void setTimestamp(uint8 data[]);
	void setTimestamp(const UWBDW1000Time& copy);
	void setTimestamp(int value);

	UWBDW1000Time& wrap();

	UWBDW1000Time& operator=(const UWBDW1000Time &assign);
	UWBDW1000Time& operator+=(const UWBDW1000Time &add);
	UWBDW1000Time operator+(const UWBDW1000Time &add) const;
	UWBDW1000Time& operator-=(const UWBDW1000Time &sub);
	UWBDW1000Time operator-(const UWBDW1000Time &sub) const;
	UWBDW1000Time& operator*=(float factor);
	UWBDW1000Time operator*(const UWBDW1000Time &factor) const;
	UWBDW1000Time& operator*=(const UWBDW1000Time &factor);
	UWBDW1000Time operator*(float factor) const;
	UWBDW1000Time& operator/=(float factor);
	UWBDW1000Time operator/(float factor) const;
	UWBDW1000Time& operator/=(const UWBDW1000Time &factor);
	UWBDW1000Time operator/(const UWBDW1000Time &factor) const;
	bool operator==(const UWBDW1000Time &cmp) const;
	bool operator!=(const UWBDW1000Time &cmp) const;

	void print();

private:
	long long int _timestamp;
};

#endif
