/* this library provides functions to control the "parent device" of the DW1000
 * (either Axiamote or EdisonDecaAnchor for the moment)
 */

#include "device_access.h"
#include "edisondecaanchor.h"
#include "UWBDW1000.h"
#include "customincrementtimer.h"

void calculatedDistance(float distance)
{
	if (distance > 0) {
		anchor_->calculatedDistance(distance);
	}
}

uint8_t setNextTimerTime(uint16_t time)
{
	int msec = ERROR_INCREMENT;
	if (time == TIMER_DECA_FAST_INCREMENT) {
		msec = FAST_INCREMENT;
	} else if (time == TIMER_DECA_TIMEOUT_INCREMENT) {
		msec = TIMEOUT_INCREMENT;
	}
	return anchor_->setNextTimerTime(msec);
}


uint8_t RGBColorSet(uint8_t color)
{
	return anchor_->RGBColorSet(color);
}


uint8_t vTaskDelay (uint8_t time)
{
	//TODO validate

	usleep(time*50);

	return 0;
}


uint8_t*  getSettingsDecaEUI()
{
	//TODO read from settings
	
	return anchor_->getSettingsDecaEUI();
}


uint64_t getSettingsDecaNID()
{
	//TODO read from settings
	
	return anchor_->getSettingsDecaNID();
}
