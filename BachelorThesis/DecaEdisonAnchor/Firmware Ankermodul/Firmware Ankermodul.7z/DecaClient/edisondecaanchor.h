#ifndef EDISONDECAANCHOR_H
#define EDISONDECAANCHOR_H

#include <QDebug>
#include <QtGlobal>
#include <QTimer>

#include "customincrementtimer.h"
#include "client.h"
#include "lib/BoardSupportLibrary/decaanchorbsl.h"
#include "lib/BoardSupportLibrary/SPI_Master.h"
#include "lib/DecaLibrary/UWBDW1000.h"

class EdisonDecaAnchor : public QObject
{
	Q_OBJECT

public:
	EdisonDecaAnchor();
	~EdisonDecaAnchor();

	void calculatedDistance(float distance);
	uint8_t setNextTimerTime(uint16_t msec);
	uint8_t RGBColorSet(uint8_t color);
	uint8_t vTaskDelay (uint8_t time);
	uint64_t getSettingsDecaNID();
	uint8_t*  getSettingsDecaEUI();

	UWBDW1000 *uwb_;

private slots:
	void decaTimer();
	void initEdisonDecaAnchor();

private:

	static void decaInterrupt(void *args);

	Client *client_;
	DecaAnchorBSL *bsl_;
	SPI_Master *spiMaster_;
	QTimer *timer_;
	CustomIncrementTimer *thrTimer;

	QString anchorName;
	uint64_t decaEUI;
	uint64_t decaNID;

	uint64_t timerCount;

};

extern EdisonDecaAnchor* anchor_;

#endif // EDISONDECAANCHOR_H
