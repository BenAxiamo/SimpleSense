/****************************************************************************
*  Header     : Server                  Version 1.0   *
*****************************************************************************
*                                                                           *
*  Function   :                  *
*                                                                           *
*                                                                           *
*  Methodes   :                            *
*                                                                           *
*  Author     : bunto1                                                      *
*                                                                           *
*  History    : 26.05.2016  bo Created                                      *
*                                                                           *
*  File       : server.cpp                                                  *
*                                                                           *
*****************************************************************************
* BFH TI Biel / Axiamo                                                      *
****************************************************************************/

/* imports */
#include <QtWidgets>
#include <QtNetwork>
#include <QTextStream>

#include <stdlib.h>

#include "server.h"

/* Class constant declaration  */
#define serverName              "Axiamo Positioning Network Server"
#define serverMsg               "Axiamo rules!"

/* Class Type declaration      */

/* Class data declaration      */

/* Class definition            */

/****************************************************************************
* Constructor:  Server                                                      *
****************************************************************************/
Server::Server(QWidget *parent)
    : QDialog(parent)
    , statusLabel(new QLabel)
    , blockSize(0)
    , tcpServer(Q_NULLPTR)
    , networkSession(0)
    , clientConnection(Q_NULLPTR)
    , tcpInMsgCount(0)
    , tcpOutMsgCount(0)
    , firstMessageTime(-1)
    , lastMessageTime(-1)
    , tcpBytes(0)
	, distCnt(0)
{
    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
    statusLabel->setTextInteractionFlags(Qt::TextBrowserInteraction);

    QNetworkConfigurationManager manager;
    if (manager.capabilities() & QNetworkConfigurationManager::NetworkSessionRequired) {
        // Get saved network configuration
        QSettings settings(QSettings::UserScope, QLatin1String("Axiamo"));
        settings.beginGroup(QLatin1String("QtNetwork"));
        const QString id = settings.value(QLatin1String("DefaultNetworkConfiguration")).toString();
        settings.endGroup();

        // If the saved network configuration is not currently discovered use the system default
        QNetworkConfiguration config = manager.configurationFromIdentifier(id);
        if ((config.state() & QNetworkConfiguration::Discovered) !=
            QNetworkConfiguration::Discovered) {
            config = manager.defaultConfiguration();
        }

        networkSession = new QNetworkSession(config, this);
        connect(networkSession, &QNetworkSession::opened, this, &Server::networkSessionOpened);

        statusLabel->setText(tr("Opening network session."));
        networkSession->open();
    } else {
        networkSessionOpened();
	}

	parser = new TcpIpFunctions(this);
	connect(parser, &TcpIpFunctions::tcpKeepalive, this, &Server::handleKeepalive);
	connect(parser, SIGNAL(tcpDistanceValue(QString,QString,double,QString)), this, SLOT(displayDistance(QString,QString,double,QString)));

	connect(tcpServer, &QTcpServer::newConnection, this, &Server::sendFortune);

	initGUI();
}

/****************************************************************************
* Destructor:  ~Server                                                      *
****************************************************************************/
Server::~Server()
{

}

void Server::initGUI()
{
	QPushButton *quitButton = new QPushButton(tr("Quit"));
	quitButton->setAutoDefault(false);
	connect(quitButton, &QAbstractButton::clicked, this, &QWidget::close);

	QLabel *lblAxiamo = new QLabel;
	QPixmap imgAxiamo("axiamo.png");
	lblAxiamo->setScaledContents(true);
	lblAxiamo->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
	lblAxiamo->setPixmap(imgAxiamo);

	QPixmap imgAxiamote("axiamote_.png");
	imgAxiamoteLabel = new QLabel(this);
	imgAxiamoteLabel->setScaledContents(true);
	imgAxiamoteLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
	imgAxiamoteLabel->setPixmap(imgAxiamote);

	distanceLabel = new QLabel("- 0.01 m");
	QFont f = distanceLabel->font();
	f.setPointSize(40);
	f.setBold(true);
	f.setItalic(true);
	distanceLabel->setFont(f);

	logField = new QPlainTextEdit();
	logField->setReadOnly(true);
	logField->setPlainText(tr("Message Log:\n"));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch(1);
	buttonLayout->addWidget(quitButton);
	buttonLayout->addStretch(1);

	QHBoxLayout *distanceLayout = new QHBoxLayout;
	distanceLayout->addWidget(imgAxiamoteLabel);
	distanceLayout->addWidget(distanceLabel);

	QVBoxLayout *menuLayout = new QVBoxLayout;
	menuLayout->addWidget(statusLabel);
	menuLayout->addLayout(buttonLayout);

	QVBoxLayout *contentLayout = new QVBoxLayout;
	contentLayout->addWidget(lblAxiamo);
	contentLayout->addLayout(distanceLayout);
	contentLayout->addWidget(logField);

	QHBoxLayout *mainLayout = new QHBoxLayout(this);

	mainLayout->addLayout(menuLayout);
	mainLayout->addLayout(contentLayout);

	setWindowTitle(QGuiApplication::applicationDisplayName());
}

/****************************************************************************
* SLOT:     networkSessionOpened                                            *
****************************************************************************/
void Server::networkSessionOpened()
{
    // Save the used configuration
    if (networkSession) {
        QNetworkConfiguration config = networkSession->configuration();
        QString id;
        if (config.type() == QNetworkConfiguration::UserChoice)
            id = networkSession->sessionProperty(QLatin1String("UserChoiceConfiguration")).toString();
        else
            id = config.identifier();

        QSettings settings(QSettings::UserScope, QLatin1String("QtProject"));
        settings.beginGroup(QLatin1String("QtNetwork"));
        settings.setValue(QLatin1String("DefaultNetworkConfiguration"), id);
        settings.endGroup();
    }


    blockSize = 0;
    tcpServer = new QTcpServer(this);
    if (!tcpServer->listen(QHostAddress::Any, 42424)) {
        QMessageBox::critical(this, tr(serverName),
                              tr("Unable to start the server: %1.")
                              .arg(tcpServer->errorString()));
        close();
        return;
    }

    QString ipAddress;
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    // use the first non-localhost IPv4 address
    for (int i = 0; i < ipAddressesList.size(); ++i) {
        if (ipAddressesList.at(i) != QHostAddress::LocalHost &&
            ipAddressesList.at(i).toIPv4Address()) {
            ipAddress = ipAddressesList.at(i).toString();
            break;
        }
    }
    // if we did not find one, use IPv4 localhost
    if (ipAddress.isEmpty())
        ipAddress = QHostAddress(QHostAddress::LocalHost).toString();

    statusLabel->setText(tr("The server is running on\n\nIP: %1\nport: %2\n\n"
                            "Run the Fortune Client example now.")
                         .arg(ipAddress).arg(tcpServer->serverPort()));

}

/****************************************************************************
* SLOT:     sendFortune                                                     *
****************************************************************************/
void Server::sendFortune()
{

    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_0);

    out << (quint16)0;
    out << tr(serverMsg);
    out.device()->seek(0);
    out << (quint16)(block.size() - sizeof(quint16));

    clientConnection = tcpServer->nextPendingConnection();

    // premarks socket (QObject) for later deletion by the system
    connect(clientConnection, &QAbstractSocket::disconnected,
            clientConnection, &QObject::deleteLater);

    /* Read */
    connect(clientConnection, &QIODevice::readyRead,
            this, &Server::readMessage);

    clientConnection->write(block);
//    clientConnection->disconnectFromHost();
}

/****************************************************************************
* SLOT:     readMessage                                                     *
****************************************************************************/
void Server::readMessage()
{
    QDataStream in(clientConnection);
    in.setVersion(QDataStream::Qt_4_0);

    if (blockSize == 0) {
        if (clientConnection->bytesAvailable() < (int)sizeof(quint16))
            return;

        in >> blockSize;
    }

    if (clientConnection->bytesAvailable() < blockSize)
        return;

    QString qStMessage;
    in >> qStMessage;

    tcpInMsgCount++;
    statusLabel->setText(QString::number(tcpInMsgCount));
    //logField->appendPlainText(qStMessage);
    parser->parseTcpMessage(&qStMessage);

    /* to test connection rate, remove later */
    if (tcpInMsgCount == 1+1) {
        firstMessageTime = QDateTime::currentMSecsSinceEpoch();
    }
    if (tcpInMsgCount == 1000+1) {
        lastMessageTime = QDateTime::currentMSecsSinceEpoch();
        logField->appendPlainText(QString::number(lastMessageTime - firstMessageTime));
    }

    blockSize = 0;
}

/****************************************************************************
* SLOT:     displayDistance                                                 *
****************************************************************************/
void Server::displayDistance(QString nameAnchor, QString nameTag, double valueDistance, QString strTimestamp)
{
    // Functions later in seperate Class, DataManager or whatever
    QStringList log;
    log << nameAnchor << nameTag << QString::number(valueDistance) << strTimestamp;
    logField->appendPlainText(log.join(TCP_SEPARATOR));

	if (distCnt < DIST_BUFFER) {
		results[distCnt++] = valueDistance;
	} else if (distCnt == DIST_BUFFER) {
		distCnt = 0;
		results[distCnt] = valueDistance;
	}
}

/****************************************************************************
* SLOT:     handleKeepalive                                                 *
****************************************************************************/
void Server::handleKeepalive(QString nameAnchor, QString strTimestamp)
{
    // Functions later in seperate Class, AnchorManager
    QStringList log;
    log << nameAnchor << strTimestamp;
    logField->appendPlainText(log.join(TCP_SEPARATOR));

	double mean = 0.0;
	for (int i = 0; i < DIST_BUFFER; i++) {
		mean += results[i];
	}
	mean /= DIST_BUFFER;
	distanceLabel->setText(QString::number(mean));
}
