/****************************************************************************
*  Header     : main (ServerApplication_SNS)                  Version 1.0   *
*****************************************************************************
*                                                                           *
*  Function   : main function                 *
*                                                                           *
*                                                                           *
*  Methodes   : main(int argc, char *argv[])                                *
*                                                                           *
*  Author     : bunto1                                                      *
*                                                                           *
*  History    : 26.05.2016  bo Created                                      *
*                                                                           *
*  File       : main.cpp                                                    *
*                                                                           *
*****************************************************************************
* BFH TI Biel / Axiamo                                                      *
****************************************************************************/

/* imports */
#include <QApplication>
#include <QtCore>

#include <stdlib.h>

#include "server.h"

/* Class constant declaration  */

/* Class Type declaration      */

/* Class data declaration      */

/* Class definition            */

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QGuiApplication::setApplicationDisplayName(Server::cStTitleBar());
    Server server;
    server.show();

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

	server.displayDistance("eddie6", "eddie13", 0.5, QString::number(QDateTime::currentMSecsSinceEpoch()));
	server.displayDistance("eddie6", "eddie13", 1.5, QString::number(QDateTime::currentMSecsSinceEpoch()));
	server.displayDistance("eddie6", "eddie13", 2.5, QString::number(QDateTime::currentMSecsSinceEpoch()));
	server.displayDistance("eddie6", "eddie13", 3.5, QString::number(QDateTime::currentMSecsSinceEpoch()));
	server.displayDistance("eddie6", "eddie13", 4.5, QString::number(QDateTime::currentMSecsSinceEpoch()));
	server.handleKeepalive("eddie6", QString::number(QDateTime::currentMSecsSinceEpoch()));


    return app.exec();
}
