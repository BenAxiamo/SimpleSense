#ifndef SERVER_H
#define SERVER_H

/****************************************************************************
*  Header     : Server                  Version 1.0   *
*****************************************************************************
*                                                                           *
*  Function   :                  *
*                                                                           *
*                                                                           *
*  Methodes   :                                 *
*                                                                           *
*  Author     : bunto1                                                      *
*                                                                           *
*  History    : 26.05.2016  bo Created                                      *
*                                                                           *
*  File       : server.h                                                    *
*                                                                           *
*****************************************************************************
* BFH TI Biel / Axiamo                                                      *
****************************************************************************/

/* imports */
#include <QDialog>
#include "../lib/tcpipfunctions.h"
#include "../lib/tcpipprotocol.h"

/* Class constant declaration  */
#define DIST_BUFFER	3
/* Class Type declaration      */

/* Class data declaration      */

/* Class definition            */


QT_BEGIN_NAMESPACE
class QDialog;
class QLabel;
class QPlainTextEdit;
class QPushButton;
class QTcpServer;
class QTcpSocket;
class QNetworkSession;
class QString;
QT_END_NAMESPACE

class Server : public QDialog
{
    Q_OBJECT

public:
    explicit Server(QWidget *parent = Q_NULLPTR);
    ~Server();
    static const QString &cStTitleBar()
    {
      static const QString constant("Axiamo Positioning Network Server");
      return constant;
	}

public slots:
    void networkSessionOpened();
    void sendFortune();
    void readMessage();
    void displayDistance(QString nameAnchor, QString nameTag, double valueDistance, QString strTimestamp);
    void handleKeepalive(QString nameAnchor, QString strTimestamp);

private:
	void initGUI();

    QLabel *statusLabel;
	QLabel *distanceLabel;
	QLabel *imgAxiamoteLabel;
    QPlainTextEdit *logField;

    quint16 blockSize;
    QTcpServer *tcpServer;
    QStringList fortunes;
    QNetworkSession *networkSession;
    QTcpSocket *clientConnection;
    TcpIpFunctions *parser;

    quint16 tcpInMsgCount;
    quint16 tcpOutMsgCount;

    qint64 firstMessageTime;
    qint64 lastMessageTime;

	quint16 tcpBytes;
	int distCnt;

	double results[DIST_BUFFER];
};

#endif // SERVER_H
