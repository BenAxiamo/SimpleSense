#ifndef TCPIPPROTOCOL_H
#define TCPIPPROTOCOL_H
/****************************************************************************
*  Header     : Client                  Version 1.0   *
*****************************************************************************
*                                                                           *
*  Function   :                  *
*                                                                           *
*                                                                           *
*  Methodes   :                           *
*                                                                           *
*  Author     : bunto1                                                      *
*                                                                           *
*  History    : 26.05.2016  bo Created                                      *
*                                                                           *
*  File       : main.cpp                                                    *
*                                                                           *
*****************************************************************************
* BFH TI Biel / Axiamo                                                      *
****************************************************************************/

/* imports */

/* Constant declaration  */
#define PREF_CONTROL    (quint16)0x0001
#define PREF_KEEPALIVE  (quint16)0x0002
#define PREF_DISTANCE   (quint16)0x0004
#define PREF_SENSORDATA (quint16)0x0008

#define FRAME_PREFIX    0
#define FRAME_ANCHOR    1
#define FRAME_CT_SEQ    2
#define FRAME_CT_TIME   3
#define FRAME_DI_TAG    2
#define FRAME_DI_VAL    3
#define FRAME_DI_TIME   4
#define FRAME_KA_TIME   2
#define FRAME_SD_TAG    2
#define FRAME_SD_TIME   3

#define TCP_SEPARATOR   ','

#define CTRL_WHATEVER    (quint16)0
#define CTRL_FIRST_TX    (quint16)1
#define CTRL_FURTHER1    (quint16)2
#define CTRL_FURTHER2    (quint16)4


/* Class Type declaration      */

/* Class data declaration      */

/* Class definition            */

#endif // TCPIPPROTOCOL_H
