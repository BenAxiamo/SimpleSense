#ifndef TCPIPFUNCTIONS_H
#define TCPIPFUNCTIONS_H

#include "tcpipprotocol.h"

#include <QObject>
#include <QString>
#include <QList>
#include <QDebug>

enum TcpParser{
    parseSuccess,
    parseError
};

class TcpIpFunctions : public QObject
{    
    Q_OBJECT

public:
    TcpIpFunctions(QObject *parent);
    TcpParser parseTcpMessage(QString *msg);

signals:
    void tcpDistanceValue(QString nameAnchor, QString nameTag, double valueDistance, QString strTimestamp);
    void tcpKeepalive(QString nameAnchor, QString strTimestamp);
    void tcpSensordata(QString nameAnchor, QString nameTag, QString strTimestamp);
    void tcpControlXY();

private:
    TcpParser subParseControlMessage(QStringList *stList, int len);
    TcpParser subParseDistanceMessage(QStringList *stList, int len);
    TcpParser subParseKeepaliveMessage(QStringList *stList, int len);
    TcpParser subParseSensorDataMessage(QStringList *stList, int len);
};

#endif // TCPIPFUNCTIONS_H
