#include "tcpipfunctions.h"

TcpIpFunctions::TcpIpFunctions(QObject *parent)
{
}

TcpParser TcpIpFunctions::parseTcpMessage(QString *msg)
{
    QStringList stList = msg->split(TCP_SEPARATOR);
    int len = stList.length();

    if (len >= 2) {
        len -= 2;

        quint16 prefix = stList.at(FRAME_PREFIX).toInt();

        switch (prefix) {

        case PREF_CONTROL:
            subParseControlMessage(&stList, len);
            break;

        case PREF_DISTANCE:
            subParseDistanceMessage(&stList, len);
            break;

        case PREF_KEEPALIVE:
            subParseKeepaliveMessage(&stList, len);
            break;

        case PREF_SENSORDATA:
            subParseSensorDataMessage(&stList, len);

        default:
            return parseError;
        }
    } else {
        return parseError;
    }

    return parseSuccess;
}

TcpParser TcpIpFunctions::subParseControlMessage(QStringList *stList, int len)
{
    if (len >= 1) {
        quint16 ctrl = CTRL_WHATEVER;

        try {
            ctrl = stList->at(FRAME_CT_SEQ).toUShort();
        } catch (std::exception& e) {
            qDebug() << e.what() << ", ctrl Sequence no quint16?";
            return parseError;
        }

        switch (ctrl) {
        case CTRL_FIRST_TX:
            emit tcpControlXY();
            break;
        default:
            return parseError;
        }

        return parseSuccess;
    } else {
        return parseError;
    }
}

TcpParser TcpIpFunctions::subParseDistanceMessage(QStringList *stList, int len)
{
    if (len >= 3) {
        double distVal = 0;

        try {
            distVal = stList->at(FRAME_DI_VAL).toDouble();
        } catch (std::exception& e) {
            qDebug() << e.what() << ", distVal no double?";
            return parseError;
        }

        emit tcpDistanceValue(stList->at(FRAME_ANCHOR),
                              stList->at(FRAME_DI_TAG),
                              distVal,
                              stList->at(FRAME_DI_TIME));

        return parseSuccess;
    } else {
        return parseError;
    }
}

TcpParser TcpIpFunctions::subParseKeepaliveMessage(QStringList *stList, int len)
{
    if (len != 0) {
        emit tcpKeepalive((QString)stList->at(FRAME_ANCHOR), (QString)stList->at(FRAME_KA_TIME));
        return parseSuccess;
    } else {
        return parseError;
    }
}

TcpParser TcpIpFunctions::subParseSensorDataMessage(QStringList *stList, int len)
{
    if (len >= 2) {

        emit tcpSensordata(stList->at(FRAME_ANCHOR),
                           stList->at(FRAME_SD_TAG),
                           stList->at(FRAME_SD_TIME));
        return parseSuccess;
    } else {
        return parseError;
    }
}
